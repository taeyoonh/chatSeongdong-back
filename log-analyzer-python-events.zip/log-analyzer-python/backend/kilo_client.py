import json
import os
import re
import subprocess
import threading
from lib.config import load_config
from lib.paths import APP_ROOT
MASKED='***'
SECRET_KEY_RE=re.compile(r'(token|secret|password|passwd|authorization|credential|api[_-]?key)',re.I)
def build_prompt(job):
    context=job.get('context',{})
    return '\n'.join(['시작: 시험 로그 분석 작업을 수행하세요.',f"업로드 ID: {job['id']}",'현재 작업은 MCP 실행 환경에 연결됩니다. 다른 작업 ID를 사용하지 마세요.',f"근거 소스: 일반 search_rag는 {job.get('knowledgeSource','rag')}, label_event prepare와 validate_event prepare는 항상 원격 RAG를 사용합니다.",f"파일명: {job['filename']} (master.csv는 분석 전에 서버가 생성합니다.)",f"컨텍스트: 프로젝트={context.get('project','')} / 시험={context.get('test','')} / 프로토콜={context.get('protocol','')}",'이 실행은 사용자 입력을 받을 수 없습니다. get_job_status로 기존 진행을 확인하세요. finalized이면 build_report → verify_report를 수행하세요. 아니면 next_analysis_batch로 읽고 label_event prepare(clientId,messageLinks)로 실제 원본의 RAG 근거를 먼저 조회하세요. 근거를 읽고 label_event submit(event,labelEvidenceId,evidenceQuote,rationale)으로 각 행의 역할·관계·상황 초안을 작성하세요. 수정 시에도 새 prepare가 필요합니다. query_messages/calculate_metrics는 eventClientId 초안을 대상으로 합니다. validate_event prepare/submit을 meaning과 boundary 각각 수행한 뒤 confirm_event로 확정하세요. 수정·계산 추가 시 검증을 다시 해야 합니다. 긴 이벤트는 초안을 다음 구간에 이어갈 수 있습니다. complete_analysis_batch(carryState) 후 다음 구간을 읽으세요. done=true이고 모든 이벤트를 확정한 뒤 finalize_analysis → build_report(Excel 포함) → verify_report. 근거 부족은 undetermined로 기록하세요.'])
def redact(value):
    if isinstance(value,dict): return {k:MASKED if SECRET_KEY_RE.search(k) else redact(v) for k,v in value.items()}
    if isinstance(value,list): return [redact(v) for v in value]
    return value

def brief_input(value):
    if value is None: return ''
    if isinstance(value,str):
        try: value=json.loads(value)
        except ValueError: return '[문자열 입력 생략]'
    if not isinstance(value,dict): return str(value)[:80]
    value=redact(value); parts=[]
    for k,v in list(value.items())[:3]:
        text=json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v)
        parts.append(f'{k}={text[:60]}')
    return ' '.join(parts)
def summarize_event(event):
    kind=event.get('type',event.get('kind','event')); error=event.get('error')
    if error:
        if isinstance(error,dict): return 'error: '+str(error.get('name','Error'))+' '+str(error.get('message') or (error.get('data') or {}).get('message') or error)[:300]
        return 'error: '+str(error)[:300]
    part=event.get('part') or {}
    if kind=='tool_use':
        state=part.get('state') or {}; name=part.get('tool','tool')
        if state.get('status')=='error': return f"tool {name} 오류: {str(state.get('error',''))[:200]}"
        return f"tool {name} ({brief_input(state.get('input'))})"
    if kind=='text': return 'text: '+re.sub(r'\s+',' ',str(part.get('text','')))[:300]
    return kind+(': '+str(event.get('text') or event.get('message'))[:300] if event.get('text') or event.get('message') else '')
class KiloRun:
    def __init__(self,job,on_log=lambda line:None):
        cfg={**load_config()}
        if job.get('selectedModel'): cfg['model']=job['selectedModel']
        if job.get('kiloExecutable'): cfg['kiloExecutable']=job['kiloExecutable']
        self.job=job; self.error=None; self.ok=False; self.child=None; self.stopped=False
        self._log=lambda line:on_log(str(line))
        self.cfg=cfg
    def stop(self):
        self.stopped=True
        if self.child and self.child.poll() is None:
            if os.name=='nt': subprocess.run(['taskkill','/PID',str(self.child.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            else:
                import signal
                try: os.killpg(self.child.pid,signal.SIGKILL)
                except ProcessLookupError: pass
    def run(self):
        if self.stopped:return dict(ok=False,error='분석 실행이 중단되었습니다.')
        cfg=self.cfg; args=[cfg['kiloExecutable'],'run',build_prompt(self.job),'--format','json','--auto','--dir',str(APP_ROOT),'--agent',cfg['agent'],'-m',cfg['model'],'--title','log-'+self.job['id'][:8]]
        try:
            options=dict(cwd=APP_ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',bufsize=1,env={**os.environ,'PYTHONUTF8':'1','LOG_ANALYZER_JOB_ID':str(self.job['id']),'LOG_ANALYZER_KNOWLEDGE_SOURCE':self.job.get('knowledgeSource','rag'),'LOG_ANALYZER_KNOWLEDGE_PATH':self.job.get('knowledgePath') or ''})
            if os.name=='nt': options['creationflags']=subprocess.CREATE_NO_WINDOW|subprocess.CREATE_NEW_PROCESS_GROUP
            else: options['start_new_session']=True
            self.child=subprocess.Popen(args,**options)
            if self.stopped: self.stop()
        except OSError as err:
            self.error=f'kilo 프로세스를 시작하지 못했습니다: {err}'; self._log(self.error); return dict(ok=False,error=self.error)
        tail=[]; model_errors=[]
        def pump(stream,is_error=False):
            for line in stream:
                line=line.strip()
                if not line: continue
                if is_error:
                    tail.append(line); del tail[:-20]; self._log('stderr: '+line[:500])
                else:
                    try:
                        event=json.loads(line); summary=summarize_event(event)
                        if event.get('error') or event.get('type')=='error': model_errors.append(summary)
                        self._log(summary)
                    except (ValueError,TypeError,AttributeError): self._log(line[:500])
            stream.close()
        readers=[threading.Thread(target=pump,args=(self.child.stdout,),daemon=True),threading.Thread(target=pump,args=(self.child.stderr,True),daemon=True)]
        for reader in readers: reader.start()
        # No total analysis deadline. Explicit stop/server shutdown still terminates Kilo.
        code=self.child.wait()
        for reader in readers: reader.join(timeout=3)
        if self.error is None:
            if self.stopped: self.error='서버 종료로 분석이 중단되었습니다.'
            elif model_errors: self.error=model_errors[-1]
            elif code!=0: self.error=f'kilo 프로세스 종료 (code {code}). '+ '\n'.join(tail)[-1000:]
        self.ok=self.error is None
        return dict(ok=self.ok,error=self.error)
def run_kilo_job(job,on_log=lambda line:None): return KiloRun(job,on_log)
