import json
import logging
import mimetypes
import re
import signal
import threading
import uuid
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from urllib.parse import urlsplit,parse_qs,unquote
from lib.config import load_config
from lib.kilo_settings import settings_view,update_settings,fetch_models,job_runtime,SettingsError,SettingsConflict
from lib.paths import PUBLIC_DIR,UPLOADS_DIR,RESULTS_DIR,LOGS_DIR,ensure_dirs
from lib.db import get_db,close_db
from lib.jobs import get_job_view,create_job,set_job_status,fail_stale_jobs,new_job_id,list_jobs,TERMINAL
from lib.time import ms_to_display
from .kilo_client import run_kilo_job
from mcp_server.knowledge import local_knowledge_path
from mcp_server.local_text_client import LocalTextClient
from mcp_server.rag_client import RagError
from mcp_server.dataset import prepare_dataset
LOGGER=logging.getLogger('log-analyzer')
active_jobs={}; active_lock=threading.Lock()
shutting_down=threading.Event()
def log_tail(id):
    try:
        with (LOGS_DIR/f'{id}.log').open(encoding='utf-8') as stream: return [line.rstrip() for line in stream if line.strip()]
    except OSError: return []
def start_analysis(id):
    job=get_job_view(id)
    if not job: return False
    with active_lock:
        if shutting_down.is_set() or id in active_jobs:return False
        active_jobs[id]=None
    set_job_status(id,'queued')
    def worker():
        try:
            with (LOGS_DIR/f'{id}.log').open('a',encoding='utf-8',buffering=1) as stream:
                lock=threading.Lock()
                def log(line):
                    with lock:
                        stream.write('['+datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')+'] '+line+'\n'); LOGGER.info('[kilo %s] %s',id,line)
                log("근거 소스: "+("사내 RAG (ON)" if job.get("knowledgeSource","rag")=="rag" else "지정 로컬 TXT (OFF)"))
                prepared=prepare_dataset(id)
                log('데이터 재사용 및 master.csv 준비 완료' if prepared.get('reused') else '시간순 master.csv 생성 완료')
                run=run_kilo_job(job,log)
                with active_lock:
                    active_jobs[id]=run
                    if shutting_down.is_set():run.stopped=True
                outcome=run.run()
                current=get_job_view(id)
                if current and current['status'] not in TERMINAL:
                    set_job_status(id,'failed',outcome.get('error') or 'Kilo가 분석 완료 도구 호출 없이 종료되었습니다. 로그를 확인하고 다시 업로드하세요.')
        except Exception as err:
            LOGGER.exception('Analysis failed: %s',id)
            set_job_status(id,'failed',str(err))
        finally:
            with active_lock: active_jobs.pop(id,None)
            close_db()
    threading.Thread(target=worker,name='job-'+id,daemon=False).start()
    return True

def valid_id(value):
    try: return str(uuid.UUID(value))==value
    except (ValueError,AttributeError): return False

def event_view(row):
    value=dict(id=row['id'],clientId=row['client_id'],title=row['title'],type=row['category']+'.'+row['action'],time=ms_to_display(row['start_ms']) if row['start_ms'] is not None else None,endTime=ms_to_display(row['end_ms']) if row['end_ms'] is not None else None,status=row['status'],severity=row['severity'],description=row['description'])
    if 'parent_id' in row.keys(): value['parentId']=row['parent_id']
    return value
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,format,*args): LOGGER.info('%s %s',self.address_string(),format%args)
    def json(self,status,value):
        raw=json.dumps(value,ensure_ascii=False).encode('utf-8'); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store');
        if self.close_connection: self.send_header('Connection','close')
        self.end_headers(); self.wfile.write(raw)
    def send_file(self,file,content_type=None,download=None):
        size=file.stat().st_size; self.send_response(200); self.send_header('Content-Type',content_type or mimetypes.guess_type(str(file))[0] or 'application/octet-stream'); self.send_header('Content-Length',str(size))
        if download: self.send_header('Content-Disposition',f'attachment; filename="{download}"')
        self.end_headers()
        with file.open('rb') as stream:
            while data:=stream.read(1024*1024): self.wfile.write(data)
    def do_GET(self): self.handle_route('GET')
    def do_POST(self): self.handle_route('POST')
    def do_PUT(self): self.json(404,{'error':'API를 찾을 수 없습니다.'})
    def do_DELETE(self): self.json(404,{'error':'API를 찾을 수 없습니다.'})
    def handle_route(self,method):
        try:
            parsed=urlsplit(self.path); path=unquote(parsed.path)
            if path.startswith('/api'):
                if path.startswith('/api/kilo/'):
                    return self.kilo_settings_route(method,path,parse_qs(parsed.query))
                if method=='POST' and path=='/api/read-jobs': return self.upload(parse_qs(parsed.query))
                if method=='GET' and path=='/api/read-jobs': return self.json(200,list_jobs())
                if method=='GET' and path=='/api/health': return self.json(200,{'ok':True})
                match=re.fullmatch(r'/api/read-jobs/([^/]+)(?:/(csv|xlsx|events|master|resume)(?:/([^/]+))?)?',path)
                if match and (method=='GET' or method=='POST' and match.group(2)=='resume'):
                    id,section,eid=match.groups()
                    if not valid_id(id): return self.json(404,{'error':'작업을 찾을 수 없습니다.'})
                    job=get_job_view(id)
                    if not job: return self.json(404,{'error':'작업을 찾을 수 없습니다.'})
                    if section=='resume':
                        if method!='POST':return self.json(405,{'error':'POST가 필요합니다.'})
                        if self.headers.get('Origin') and urlsplit(self.headers['Origin']).netloc!=self.headers.get('Host'):return self.json(403,{'error':'다른 출처의 실행은 허용되지 않습니다.'})
                        if job['status']=='completed':return self.json(409,{'error':'이미 완료된 작업입니다.'})
                        if not (UPLOADS_DIR/id/'upload.zip').is_file():return self.json(404,{'error':'기존 업로드 ZIP이 없습니다.'})
                        if not start_analysis(id):return self.json(409,{'error':'이미 실행 중이거나 서버 종료 중입니다.'})
                        return self.json(202,{'id':id,'status':'queued'})
                    if section is None: job['log']=log_tail(id); return self.json(200,job)
                    if section=='master':
                        output=RESULTS_DIR/id/'master.csv'
                        if not output.is_file():return self.json(404,{'error':'통합 CSV가 아직 준비되지 않았습니다.'})
                        return self.send_file(output,'text/csv; charset=utf-8',f'master_{id[:8]}.csv')
                    if section=='csv':
                        output=RESULTS_DIR/id/'final.csv'
                        if not output.exists(): return self.json(404,{'error':'최종 CSV가 아직 없습니다.'})
                        return self.send_file(output,'text/csv; charset=utf-8',f'final_{id[:8]}.csv')
                    if section=='xlsx':
                        if not (job.get('report') or {}).get('excel'): return self.json(409,{'error':'검증·확정 후 Excel을 생성하세요.'})
                        output=RESULTS_DIR/id/'final.xlsx'
                        if not output.is_file():return self.json(404,{'error':'최종 Excel이 없습니다.'})
                        return self.send_file(output,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',f'final_{id[:8]}.xlsx')
                    if section=='events': return self.events(id,eid)
                return self.json(404,{'error':f'API를 찾을 수 없습니다: {method} {path}'})
            if method!='GET': return self.json(404,{'error':'Not found'})
            target=(PUBLIC_DIR/(path.lstrip('/') or 'index.html')).resolve()
            if not target.is_relative_to(PUBLIC_DIR.resolve()) or not target.is_file(): return self.json(404,{'error':'Not found'})
            return self.send_file(target)
        except SettingsConflict as err: self.json(409,{'error':str(err)})
        except SettingsError as err: self.json(400,{'error':str(err)})
        except (BrokenPipeError,ConnectionResetError): pass
        except Exception:
            LOGGER.exception('HTTP request failed')
            self.close_connection=True
            try: self.json(500,{'error':'서버 오류가 발생했습니다.'})
            except OSError: pass
        finally: close_db()
    def upload(self,query):
        cfg=load_config(); self.close_connection=True
        if self.headers.get('Transfer-Encoding'): return self.json(400,{'error':'Content-Length가 있는 업로드가 필요합니다.'})
        try: length=int(self.headers.get('Content-Length','-1'))
        except ValueError: length=-1
        if length<0: return self.json(411,{'error':'Content-Length가 필요합니다.'})
        if length==0: return self.json(400,{'error':'빈 파일입니다.'})
        if length>cfg['maxUploadBytes']: return self.json(413,{'error':f"파일은 {cfg['maxUploadBytes']//1024//1024}MB보다 클 수 없습니다."})
        # Browser uploads must originate from this local service.
        origin=self.headers.get('Origin')
        if origin and urlsplit(origin).netloc!=self.headers.get('Host'): return self.json(403,{'error':'다른 출처의 업로드는 허용되지 않습니다.'})
        get=lambda key,default:str(query.get(key,[default])[0]).strip() or default
        mode=get('knowledgeSource','rag')
        if mode!='rag': return self.json(400,{'error':'이벤트 라벨링은 사내 RAG 조회가 필수입니다. RAG 모드로 업로드하세요.'})
        knowledge_path=None
        runtime=job_runtime(get('selectedModel','') or None)
        id=new_job_id(); directory=UPLOADS_DIR/id; directory.mkdir(parents=True); part=directory/'upload.zip.part'; final=directory/'upload.zip'
        try:
            self.connection.settimeout(600); remaining=length
            with part.open('wb') as stream:
                while remaining:
                    data=self.rfile.read(min(1024*1024,remaining))
                    if not data: raise ConnectionError('업로드 전송이 중단되었습니다.')
                    stream.write(data); remaining-=len(data)
            part.replace(final)
            create_job(id=id,filename=get('filename','upload.zip'),project=get('project','미지정 프로젝트'),test=get('test','미지정 시험'),protocol=get('protocol','Link-16'),knowledge_source=mode,knowledge_path=knowledge_path,selected_model=runtime['model'],kilo_executable=runtime['kiloExecutable'])
            start_analysis(id); self.json(200,{'id':id,'status':'queued'})
        except Exception:
            part.unlink(missing_ok=True)
            raise
    def kilo_settings_route(self,method,path,query):
        if method=='POST':self.close_connection=True
        import ipaddress
        if not ipaddress.ip_address(self.client_address[0]).is_loopback:
            return self.json(403,{'error':'Kilo 설정 관리는 서버 PC의 로컬 접속에서만 가능합니다.'})
        host=urlsplit('http://'+self.headers.get('Host','')).hostname
        if host not in ('localhost','127.0.0.1','::1'):
            return self.json(403,{'error':'localhost 주소로 접속하세요.'})
        origin=self.headers.get('Origin')
        if (origin and urlsplit(origin).netloc!=self.headers.get('Host')) or self.headers.get('Sec-Fetch-Site')=='cross-site':
            return self.json(403,{'error':'다른 출처에서 Kilo 설정에 접근할 수 없습니다.'})
        if method=='GET' and path=='/api/kilo/settings':
            return self.json(200,settings_view(query.get('fileId',[None])[0]))
        if method!='POST': return self.json(404,{'error':'설정 API를 찾을 수 없습니다.'})
        self.close_connection=True
        if self.headers.get_content_type()!='application/json':return self.json(415,{'error':'application/json이 필요합니다.'})
        try:length=int(self.headers.get('Content-Length','-1'))
        except ValueError:length=-1
        if not 0<length<=2*1024*1024:return self.json(400,{'error':'설정 요청 크기는 1바이트~2MiB여야 합니다.'})
        self.connection.settimeout(30)
        try:args=json.loads(self.rfile.read(length).decode('utf-8'))
        except (ValueError,UnicodeError):return self.json(400,{'error':'올바른 JSON이 필요합니다.'})
        if not isinstance(args,dict):return self.json(400,{'error':'JSON 객체가 필요합니다.'})
        if path=='/api/kilo/settings':return self.json(200,update_settings(args))
        if path=='/api/kilo/models/fetch':return self.json(200,fetch_models(args.get('providerId')))
        return self.json(404,{'error':'설정 API를 찾을 수 없습니다.'})

    def events(self,id,eid):
        db=get_db()
        if eid is None:
            rows=db.execute('''SELECT e.*,(SELECT COUNT(*) FROM event_messages em WHERE em.event_id=e.id) message_count,(SELECT COUNT(*) FROM findings f WHERE f.event_id=e.id) finding_count FROM events e WHERE e.upload_id=? ORDER BY e.start_ms IS NULL,e.start_ms,e.id''',(id,))
            return self.json(200,{'events':[event_view(e)|dict(messageCount=e['message_count'],findingCount=e['finding_count']) for e in rows]})
        event=db.execute('SELECT * FROM events WHERE upload_id=? AND (CAST(id AS TEXT)=? OR client_id=?) ORDER BY CASE WHEN client_id=? THEN 0 ELSE 1 END LIMIT 1',(id,eid,eid,eid)).fetchone()
        if not event: return self.json(404,{'error':'이벤트를 찾을 수 없습니다.'})
        findings=[dict(id=f['id'],clientId=f['client_id'],kind=f['kind'],title=f['title'],description=f['description'],verdict=f['verdict'],severity=f['severity'],time=ms_to_display(f['start_ms']),references=json.loads(f['reference_json'])) for f in db.execute('SELECT * FROM findings WHERE event_id=? ORDER BY id',(event['id'],))]
        rows=db.execute('SELECT m.* FROM messages m JOIN event_messages em ON em.message_id=m.id WHERE em.event_id=? ORDER BY m.ts_ms IS NULL,m.ts_ms,m.source_file,m.line_no LIMIT 501',(event['id'],)).fetchall()
        messages=[dict(id=m['id'],time=ms_to_display(m['ts_ms']),source=m['source_file'],line=m['line_no'],fields=json.loads(m['data_json'])) for m in rows[:500]]
        return self.json(200,dict(event=event_view(event),findings=findings,messages=messages,truncated=len(rows)>500))

def main():
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    shutting_down.clear()
    ensure_dirs(); get_db(); fail_stale_jobs('서버 재시작으로 처리가 중단되었습니다. 기존 작업을 이어서 실행할 수 있습니다.'); close_db(); cfg=load_config()
    server=ThreadingHTTPServer((cfg['host'],cfg['port']),Handler); server.daemon_threads=True
    def stop(*_):
        threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGINT,stop); signal.signal(signal.SIGTERM,stop)
    LOGGER.info('시험 로그 분석기: http://%s:%s/ | 모델 및 Kilo 실행 경로는 화면의 Kilo 설정에서 관리합니다.',cfg['host'],cfg['port'])
    try: server.serve_forever(poll_interval=.2)
    finally:
        shutting_down.set()
        with active_lock: runs=list(active_jobs.values())
        for run in runs:
            if run is not None:run.stop()
        server.server_close(); close_db()
if __name__=='__main__': main()
