import re
import statistics
from .time import ms_to_clock
MSG_COLUMN_RE=re.compile(r'^(msg|message|type|family|mf|msg_fam|msg_type|protocol_type|message_type)$',re.I)
FROM_COLUMN_RE=re.compile(r'^(from|src|sender|source|origin|tx)$',re.I)
TO_COLUMN_RE=re.compile(r'^(to|dst|receiver|dest|destination|rx)$',re.I)
TIME_COLUMN_RE=re.compile(r'^(time1|time2|time|timestamp|datetime)$',re.I)
def find_column(data,regex):
    for k,v in data.items():
        v=str(v or '').strip()
        if regex.fullmatch(k) and v and not re.fullmatch('[-_–—]+',v): return v
    return ''
def msg_cell(data): return find_column(data,MSG_COLUMN_RE)
def route_label(data,source):
    a,b=find_column(data,FROM_COLUMN_RE),find_column(data,TO_COLUMN_RE)
    return f'{a} → {b}' if a and b else re.split(r'[\\/]',source or '')[-1]
def pick_pairs(data):
    return [f'{k}={v}' for k,v in data.items() if not TIME_COLUMN_RE.fullmatch(k) and str(v or '').strip() and not re.fullmatch('[-_–—]+',str(v))][:4]
def make_evidence(rows,limit=12):
    out=[]; seen=set()
    for row in rows:
        if row.get('ts_ms') is None: continue
        key=row.get('id')
        if key is not None and key in seen: continue
        seen.add(key); data=row.get('data',{}); source=row.get('source_file','')
        out.append([ms_to_clock(row['ts_ms']),route_label(data,source),msg_cell(data) or source.split('/')[-1],pick_pairs(data)])
        if len(out)>=limit: break
    return out
def median(values): return statistics.median(values) if values else 0
def percentile(values,p):
    if not values: return 0
    ordered=sorted(values)
    return ordered[min(len(ordered)-1,max(0,int((len(ordered)-1)*p+0.5)))]
