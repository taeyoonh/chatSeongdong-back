from pathlib import Path
APP_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = APP_ROOT / 'data'
UPLOADS_DIR = DATA_DIR / 'uploads'
RESULTS_DIR = DATA_DIR / 'results'
LOGS_DIR = DATA_DIR / 'logs'
DB_PATH = DATA_DIR / 'app.db'
PUBLIC_DIR = APP_ROOT / 'public'
def ensure_dirs():
    for directory in (DATA_DIR, UPLOADS_DIR, RESULTS_DIR, LOGS_DIR):
        directory.mkdir(parents=True, exist_ok=True)
