import json
import time
import uuid
from .db import get_db
TERMINAL = ('completed','verification_failed','failed')
def now(): return int(time.time()*1000)
def new_job_id(): return str(uuid.uuid4())
def create_job(*, id, filename, project, test, protocol, knowledge_source="rag", knowledge_path=None, selected_model=None, kilo_executable=None):
    if knowledge_source not in ('rag','local_text'): raise ValueError('Invalid knowledge source')
    get_db().execute('INSERT INTO jobs(id,filename,project,test,protocol,status,created_at,updated_at,knowledge_source,knowledge_path,selected_model,kilo_executable) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', (id,filename,project,test,protocol,'uploading',now(),now(),knowledge_source,knowledge_path,selected_model,kilo_executable))
def get_job(id):
    row = get_db().execute('SELECT * FROM jobs WHERE id=?',(id,)).fetchone()
    if row is None:return None
    value=dict(row);value.pop('token',None)  # Ignore the unused column in pre-existing databases.
    return value
def set_job_status(id, status, error=None):
    get_db().execute('UPDATE jobs SET status=?,error=?,updated_at=? WHERE id=?',(status,error,now(),id))
def fail_stale_jobs(message):
    get_db().execute("UPDATE jobs SET status='failed',error=?,updated_at=? WHERE status NOT IN ('completed','verification_failed','failed')",(message,now()))
def set_job_result(id, *, result=None, report=None, verification=None, policy=None):
    encode=lambda x: json.dumps(x,ensure_ascii=False) if x is not None else None
    get_db().execute('UPDATE jobs SET result_json=?,report_json=?,verification_json=?,policy=?,updated_at=? WHERE id=?',(encode(result),encode(report),encode(verification),policy,now(),id))
def parse_json(value, fallback=None):
    try: return json.loads(value) if value else fallback
    except (ValueError,TypeError): return fallback
def get_job_view(id):
    job = get_job(id)
    if not job: return None
    result = dict(datasetWarnings=parse_json(job['dataset_warnings_json'],[]),id=job['id'],status=job['status'],error=job['error'],filename=job['filename'],selectedModel=job['selected_model'],kiloExecutable=job['kilo_executable'],knowledgeSource=job['knowledge_source'],knowledgePath=job['knowledge_path'],context={k:job[k] for k in ('project','test','protocol')},files=[dict(r) for r in get_db().execute('SELECT name,row_count AS rowCount,first_time AS firstTime,last_time AS lastTime FROM file_meta WHERE upload_id=? ORDER BY name',(id,))],report=parse_json(job['report_json'],{'files':[]}),verification=parse_json(job['verification_json'],{'errors':[]}),result=parse_json(job['result_json']),policy=job['policy'])
    return result
def list_jobs():
    return [dict(r) for r in get_db().execute('SELECT id,filename,status,project,test,protocol,created_at,knowledge_source AS knowledgeSource FROM jobs ORDER BY created_at DESC')]
