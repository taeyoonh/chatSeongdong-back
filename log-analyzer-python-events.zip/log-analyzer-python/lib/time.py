import math
import re
from datetime import datetime
TIME_ONLY_RE = re.compile(r'^(\d{1,2}):(\d{1,2}):(\d{1,2})(?:[.,](\d{1,6}))?$')
DATETIME_RE = re.compile(r'^(\d{4})[-_/.](\d{1,2})[-_/.](\d{1,2})[T ]?(\d{1,2}):(\d{1,2}):(\d{1,2})(?:[.,](\d{1,6}))?$')
COMPACT_RE = re.compile(r'^(\d{4})(\d{2})(\d{2})[ _-]?(\d{2})(\d{2})(\d{2})$')
def ms_to_display(ms, with_date=True):
    if ms is None: return ''
    try: return datetime.fromtimestamp(ms/1000).strftime('%Y-%m-%d %H:%M:%S' if with_date else '%H:%M:%S')
    except (ValueError,OverflowError,OSError): return ''
def ms_to_clock(ms): return ms_to_display(ms,False)
def duration_text(ms):
    s=int(ms//1000); h,s=divmod(s,3600); m,s=divmod(s,60)
    return (f'{h}시간 ' if h else '')+f'{m}분 {s}초'
def parse_time_value(raw, date_context=None):
    if raw is None: return None
    s=str(raw).strip()
    anchor=date_context or datetime.now()
    try:
        match=DATETIME_RE.fullmatch(s) or COMPACT_RE.fullmatch(s)
        if match:
            parts=match.groups(); frac=(parts[6] if len(parts)>6 else '') or ''
            d=datetime(*map(int,parts[:6]),microsecond=int(frac.ljust(6,'0') or '0'))
            return int(d.timestamp()*1000)
        match=TIME_ONLY_RE.fullmatch(s)
        if match:
            h,m,sec,frac=match.groups()
            return int(datetime(anchor.year,anchor.month,anchor.day,int(h),int(m),int(sec),int((frac or '').ljust(6,'0') or '0')).timestamp()*1000)
        if len(s)>=9:
            n=float(s)
            if math.isfinite(n):
                if n>1e12: return math.floor(n)
                if n>1e9: return math.floor(n*1000)
    except (ValueError,OverflowError,OSError): pass
    return None
