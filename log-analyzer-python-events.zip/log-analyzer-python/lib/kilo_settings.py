"""Local UI management of Kilo JSON/JSONC provider/model configuration."""
from __future__ import annotations
import copy
import hashlib
import ipaddress
import json
import os
import re
import tempfile
import threading
import time
from pathlib import Path
from urllib.request import Request,build_opener,HTTPRedirectHandler
from urllib.error import HTTPError,URLError
from urllib.parse import urlsplit
from .paths import APP_ROOT,DATA_DIR
from .config import load_config,find_kilo_exe

LOCK=threading.RLock()
KEEP='__KEEP_SECRET__'
SECRET=re.compile(r'token|secret|password|passwd|authorization|credential|api[_-]?key',re.I)
UI_PATH=DATA_DIR/'kilo-ui-settings.json'
class SettingsError(ValueError): pass
class SettingsConflict(SettingsError): pass

def clean_jsonc(text):
    chars=list(text);i=0;quoted=False;escape=False
    while i<len(text):
        ch=text[i]
        if quoted:
            if escape:escape=False
            elif ch=='\\':escape=True
            elif ch=='"':quoted=False
            i+=1;continue
        if ch=='"':quoted=True;i+=1;continue
        if text[i:i+2]=='//':
            end=text.find('\n',i+2);end=len(text) if end<0 else end
            for n in range(i,end):chars[n]=' '
            i=end;continue
        if text[i:i+2]=='/*':
            end=text.find('*/',i+2)
            if end<0:raise SettingsError('JSONC 주석이 닫히지 않았습니다.')
            for n in range(i,end+2):
                if chars[n] not in '\r\n':chars[n]=' '
            i=end+2;continue
        i+=1
    # Remove trailing commas outside strings without changing offsets.
    clean=''.join(chars);quoted=False;escape=False
    for i,ch in enumerate(clean):
        if quoted:
            if escape:escape=False
            elif ch=='\\':escape=True
            elif ch=='"':quoted=False
        elif ch=='"':quoted=True
        elif ch==',':
            j=i+1
            while j<len(clean) and clean[j].isspace():j+=1
            if j<len(clean) and clean[j] in '}]':chars[i]=' '
    return ''.join(chars)

def read_config(path):
    if not path.exists(): return {},'{}\n'
    try:
        raw=path.read_text(encoding='utf-8-sig');value=json.loads(clean_jsonc(raw))
    except (OSError,ValueError) as err: raise SettingsError(f'{path.name}: 설정 파일을 읽거나 JSON/JSONC로 해석할 수 없습니다.') from err
    if not isinstance(value,dict):raise SettingsError(f'{path.name}: 최상위 JSON 객체가 필요합니다.')
    return value,raw

def revision(raw):return hashlib.sha256(raw.encode('utf-8')).hexdigest()
def file_id(path):return hashlib.sha256(str(path).encode()).hexdigest()[:20]
def global_paths():
    home=Path(os.getenv('USERPROFILE') or Path.home())
    dirs=[Path(os.getenv('XDG_CONFIG_HOME',str(home/'.config')))/'kilo']
    if home/'.config/kilo' not in dirs:dirs.append(home/'.config/kilo')
    paths=[]
    for directory in dirs:
        for name in ('config.json','opencode.json','opencode.jsonc','kilo.json','kilo.jsonc'):
            p=(directory/name).resolve()
            if p.exists():paths.append(p)
    override=os.getenv('KILO_CONFIG')
    if override and Path(override).is_file():
        path=Path(override).resolve()
        if path not in paths:paths.append(path)
    # The create target is explicit in the UI when no global file exists.
    if not paths:paths=[(dirs[0]/'kilo.jsonc').resolve()]
    return paths

def project_paths():
    paths=[]
    for directory in (APP_ROOT,APP_ROOT/'.kilocode',APP_ROOT/'.kilo'):
        for name in ('config.json','opencode.json','opencode.jsonc','kilo.json','kilo.jsonc'):
            path=directory/name
            if path.exists():paths.append(path)
    return paths

def merge(a,b):
    out=copy.deepcopy(a)
    for key,value in b.items():out[key]=merge(out[key],value) if isinstance(out.get(key),dict) and isinstance(value,dict) else copy.deepcopy(value)
    return out

def effective_config():
    out={};origins={}
    for path in global_paths()+project_paths():
        value,_=read_config(path);out=merge(out,value)
        for name,provider in value.get('provider',{}).items():
            origins[name]=str(path)
    if os.getenv('KILO_CONFIG_CONTENT'):
        try:value=json.loads(clean_jsonc(os.environ['KILO_CONFIG_CONTENT']))
        except ValueError as err:raise SettingsError('KILO_CONFIG_CONTENT의 JSON을 확인하세요.') from err
        out=merge(out,value)
        for name in value.get('provider',{}):origins[name]='KILO_CONFIG_CONTENT'
    return out,origins

def redact(value):
    if isinstance(value,dict):return {k:({h:KEEP if v2 not in (None,'') else v2 for h,v2 in v.items()} if k.lower()=='headers' and isinstance(v,dict) else KEEP if SECRET.search(k) and v not in (None,'') else redact(v)) for k,v in value.items()}
    if isinstance(value,list):return [redact(v) for v in value]
    return value

def restore(value,old):
    if value==KEEP:
        if old is None:raise SettingsError('기존 값이 없는 항목에 비밀값 유지 표시를 사용할 수 없습니다.')
        return copy.deepcopy(old)
    if isinstance(value,dict):return {k:restore(v,old.get(k) if isinstance(old,dict) else None) for k,v in value.items()}
    if isinstance(value,list):return [restore(v,old[i] if isinstance(old,list) and i<len(old) else None) for i,v in enumerate(value)]
    return value

def atomic_write(path,text):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(dir=path.parent,prefix='.'+path.name+'.',suffix='.tmp')
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as out:out.write(text)
        try:os.chmod(tmp,0o600)
        except OSError:pass
        os.replace(tmp,path)
    finally:Path(tmp).unlink(missing_ok=True)

def set_top(raw,key,value):
    clean=clean_jsonc(raw);decoder=json.JSONDecoder();i=clean.find('{')+1;last_end=i
    while i<len(clean):
        while i<len(clean) and (clean[i].isspace() or clean[i]==','):i+=1
        if i>=len(clean) or clean[i]=='}':break
        name,end=decoder.raw_decode(clean,i);i=end
        while clean[i].isspace():i+=1
        if clean[i]!=':':raise SettingsError('설정 객체 문법을 확인하세요.')
        i+=1
        while clean[i].isspace():i+=1
        start=i;_,end=decoder.raw_decode(clean,i)
        if name==key:return raw[:start]+json.dumps(value,ensure_ascii=False,indent=2)+raw[end:]
        i=end;last_end=end
    obj=json.loads(clean)
    fragment=(',' if obj else '')+'\n  '+json.dumps(key)+': '+json.dumps(value,ensure_ascii=False,indent=2)
    return raw[:last_end]+fragment+raw[last_end:]

def write_top(path,key,value,expected):
    _,raw=read_config(path)
    if expected!=revision(raw):raise SettingsConflict('설정 파일이 변경됐습니다. 새로고침 후 다시 저장하세요.')
    updated=set_top(raw,key,value)
    json.loads(clean_jsonc(updated))
    if path.exists():
        backup=path.with_name(path.name+'.backup-'+str(time.time_ns()))
        atomic_write(backup,raw)
    atomic_write(path,updated)

def ui_settings():
    if not UI_PATH.exists():return {}
    try:return json.loads(UI_PATH.read_text(encoding='utf-8'))
    except (OSError,ValueError) as err:raise SettingsError('UI 설정 파일을 읽을 수 없습니다.') from err

def models_from(config,origins):
    enabled=set(config.get('enabled_providers') or []);disabled=set(config.get('disabled_providers') or []);rows=[]
    for pid,provider in config.get('provider',{}).items():
        if not isinstance(provider,dict):continue
        for mid,model in (provider.get('models') or {}).items():
            if not isinstance(model,dict):continue
            rows.append(dict(id=pid+'/'+mid,providerId=pid,modelId=mid,name=model.get('name',mid),providerName=provider.get('name',pid),toolCall=model.get('tool_call'),reasoning=model.get('reasoning'),disabled=pid in disabled or bool(enabled and pid not in enabled),origin=origins.get(pid,'')))
    return rows

def settings_view(selected_file=None):
    with LOCK:
        paths=global_paths();target=next((p for p in paths if file_id(p)==selected_file),paths[-1] if selected_file is None else None)
        if target is None:raise SettingsError('설정 파일 선택을 확인하세요.')
        value,raw=read_config(target);config,origins=effective_config();ui=ui_settings()
        current=ui.get('model') or config.get('model') or ''
        return dict(files=[dict(id=file_id(p),path=str(p),exists=p.exists()) for p in paths],fileId=file_id(target),path=str(target),revision=revision(raw),providers=redact(value.get('provider',{})),fileModel=value.get('model',''),models=models_from(config,origins),currentModel=current,kiloExecutable=ui.get('kiloExecutable') or load_config()['kiloExecutable'],warnings=['프로젝트 설정이나 KILO_CONFIG_CONTENT가 전역 설정을 덮어쓸 수 있습니다. 목록의 origin을 확인하세요.','JSONC 편집 시 변경하는 provider/model 항목 내부의 주석은 정규화되며, 다른 최상위 항목과 원본 백업은 보존합니다.'])

def validate_provider(pid,value):
    if not isinstance(pid,str) or not re.fullmatch(r'[A-Za-z0-9_.-]+',pid):raise SettingsError('Provider ID는 영문·숫자·점·밑줄·하이픈으로 입력하세요.')
    if not isinstance(value,dict):raise SettingsError('Provider 설정은 JSON 객체여야 합니다.')
    if not isinstance(value.get('models'),dict) or not value['models']:raise SettingsError('하나 이상의 models 항목이 필요합니다.')
    for mid,model in value['models'].items():
        if not mid.strip() or not isinstance(model,dict):raise SettingsError('모델 ID와 객체 형식 설정이 필요합니다.')
        for flag in ('tool_call','reasoning'):
            if flag in model and not isinstance(model[flag],bool):raise SettingsError(flag+'은 true 또는 false여야 합니다.')
    base=(value.get('options') or {}).get('baseURL')
    if base and not isinstance(base,str):raise SettingsError('baseURL은 문자열이어야 합니다.')

def update_settings(args):
    with LOCK:
        action=args.get('action');paths=global_paths();target=next((p for p in paths if file_id(p)==args.get('fileId')),None)
        if target is None:raise SettingsError('목록에서 전역 설정 파일을 선택하세요.')
        value,raw=read_config(target)
        if args.get('revision')!=revision(raw):raise SettingsConflict('설정 파일이 변경됐습니다. 목록을 새로고침하세요.')
        if action in ('save_provider','delete_provider'):
            providers=copy.deepcopy(value.get('provider',{}));pid=args.get('providerId')
            if action=='save_provider':
                provider=args.get('provider');validate_provider(pid,provider);providers[pid]=restore(provider,providers.get(pid))
            else:
                if pid not in providers:raise SettingsError('선택된 파일에 해당 provider가 없습니다.')
                del providers[pid]
            write_top(target,'provider',providers,args['revision'])
        elif action=='select_model':
            model=args.get('model');config,origins=effective_config()
            row=next((r for r in models_from(config,origins) if r['id']==model),None)
            if not row or row['disabled']:raise SettingsError('사용 가능한 등록 모델을 선택하세요.')
            write_top(target,'model',model,args['revision'])
            ui=ui_settings();ui['model']=model;atomic_write(UI_PATH,json.dumps(ui,ensure_ascii=False,indent=2)+'\n')
        elif action=='runtime':
            exe=args.get('kiloExecutable','').strip()
            if not exe:raise SettingsError('Kilo 실행 파일 경로 또는 명령을 입력하세요.')
            ui=ui_settings();ui['kiloExecutable']=exe;atomic_write(UI_PATH,json.dumps(ui,ensure_ascii=False,indent=2)+'\n')
        else:raise SettingsError('알 수 없는 설정 작업입니다.')
        return settings_view(file_id(target))

def job_runtime(model_override=None):
    with LOCK:
        config,origins=effective_config();ui=ui_settings();model=model_override or ui.get('model') or config.get('model')
        if not model:raise SettingsError('Kilo 설정 화면에서 분석 모델을 선택하세요.')
        row=next((r for r in models_from(config,origins) if r['id']==model),None)
        if not row or row['disabled']:raise SettingsError('선택 모델이 삭제되었거나 비활성화되었습니다. Kilo 설정에서 다시 선택하세요.')
        return dict(model=model,kiloExecutable=ui.get('kiloExecutable') or load_config()['kiloExecutable'])

class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args):return None

def fetch_models(provider_id):
    config,_=effective_config();provider=config.get('provider',{}).get(provider_id)
    if not provider:raise SettingsError('등록된 provider를 선택하세요.')
    options=provider.get('options') or {};base=options.get('baseURL','');parsed=urlsplit(base)
    if parsed.scheme not in ('http','https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:raise SettingsError('유효한 OpenAI 호환 baseURL이 필요합니다.')
    def resolve_env(value):
        if isinstance(value,str) and re.fullmatch(r'\{env:[A-Za-z_][A-Za-z0-9_]*\}',value):return os.getenv(value[5:-1],'')
        if isinstance(value,str) and value.startswith('{file:'):raise SettingsError('서버 모델 조회에서 {file:...} 비밀값 참조는 지원하지 않습니다.')
        return value
    key=resolve_env(options.get('apiKey',''));headers={'Accept':'application/json'}
    if key:headers['Authorization']='Bearer '+str(key)
    for k,v in (options.get('headers') or {}).items():headers[k]=str(resolve_env(v))
    request=Request(base.rstrip('/')+'/models',headers=headers)
    try:
        with build_opener(_NoRedirect()).open(request,timeout=15) as response:body=json.load(response)
    except HTTPError as err:raise SettingsError(f'모델 목록 API HTTP {err.code}. 이 provider가 /models를 제공하는지 확인하세요.') from err
    except (URLError,OSError,ValueError):raise SettingsError('모델 목록 조회 실패. 주소·인증·JSON 응답을 확인하세요.')
    data=body.get('data') if isinstance(body,dict) else None
    if not isinstance(data,list):raise SettingsError('/models 응답에 data 배열이 없습니다.')
    return dict(providerId=provider_id,models=[dict(id=r['id'],name=r.get('name') or r['id']) for r in data if isinstance(r,dict) and isinstance(r.get('id'),str)])
