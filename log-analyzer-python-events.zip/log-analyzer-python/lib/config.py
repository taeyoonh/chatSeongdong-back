import json
import os
from functools import lru_cache
from pathlib import Path
from .paths import APP_ROOT
DEFAULTS = dict(host='127.0.0.1', port=3000, model='qwen38/Qwen3.8-27B', agent='log-analyst', localKnowledgePath='knowledge/reference.txt', maxUploadBytes=1073741824, maxExpandedBytes=2147483648, maxZipEntries=10000)
def find_kilo_exe():
    if os.getenv('KILO_EXE'):
        return os.environ['KILO_EXE']
    root = Path(os.getenv('USERPROFILE', str(Path.home()))) / '.vscode/extensions'
    import re
    def version(p):
        return tuple(int(v) for v in re.findall(r'\d+', p.parent.parent.name))
    candidates = sorted(root.glob('kilocode.kilo-code-*/bin/kilo.exe'), key=version, reverse=True)
    return str(candidates[0]) if candidates else 'kilo'
@lru_cache(maxsize=1)
def load_config():
    values = {}
    for name in ('local-config.json', 'local-config.example.json'):
        file = APP_ROOT / 'config' / name
        if file.exists():
            # Invalid configuration is an actionable startup error, never silently ignored.
            values = json.loads(file.read_text(encoding='utf-8-sig'))
            break
    cfg = {**DEFAULTS, **values}
    cfg['kiloExecutable'] = values.get('kiloExecutable') or find_kilo_exe()
    for key in ('port', 'maxUploadBytes', 'maxExpandedBytes', 'maxZipEntries'):
        if not isinstance(cfg[key], int) or isinstance(cfg[key], bool) or cfg[key] <= 0:
            raise ValueError(f'{key}: 양의 정수가 필요합니다.')
    return cfg
