import sqlite3
import threading
from contextlib import contextmanager
from .paths import DB_PATH, ensure_dirs
_local = threading.local()
def get_db():
    if getattr(_local, 'db', None) is None:
        ensure_dirs()
        db = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA busy_timeout=10000')
        db.execute('PRAGMA foreign_keys=ON')
        migrate(db)
        _local.db = db
    return _local.db

def migrate(db):
    db.executescript('''
CREATE TABLE IF NOT EXISTS jobs(
 id TEXT PRIMARY KEY, filename TEXT, project TEXT, test TEXT, protocol TEXT,
 status TEXT NOT NULL DEFAULT 'queued', error TEXT, policy TEXT,
 created_at INTEGER, updated_at INTEGER, result_json TEXT, report_json TEXT,
 verification_json TEXT, finalized_at INTEGER);
CREATE TABLE IF NOT EXISTS file_meta(
 upload_id TEXT NOT NULL, name TEXT NOT NULL, row_count INTEGER NOT NULL DEFAULT 0,
 first_ms INTEGER, last_ms INTEGER, first_time TEXT, last_time TEXT,
 header_order TEXT NOT NULL DEFAULT '[]', PRIMARY KEY(upload_id,name));
''')
    cols = {r['name'] for r in db.execute('PRAGMA table_info(jobs)')}
    if 'finalized_at' not in cols:
        db.execute('ALTER TABLE jobs ADD COLUMN finalized_at INTEGER')
    if 'knowledge_source' not in cols:
        db.execute("ALTER TABLE jobs ADD COLUMN knowledge_source TEXT NOT NULL DEFAULT 'rag'")
    if 'knowledge_path' not in cols:
        db.execute("ALTER TABLE jobs ADD COLUMN knowledge_path TEXT")
    for column in ('selected_model','kilo_executable'):
        if column not in cols: db.execute(f'ALTER TABLE jobs ADD COLUMN {column} TEXT')
    if 'dataset_warnings_json' not in cols:db.execute('ALTER TABLE jobs ADD COLUMN dataset_warnings_json TEXT')
    if 'dataset_ready_at' not in cols:db.execute('ALTER TABLE jobs ADD COLUMN dataset_ready_at INTEGER')
    exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='messages'").fetchone()
    legacy = exists and 'id' not in {r['name'] for r in db.execute('PRAGMA table_info(messages)')}
    if legacy:
        # Legacy v1 has no event/finding links. Roll back the complete rebuild on failure.
        db.execute('BEGIN IMMEDIATE')
        db.execute('ALTER TABLE messages RENAME TO messages_v1')
    try:
        db.execute('''CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY, upload_id TEXT NOT NULL, line_no INTEGER NOT NULL,
 ts_ms INTEGER, source_file TEXT NOT NULL, data_json TEXT NOT NULL)''')
        if legacy:
            db.execute('INSERT INTO messages SELECT rowid,upload_id,line_no,ts_ms,source_file,data_json FROM messages_v1')
            db.execute('DROP TABLE messages_v1')
            db.execute('COMMIT')
    except Exception:
        if legacy: db.execute('ROLLBACK')
        raise
    db.executescript('''
CREATE INDEX IF NOT EXISTS idx_messages_order ON messages(upload_id,ts_ms IS NULL,ts_ms,source_file,line_no);
CREATE INDEX IF NOT EXISTS idx_messages_file ON messages(upload_id,source_file,line_no);
CREATE INDEX IF NOT EXISTS idx_messages_seek ON messages(upload_id,ts_ms,source_file,line_no,id);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY, upload_id TEXT NOT NULL, client_id TEXT NOT NULL,
 parent_id INTEGER REFERENCES events(id) ON DELETE CASCADE,
 category TEXT NOT NULL, action TEXT NOT NULL, title TEXT NOT NULL,
 subject_json TEXT NOT NULL DEFAULT 'null', start_ms INTEGER, end_ms INTEGER,
 description TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'undetermined',
 severity TEXT, created_at INTEGER NOT NULL, UNIQUE(upload_id,client_id));
CREATE INDEX IF NOT EXISTS idx_events_upload ON events(upload_id,start_ms IS NULL,start_ms);
CREATE TABLE IF NOT EXISTS event_messages(
 event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
 message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 PRIMARY KEY(event_id,message_id));
CREATE INDEX IF NOT EXISTS idx_event_messages_msg ON event_messages(message_id);
CREATE TABLE IF NOT EXISTS findings(
 id INTEGER PRIMARY KEY, upload_id TEXT NOT NULL, client_id TEXT NOT NULL,
 event_id INTEGER REFERENCES events(id) ON DELETE SET NULL,
 kind TEXT NOT NULL DEFAULT 'anomaly', title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '', verdict TEXT NOT NULL DEFAULT 'anomaly',
 severity TEXT, start_ms INTEGER, end_ms INTEGER,
 reference_json TEXT NOT NULL DEFAULT '[]', created_at INTEGER NOT NULL,
 UNIQUE(upload_id,client_id));
CREATE INDEX IF NOT EXISTS idx_findings_upload ON findings(upload_id,start_ms IS NULL,start_ms);
CREATE TABLE IF NOT EXISTS finding_messages(
 finding_id INTEGER NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
 message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 PRIMARY KEY(finding_id,message_id));
CREATE INDEX IF NOT EXISTS idx_finding_messages_msg ON finding_messages(message_id);
CREATE TABLE IF NOT EXISTS analysis_batches(
 id TEXT PRIMARY KEY, upload_id TEXT NOT NULL, start_offset INTEGER NOT NULL,
 row_count INTEGER NOT NULL, ids_json TEXT NOT NULL, carry_state TEXT,
 completed_at INTEGER, UNIQUE(upload_id,start_offset));
CREATE TABLE IF NOT EXISTS event_rag_evidence(
 id TEXT PRIMARY KEY, upload_id TEXT NOT NULL, batch_id TEXT NOT NULL,
 client_id TEXT NOT NULL, query TEXT NOT NULL, response_json TEXT NOT NULL,
 error TEXT, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_batches_pending ON analysis_batches(upload_id) WHERE completed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_batches_completed ON analysis_batches(upload_id,start_offset DESC) WHERE completed_at IS NOT NULL;
CREATE TABLE IF NOT EXISTS analysis_item_audit(
 upload_id TEXT NOT NULL, kind TEXT NOT NULL, client_id TEXT NOT NULL,
 batch_id TEXT NOT NULL, evidence_id TEXT NOT NULL, quote TEXT NOT NULL,
 PRIMARY KEY(upload_id,kind,client_id));

CREATE TABLE IF NOT EXISTS metric_results(
 id TEXT PRIMARY KEY, upload_id TEXT NOT NULL, batch_id TEXT NOT NULL,
 event_client_id TEXT NOT NULL,
 arguments_json TEXT NOT NULL, scope_json TEXT NOT NULL, result_json TEXT NOT NULL,
 created_at INTEGER NOT NULL, superseded_at INTEGER, superseded_reason TEXT);
CREATE INDEX IF NOT EXISTS idx_metric_results_batch ON metric_results(upload_id,batch_id);
CREATE TABLE IF NOT EXISTS event_drafts(
 upload_id TEXT NOT NULL, client_id TEXT NOT NULL, revision INTEGER NOT NULL,
 data_json TEXT NOT NULL, ids_json TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'draft',
 updated_at INTEGER NOT NULL, confirmed_at INTEGER,
 PRIMARY KEY(upload_id,client_id));
CREATE TABLE IF NOT EXISTS event_validations(
 id TEXT PRIMARY KEY, upload_id TEXT NOT NULL, client_id TEXT NOT NULL,
 revision INTEGER NOT NULL, review_type TEXT NOT NULL, query TEXT NOT NULL,
 response_json TEXT NOT NULL, review_json TEXT, passed INTEGER,
 created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_event_validations_revision ON event_validations(upload_id,client_id,revision,created_at);
CREATE TABLE IF NOT EXISTS event_label_evidence(
 id TEXT PRIMARY KEY, upload_id TEXT NOT NULL, client_id TEXT NOT NULL,
 base_revision INTEGER NOT NULL, scope_json TEXT NOT NULL, query TEXT NOT NULL,
 response_json TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_label_evidence_event ON event_label_evidence(upload_id,client_id);

''')
    for table, additions in {
        'metric_results': {'event_client_id': "TEXT NOT NULL DEFAULT ''", 'superseded_at': 'INTEGER', 'superseded_reason': 'TEXT'},
        'analysis_item_audit': {'review_id': 'TEXT', 'assessment_json': 'TEXT'},
    }.items():
        present = {r['name'] for r in db.execute(f'PRAGMA table_info({table})')}
        for column, definition in additions.items():
            if column not in present:
                db.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')
@contextmanager
def transaction(db=None):
    db = db or get_db()
    db.execute('BEGIN IMMEDIATE')
    try:
        yield db
        db.execute('COMMIT')
    except BaseException:
        db.execute('ROLLBACK')
        raise
def close_db():
    db = getattr(_local, 'db', None)
    if db is not None:
        db.close()
        _local.db = None
