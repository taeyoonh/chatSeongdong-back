import csv
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from zipfile import ZipFile
from lib import db
from lib.jobs import create_job
from mcp_server.dataset import prepare_dataset
from mcp_server.ordered import ORDER, rows_after
from mcp_server.master import export_master_csv
from mcp_server.index import create_server

class OrderedMasterTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.patches=[patch.object(db,'DB_PATH',self.root/'app.db'),patch('mcp_server.dataset.UPLOADS_DIR',self.root/'uploads'),patch('mcp_server.dataset.RESULTS_DIR',self.root/'results'),patch('mcp_server.workflow.RESULTS_DIR',self.root/'results')]
        for p in self.patches:p.start()
        db.close_db(); create_job(id='job',filename='test.zip',project='P',test='T',protocol='Link-16')
        self.upload=self.root/'uploads/job';self.upload.mkdir(parents=True)
    def tearDown(self):
        db.close_db()
        for p in reversed(self.patches):p.stop()
        self.temp.cleanup()
    def zip(self):
        with ZipFile(self.upload/'upload.zip','w') as z:
            z.writestr('b.csv','Time1,Time2,B,_MessageId\n2026-10-20 10:00:02,123,b,original\n2026-10-20 10:00:00,999,c,keep\n')
            z.writestr('a.csv','Time1,Time2,A\n2026-10-20 10:00:01,1,a\nnot-time,,unknown\n')
    def test_master_sorted_union_collision_and_reuse(self):
        self.zip(); result=prepare_dataset('job');path=self.root/'results/job/master.csv'
        self.assertEqual(result['master']['rows'],4)
        with path.open(encoding='utf-8-sig',newline='') as stream:
            reader=csv.DictReader(stream);rows=list(reader);headers=reader.fieldnames
        self.assertIn('A',headers);self.assertIn('B',headers)
        self.assertEqual(rows[0]['_MessageId'],'keep')
        self.assertIn('_MessageId__2',headers)
        expected=list(db.get_db().execute('SELECT * FROM messages WHERE upload_id=? ORDER BY '+ORDER,('job',)))
        self.assertEqual([int(r['_MessageId__2']) for r in rows],[r['id'] for r in expected])
        self.assertEqual(rows[-1]['A'],'unknown');self.assertEqual(rows[-1]['_TimeMs'],'')
        self.assertEqual(int(rows[0]['_TimeMs'])%1000,999)
        ids=[r['id'] for r in expected];db.get_db().execute('INSERT INTO events(upload_id,client_id,category,action,title,created_at) VALUES(?,?,?,?,?,?)',('job','E','track','observed','saved',1))
        reused=prepare_dataset('job');self.assertTrue(reused['reused'])
        self.assertEqual([r['id'] for r in db.get_db().execute('SELECT * FROM messages ORDER BY '+ORDER)],ids)
        self.assertEqual(db.get_db().execute('SELECT COUNT(*) FROM events').fetchone()[0],1)
        path.unlink();self.assertTrue(prepare_dataset('job')['reused']);self.assertTrue(path.is_file())
    def test_export_failure_prevents_ready_state(self):
        self.zip()
        with patch('mcp_server.master.export_master_csv',side_effect=OSError('disk full')):
            with self.assertRaisesRegex(Exception,'disk full'):prepare_dataset('job')
        row=db.get_db().execute('SELECT status,dataset_ready_at FROM jobs').fetchone()
        self.assertEqual(row['status'],'failed');self.assertIsNone(row['dataset_ready_at'])
        self.assertEqual(db.get_db().execute('SELECT COUNT(*) FROM messages').fetchone()[0],0)
    def seed(self,unknown=False):
        d=db.get_db()
        d.executemany('INSERT INTO messages(upload_id,line_no,ts_ms,source_file,data_json) VALUES(?,?,?,?,?)',
            (('job',i//3,None if unknown or i>450 else i//4,'a.csv' if i%2 else 'b.csv',json.dumps({'N':i})) for i in reversed(range(1003))))
    def test_seek_equal_keys_null_boundary_and_no_offset(self):
        self.seed();expected=[r['id'] for r in db.get_db().execute('SELECT * FROM messages ORDER BY '+ORDER)]
        statements=[];db.get_db().set_trace_callback(statements.append)
        found=[];last=None
        while True:
            rows=rows_after('job',last,200)
            if not rows:break
            found.extend(r['id'] for r in rows);last=rows[-1]
        db.get_db().set_trace_callback(None)
        self.assertEqual(found,expected);self.assertEqual(len(set(found)),1003)
        self.assertTrue(all('OFFSET' not in sql.upper() for sql in statements))
        # Confirm SQLite performs a range search using the seek index.
        plan=db.get_db().execute('EXPLAIN QUERY PLAN SELECT * FROM messages WHERE upload_id=? AND ts_ms IS NOT NULL AND (ts_ms,source_file,line_no,id)>(?,?,?,?) ORDER BY ts_ms,source_file,line_no,id LIMIT ?',('job',10,'a.csv',1,1,200)).fetchall()
        detail=' '.join(r['detail'] for r in plan)
        self.assertIn('SEARCH',detail);self.assertIn('idx_messages_seek',detail);self.assertNotIn('TEMP B-TREE',detail)
    def test_all_unknown_timestamps_seek(self):
        self.seed(unknown=True);last=None;found=[]
        while True:
            rows=rows_after('job',last,200)
            if not rows:break
            found.extend(r['id'] for r in rows);last=rows[-1]
        expected=[r['id'] for r in db.get_db().execute('SELECT * FROM messages ORDER BY '+ORDER)]
        self.assertEqual(found,expected)
    def test_mcp_has_no_access_token_parameter(self):
        for name,(_,schema,_) in create_server().tools.items():
            self.assertNotIn('accessToken',schema['properties'],name)
        self.assertNotIn('token',[r['name'] for r in db.get_db().execute('PRAGMA table_info(jobs)')])
    def test_backend_prepares_master_before_kilo(self):
        import threading,time
        from backend import index
        self.zip();logs=self.root/'logs';logs.mkdir();invoked=threading.Event();seen=[]
        class Runner:
            stopped=False
            def run(runner):
                seen.append((self.root/'results/job/master.csv').is_file())
                invoked.set()
                return dict(ok=False,error='fake Kilo finished')
        with patch.object(index,'LOGS_DIR',logs),patch.object(index,'run_kilo_job',return_value=Runner()):
            self.assertTrue(index.start_analysis('job'))
            self.assertTrue(invoked.wait(5))
            for _ in range(200):
                with index.active_lock:running='job' in index.active_jobs
                if not running:break
                time.sleep(.01)
            self.assertFalse(running)
        self.assertEqual(seen,[True])
    def test_prepare_reuses_legacy_batch_and_cursor_state(self):
        self.zip();prepare_dataset('job');server=create_server()
        def call(name,args=None):
            response=server.call_tool({'name':name,'arguments':{'uploadId':'job',**(args or {})}})
            self.assertFalse(response.get('isError'),response)
            return json.loads(response['content'][0]['text'])
        batch=call('next_analysis_batch');db.get_db().execute('UPDATE jobs SET dataset_ready_at=NULL')
        reused=prepare_dataset('job');self.assertTrue(reused['reused'])
        self.assertEqual(call('next_analysis_batch')['batchId'],batch['batchId'])
        self.assertEqual(call('get_job_status')['activeBatch']['id'],batch['batchId'])

if __name__=='__main__':unittest.main()
