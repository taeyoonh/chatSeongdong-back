"""Exercise exposed tools, real HTTP RAG payloads, revision gates and Excel."""
import json
import tempfile
import threading
import unittest
import xml.etree.ElementTree as ET
from zipfile import ZipFile
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch
from lib import db
from lib.jobs import create_job
from mcp_server.index import create_server
from mcp_server.rag_client import RagClient, Settings, RagError

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.patches=[patch.object(db,'DB_PATH',self.root/'app.db'),patch('mcp_server.workflow.RESULTS_DIR',self.root/'results'),patch('mcp_server.report.RESULTS_DIR',self.root/'results')]
        for p in self.patches:p.start()
        db.close_db();create_job(id='job',filename='a.zip',project='P',test='T',protocol='Link-16')
        self.args=dict(uploadId='job');self.server=create_server();database=db.get_db()
        for i in reversed(range(405)):
            database.execute('INSERT INTO messages(upload_id,line_no,ts_ms,source_file,data_json) VALUES(?,?,?,?,?)',('job',i,None if i==404 else i//2,'a.csv' if i%2 else 'b.csv',json.dumps({'TN':str(i),'State':'A' if i<100 else 'B'})))
        for source in ('a.csv','b.csv'):
            stats=database.execute('SELECT COUNT(*),MIN(ts_ms),MAX(ts_ms) FROM messages WHERE source_file=?',(source,)).fetchone()
            from lib.time import ms_to_display
            database.execute('INSERT INTO file_meta(upload_id,name,row_count,first_ms,last_ms,first_time,last_time,header_order) VALUES(?,?,?,?,?,?,?,?)',('job',source,*stats,ms_to_display(stats[1]),ms_to_display(stats[2]),'["TN","State"]'))
        self.calls=[];calls=self.calls
        class RAG(BaseHTTPRequestHandler):
            def do_POST(self):
                calls.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
                raw=json.dumps({'chunks':[{'content':'Track report describes observed target state. Interval is checked against applicable operating conditions.','document_name':'ICD','section':'3'}]}).encode()
                self.send_response(200);self.end_headers();self.wfile.write(raw)
            def log_message(self,*args):pass
        self.http=ThreadingHTTPServer(('127.0.0.1',0),RAG);self.thread=threading.Thread(target=self.http.serve_forever,daemon=True);self.thread.start()
        client=RagClient(Settings(rag_server_url=f'http://127.0.0.1:{self.http.server_port}'))
        self.ragpatch=patch('mcp_server.event_workflow.RagClient',return_value=client);self.ragpatch.start()
    def tearDown(self):
        self.ragpatch.stop();self.http.shutdown();self.http.server_close();self.thread.join();db.close_db()
        for p in reversed(self.patches):p.stop()
        self.temp.cleanup()
    def call(self,name,extra=None,error=False):
        result=self.server.call_tool({'name':name,'arguments':self.args|dict(extra or {})})
        self.assertEqual(bool(result.get('isError')),error,result)
        return json.loads(result['content'][0]['text'])
    def event(self,batch,cid='E',**extra):
        ids=[r['id'] for r in batch['rows']]
        return dict(clientId=cid,category='track',action='observed',title='관측',status='undetermined' if any(r['tsMs'] is None for r in batch['rows']) else 'normal',description='표적 관측 보고의 주체와 메시지 관계를 확인함',messageLinks={'messageIds':ids},
                    messageRoles=[dict(messageId=i,role='표적 상태 보고') for i in ids],relations=[dict(fromMessageId=a,toMessageId=b,relation='동일 관찰 구간의 후속 보고') for a,b in zip(ids,ids[1:])])|extra
    def label_prepare(self,event):
        return self.call('label_event',dict(action='prepare',clientId=event['clientId'],messageLinks=event['messageLinks']))
    def draft(self,event):
        p=self.label_prepare(event)
        return self.call('label_event',dict(action='submit',event=event,labelEvidenceId=p['labelEvidenceId'],evidenceQuote='describes observed target state',rationale='검색한 규격의 메시지 정의와 실제 보고 관계를 대조하여 라벨링함'))
    def prepare(self,cid,kind):return self.call('validate_event',dict(clientId=cid,action='prepare',reviewType=kind))
    def checks(self,prepared,event,verdict='pass'):
        checks=[dict(code=code,verdict=verdict,observed='실제 로그의 관측값',expected='규격의 적용 조건',comparison='해당 주체와 상태에서 실제 메시지 및 경계를 원문과 대조함',applicability='동일 메시지 종류와 운용 조건',quote='describes observed target state' if verdict!='undetermined' else '',messageIds=event['messageLinks']['messageIds']) for code in prepared['requiredChecks']]
        for check in checks:
            if check['code'].startswith('finding:'):
                check['messageIds']=next(f['messageLinks']['messageIds'] for f in event['findings'] if 'finding:'+f['clientId']==check['code'])
        return checks
    def submit(self,prepared,event,checks=None,error=False):
        return self.call('validate_event',dict(clientId=event['clientId'],action='submit',validationId=prepared['validationId'],checks=checks or self.checks(prepared,event)),error)
    def review(self,event,verdict='pass'):
        for kind in ('meaning','boundary'):
            p=self.prepare(event['clientId'],kind);self.submit(p,event,self.checks(p,event,verdict))
    def confirm(self,cid='E',error=False):return self.call('confirm_event',dict(clientId=cid),error)
    def test_order_coverage_resume_and_full_report(self):
        seen=[]
        for index,count in enumerate((200,200,5)):
            b=self.call('next_analysis_batch');self.assertEqual(len(b['rows']),count)
            self.assertEqual(self.call('next_analysis_batch')['batchId'],b['batchId'])
            self.call('complete_analysis_batch',dict(batchId=b['batchId'],carryState='미처리'),error=True)
            event=self.event(b,f'E{index}');self.draft(event)
            self.assertEqual(db.get_db().execute('SELECT COUNT(*) FROM events').fetchone()[0],index)
            self.review(event);self.confirm(event['clientId']);seen.extend(b['rows'])
            db.close_db();self.assertEqual(self.call('next_analysis_batch')['batchId'],b['batchId'])
            self.call('complete_analysis_batch',dict(batchId=b['batchId'],carryState=f'구간 {index} 완료'))
        self.assertTrue(self.call('next_analysis_batch')['done']);self.assertEqual(len({r['id'] for r in seen}),405)
        keys=[(r['tsMs'] is None,r['tsMs'] or 0,r['source'],r['line'],r['id']) for r in seen];self.assertEqual(keys,sorted(keys))
        self.assertEqual(len(self.calls),9);self.assertIn('messages',self.calls[0]['question']);self.assertIn('State',self.calls[0]['question'])
        self.call('finalize_analysis');result=self.call('build_report',dict(agentSummary='전 구간을 관찰했고 시각 불명 메시지는 보류했습니다.'))
        self.assertEqual(result['excel']['sheets']['Messages'],405)
        verified=self.call('verify_report');self.assertTrue(verified['verified'],verified)
        path=self.root/'results/job/final.xlsx'
        with ZipFile(path) as z:
            for name in z.namelist():
                if name.endswith('.xml') or name.endswith('.rels'):ET.fromstring(z.read(name))
            ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            ws=ET.fromstring(z.read('xl/worksheets/sheet2.xml'));self.assertEqual(len(ws.findall('.//s:row',ns)),406)
            text=z.read('xl/worksheets/sheet1.xml').decode();self.assertIn('표적 관측 보고',text);self.assertIn('describes observed target state',text);self.assertIn('ICD',text)
        snapshot=json.loads((self.root/'results/job/analysis-checkpoint.json').read_text());self.assertEqual(len(snapshot['event_validations']),6);self.assertEqual(len(snapshot['event_label_evidence']),3)
        with path.open('ab') as f:f.write(b'tamper')
        self.assertFalse(self.call('verify_report')['verified'])
    def test_two_reviews_revision_and_latest_attempt_are_required(self):
        b=self.call('next_analysis_batch');e=self.event(b);self.draft(e);self.confirm(error=True)
        p=self.prepare('E','meaning');self.submit(p,e);self.confirm(error=True)
        q=self.prepare('E','boundary');self.draft(e);self.submit(q,e,error=True);self.confirm(error=True)
        self.review(e)
        latest=self.prepare('E','boundary');self.confirm(error=True)
        failed=self.checks(latest,e);failed[0]['verdict']='fail';self.submit(latest,e,failed);self.confirm(error=True)
        self.draft(e);self.review(e);self.confirm();self.call('label_event',dict(event=e),error=True)
    def test_missing_forged_quote_scope_roles_and_future_rows_blocked(self):
        b=self.call('next_analysis_batch');e=self.event(b)
        p=self.label_prepare(e)
        submission=dict(action='submit',labelEvidenceId=p['labelEvidenceId'],evidenceQuote='describes observed target state',rationale='규격 관계 대조')
        bad=dict(e,messageRoles=e['messageRoles'][:-1]);self.call('label_event',submission|dict(event=bad),error=True)
        bad=dict(e,relations=[]);self.call('label_event',submission|dict(event=bad),error=True)
        future=self.event(dict(rows=b['contextAfter']),'future');self.call('label_event',dict(event=future),error=True)
        self.draft(e);p=self.prepare('E','meaning');checks=self.checks(p,e);checks[0]['quote']='fabricated';self.submit(p,e,checks,error=True)
        checks=self.checks(p,e);checks[0]['messageIds']=[b['contextAfter'][0]['id']];self.submit(p,e,checks,error=True)
        self.call('save_analysis',dict(events=[e]),error=True)
        self.call('query_messages',dict(eventClientId='missing'),error=True)
        self.call('next_analysis_batch',dict(uploadId='missing'),error=True)
    def test_remote_failure_or_empty_results_only_allows_undetermined(self):
        b=self.call('next_analysis_batch');e=self.event(b);self.draft(e)
        with patch('mcp_server.event_workflow.RagClient') as factory:
            factory.return_value.search.side_effect=RagError('HTTP 401')
            for kind in ('meaning','boundary'):
                p=self.prepare('E',kind);self.submit(p,e,self.checks(p,e),error=True);self.submit(p,e,self.checks(p,e,'undetermined'))
        self.confirm(error=True);e['status']='undetermined';self.draft(e)
        with patch('mcp_server.event_workflow.RagClient') as factory:
            factory.return_value.search.return_value=dict(ok=True,results=[])
            self.review(e,'undetermined')
        self.confirm();self.assertEqual(db.get_db().execute('SELECT status FROM events').fetchone()[0],'undetermined')
    def test_saved_metrics_are_bound_to_event_and_rag_and_cannot_be_forged(self):
        b=self.call('next_analysis_batch');e=self.event(b);self.draft(e)
        old=self.prepare('E','meaning')
        metric=self.call('calculate_metrics',dict(eventClientId='E',operation='intervals'))
        self.submit(old,e,error=True)
        self.assertEqual(metric['selection']['rowCount'],200)
        raw=json.loads(db.get_db().execute('SELECT result_json FROM metric_results WHERE id=?',(metric['metricId'],)).fetchone()[0])
        self.assertEqual(raw['rows'],metric['rows'])
        p=self.prepare('E','meaning');self.assertIn('metric:'+metric['metricId'],p['requiredChecks']);self.assertIn(metric['metricId'],self.calls[-1]['question']);self.assertIn('maxGapMs',self.calls[-1]['question'])
        checks=self.checks(p,e);self.submit(p,e,checks[:-1],error=True)
        for c in checks:
            if c['code'].startswith('metric:'):c['observed']='AI invented value 999999'
        submitted=self.submit(p,e,checks)
        observed=next(c['observed'] for c in submitted['checks'] if c['code'].startswith('metric:'))
        self.assertNotIn('invented',observed);self.assertEqual(json.loads(observed),raw)
        q=self.prepare('E','boundary');self.submit(q,e);self.confirm()
        rows=self.call('query_messages',dict(eventClientId='E',limit=500));self.assertEqual(rows['total'],200);self.assertIn('TN',rows['rows'][0]['fields'])
        self.call('calculate_metrics',dict(eventClientId='E',operation='intervals'),error=True)
    def test_read_window_is_not_an_event_boundary(self):
        first=self.call('next_analysis_batch');e=self.event(first);self.draft(e)
        self.call('complete_analysis_batch',dict(batchId=first['batchId'],carryState='E 코릴레이션 진행 중'))
        second=self.call('next_analysis_batch');combined=dict(rows=first['rows']+second['rows']);e=self.event(combined)
        e['title']='코릴레이션 시작부터 종료';self.draft(e)
        self.call('complete_analysis_batch',dict(batchId=second['batchId'],carryState='E 종료 확인'))
        self.assertEqual(len(self.call('label_event',dict(clientId='E'))['event']['messageRoles']),400)
        self.review(e);self.confirm();self.assertEqual(db.get_db().execute('SELECT COUNT(*) FROM event_messages').fetchone()[0],400)
    def test_finding_checks_and_actual_references(self):
        b=self.call('next_analysis_batch');e=self.event(b)
        e['findings']=[dict(clientId='FN1',title='재확인',description='관측 근거 대조',analysisType='relationship',verdict='undetermined',messageLinks={'messageIds':[b['rows'][0]['id']]})]
        self.draft(e);p=self.prepare('E','meaning');self.assertIn('finding:FN1',p['requiredChecks']);self.submit(p,e)
        q=self.prepare('E','boundary');self.submit(q,e);self.confirm()
        refs=json.loads(db.get_db().execute('SELECT reference_json FROM findings').fetchone()[0]);self.assertTrue(all(r['document']=='ICD' for r in refs))

    def test_incomplete_metrics_cannot_pass_and_scope_change_retains_audit(self):
        b=self.call('next_analysis_batch');e=self.event(b);self.draft(e)
        metric=self.call('calculate_metrics',dict(eventClientId='E',operation='first_last',groupBy=['TN'],limit=1))
        self.assertTrue(metric['selection']['incomplete'])
        p=self.prepare('E','meaning');self.submit(p,e,error=True)
        smaller=self.event(dict(rows=b['rows'][:2]));self.draft(smaller)
        row=db.get_db().execute('SELECT * FROM metric_results WHERE id=?',(metric['metricId'],)).fetchone()
        self.assertIsNotNone(row['superseded_at']);self.assertIn('scope changed',row['superseded_reason'])
        self.assertEqual(len(json.loads(row['scope_json'])),200)
        self.assertEqual(self.call('label_event',dict(clientId='E'))['event']['metricIds'],[])

    def test_complete_reading_does_not_bypass_confirmation(self):
        for n in range(3):
            b=self.call('next_analysis_batch');self.draft(self.event(b,f'E{n}'))
            self.call('complete_analysis_batch',dict(batchId=b['batchId'],carryState='초안만 작성'))
        self.assertTrue(self.call('next_analysis_batch')['done'])
        self.call('finalize_analysis',error=True);self.call('build_report',error=True)
        self.assertFalse((self.root/'results/job/final.xlsx').exists())

    def test_numeric_finding_requires_real_saved_metric(self):
        b=self.call('next_analysis_batch');e=self.event(b,status='anomaly')
        e['findings']=[dict(clientId='FN',title='간격 이상 후보',description='계산 원본과 규격 기준 대조',verdict='anomaly',analysisType='metric',messageLinks=e['messageLinks'])]
        self.draft(e);self.call('validate_event',dict(clientId='E',action='prepare',reviewType='meaning'),error=True)
        metric=self.call('calculate_metrics',dict(eventClientId='E',operation='intervals'))
        e['findings'][0]['metricIds']=[metric['metricId']];self.draft(e)
        self.review(e);self.confirm()

    def test_label_requires_prior_rag_and_exact_evidence_scope_revision(self):
        b=self.call('next_analysis_batch');e=self.event(b)
        self.call('label_event',dict(event=e),error=True)
        self.call('label_event',dict(action='submit',event=e,labelEvidenceId='forged',rationale='unsupported'),error=True)
        p=self.label_prepare(e)
        self.assertEqual(db.get_db().execute('SELECT COUNT(*) FROM event_drafts').fetchone()[0],0)
        self.assertIn('BEFORE assigning',self.calls[-1]['question'])
        self.assertIn('State',self.calls[-1]['question'])
        args=dict(action='submit',event=e,labelEvidenceId=p['labelEvidenceId'],evidenceQuote='invented quotation',rationale='규격과 실제 로그 대조')
        self.call('label_event',args,error=True)
        args['evidenceQuote']='describes observed target state'
        self.call('label_event',args|dict(event=self.event(dict(rows=b['rows'][:2]))),error=True)
        self.call('label_event',args|dict(event=dict(e,clientId='other')),error=True)
        self.call('label_event',args)
        self.call('label_event',args,error=True)  # Old retrieval cannot label a newer revision.
        saved=self.call('label_event',dict(action='inspect',clientId='E'))['event']
        self.assertEqual(saved['labelGrounding']['labelEvidenceId'],p['labelEvidenceId'])
        self.assertTrue(saved['labelGrounding']['grounded'])
        # A copied grounding object never bypasses the top-level retrieval gate.
        self.call('label_event',dict(action='submit',event=saved,rationale='copied'),error=True)

    def test_label_rag_failure_or_empty_only_allows_undetermined(self):
        b=self.call('next_analysis_batch');e=self.event(b)
        for response in (RagError('HTTP 401'),dict(ok=True,results=[])):
            with patch('mcp_server.event_workflow.RagClient') as factory:
                if isinstance(response,Exception): factory.return_value.search.side_effect=response
                else: factory.return_value.search.return_value=response
                p=self.label_prepare(e)
            args=dict(action='submit',event=e,labelEvidenceId=p['labelEvidenceId'],evidenceQuote='',rationale='근거 검색이 실패하여 의미 판정을 보류함')
            self.call('label_event',args,error=True)
            self.call('label_event',args|dict(event=dict(e,status='undetermined')))
        saved=self.call('label_event',dict(clientId='E'))['event']
        self.assertFalse(saved['labelGrounding']['grounded'])
        self.assertEqual(saved['status'],'undetermined')

    def test_label_prepare_future_rows_and_concurrent_revision_are_rejected(self):
        b=self.call('next_analysis_batch');e=self.event(b);self.draft(e)
        future=self.event(dict(rows=b['contextAfter']),'future')
        self.call('label_event',dict(action='prepare',clientId='future',messageLinks=future['messageLinks']),error=True)
        def change_during_search(**kwargs):
            db.get_db().execute('UPDATE event_drafts SET revision=revision+1 WHERE upload_id=?',('job',))
            return dict(ok=True,results=[])
        with patch('mcp_server.event_workflow.RagClient') as factory:
            factory.return_value.search.side_effect=change_during_search
            self.call('label_event',dict(action='prepare',clientId='E',messageLinks=e['messageLinks']),error=True)

    def test_legacy_unbacked_draft_cannot_be_validated_or_confirmed(self):
        b=self.call('next_analysis_batch');e=self.event(b);self.draft(e)
        db.get_db().execute('DELETE FROM event_label_evidence')
        self.call('validate_event',dict(clientId='E',action='prepare',reviewType='meaning'),error=True)
        self.confirm(error=True)

if __name__=='__main__':unittest.main()
