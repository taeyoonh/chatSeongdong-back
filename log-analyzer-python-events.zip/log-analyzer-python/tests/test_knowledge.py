import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from mcp_server.local_text_client import LocalTextClient
from mcp_server.rag_client import RagError
from mcp_server.knowledge import search_knowledge,check_knowledge,_local_client
from backend.kilo_client import KiloRun

class KnowledgeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name)/'reference.txt'
        self.path.write_text('J3.2 TRACK QUALITY\nTrack Quality denotes confidence in the reported track.\n\nK.0 TN Originator\nTN Originator identifies the originating unit.\n',encoding='utf-8')
        _local_client.cache_clear()
    def tearDown(self):
        _local_client.cache_clear();self.temp.cleanup()
    def test_local_search_and_provenance(self):
        client=LocalTextClient(str(self.path));result=client.search(query='TRACK QUALITY',message_id='J3.2',top_k=1)
        self.assertEqual(result['knowledge_source'],'local_text');self.assertEqual(result['count'],1)
        hit=result['results'][0];self.assertEqual(hit['source'],'reference.txt');self.assertIn('lines 1-',hit['section']);self.assertIn('sha256',hit['metadata']);self.assertIn('confidence',hit['content'])
        self.assertEqual(client.search(query='nonexistentterm')['count'],0)
    def test_off_never_constructs_rag_client(self):
        with patch.dict(os.environ,{'LOG_ANALYZER_KNOWLEDGE_SOURCE':'local_text','LOG_ANALYZER_KNOWLEDGE_PATH':str(self.path)}),patch('mcp_server.knowledge.RagClient') as rag:
            result=search_knowledge({'query':'K.0'});self.assertTrue(result['results']);self.assertEqual(check_knowledge()['knowledge_source'],'local_text');rag.assert_not_called()
    def test_on_routes_only_to_rag(self):
        with patch.dict(os.environ,{'LOG_ANALYZER_KNOWLEDGE_SOURCE':'rag'}),patch('mcp_server.knowledge.RagClient') as rag,patch('mcp_server.knowledge.LocalTextClient') as text:
            rag.return_value.search.return_value={'ok':True,'results':[]}
            self.assertEqual(search_knowledge({'query':'q'})['knowledge_source'],'rag');text.assert_not_called()
    def test_local_missing_empty_wrong_encoding_and_change(self):
        with self.assertRaises(RagError): LocalTextClient(str(self.path.parent/'missing.txt')).health()
        empty=self.path.parent/'empty.txt';empty.write_text('')
        with self.assertRaises(RagError):LocalTextClient(str(empty)).health()
        client=LocalTextClient(str(self.path));client.health();self.path.write_text('changed content')
        with self.assertRaises(RagError):client.search(query='changed')
        cp=self.path.parent/'cp.txt';cp.write_bytes('항적번호 의미'.encode('cp949'));self.assertEqual(LocalTextClient(str(cp)).search(query='항적번호')['count'],1)
    def test_actual_mcp_process_off(self):
        calls=[dict(jsonrpc='2.0',id=1,method='tools/call',params={'name':'search_rag','arguments':{'query':'TRACK QUALITY'}}),dict(jsonrpc='2.0',id=2,method='tools/call',params={'name':'rag_connection_check','arguments':{}})]
        result=subprocess.run([sys.executable,'-m','mcp_server.index'],input='\n'.join(map(json.dumps,calls))+'\n',text=True,capture_output=True,encoding='utf-8',timeout=10,env={**os.environ,'LOG_ANALYZER_KNOWLEDGE_SOURCE':'local_text','LOG_ANALYZER_KNOWLEDGE_PATH':str(self.path)})
        self.assertEqual(result.returncode,0,result.stderr)
        for line in result.stdout.splitlines():
            response=json.loads(line)['result'];self.assertNotIn('isError',response);self.assertEqual(json.loads(response['content'][0]['text'])['knowledge_source'],'local_text')
    def test_job_mode_inherited_by_cli_subprocess(self):
        class Child:
            stdout=[];stderr=[];pid=123
            def wait(self,timeout=None):return 0
        # Use pipes with close() for the reader threads.
        import io
        child=Child();child.stdout=io.StringIO('');child.stderr=io.StringIO('')
        job=dict(id='job',token='token',filename='x',context={},knowledgeSource='local_text',knowledgePath=str(self.path))
        with patch('backend.kilo_client.subprocess.Popen',return_value=child) as spawn:
            self.assertTrue(KiloRun(job).run()['ok'])
            env=spawn.call_args.kwargs['env'];self.assertEqual(env['LOG_ANALYZER_KNOWLEDGE_SOURCE'],'local_text');self.assertEqual(env['LOG_ANALYZER_KNOWLEDGE_PATH'],str(self.path))

if __name__=='__main__':unittest.main()
