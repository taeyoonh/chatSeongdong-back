import json
import os
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from lib import kilo_settings as ks
from backend.kilo_client import KiloRun

class KiloSettingsTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.global_file=self.root/'kilo.jsonc';self.project=self.root/'project.json'
        self.provider={'name':'Test','npm':'@ai-sdk/openai-compatible','options':{'baseURL':'http://127.0.0.1:9000/v1','apiKey':'test-secret','headers':{'X-Key':'header-secret'}},'models':{'m1':{'name':'Model One','tool_call':False,'reasoning':False,'limit':{'context':32768}}}}
        self.global_file.write_text('// top comment\n'+json.dumps({'provider':{'test':self.provider},'model':'test/m1','permission':{'read':'deny'},'mcp':{'x':{'command':['python']}}},indent=2)+'\n',encoding='utf-8')
        self.patches=[patch.object(ks,'global_paths',return_value=[self.global_file]),patch.object(ks,'project_paths',return_value=[]),patch.object(ks,'UI_PATH',self.root/'ui.json'),patch.object(ks,'load_config',return_value={'kiloExecutable':'kilo','model':'legacy/not-used'})]
        for p in self.patches:p.start()
    def tearDown(self):
        for p in reversed(self.patches):p.stop()
        self.temp.cleanup()
    def request(self,action,**extra):
        view=ks.settings_view();return ks.update_settings(dict(action=action,fileId=view['fileId'],revision=view['revision'],**extra))
    def test_secret_redaction_and_round_trip(self):
        view=ks.settings_view();raw=json.dumps(view);self.assertNotIn('test-secret',raw);self.assertNotIn('header-secret',raw)
        provider=view['providers']['test'];provider['name']='Updated';self.request('save_provider',providerId='test',provider=provider)
        config,_=ks.read_config(self.global_file);self.assertEqual(config['provider']['test']['options']['apiKey'],'test-secret');self.assertEqual(config['provider']['test']['options']['headers']['X-Key'],'header-secret');self.assertEqual(config['mcp']['x']['command'],['python']);self.assertEqual(config['permission']['read'],'deny');self.assertTrue(self.global_file.read_text().startswith('// top comment'));self.assertTrue(list(self.root.glob('*.backup-*')))
    def test_select_model_and_false_flag_not_blocked(self):
        view=self.request('select_model',model='test/m1');self.assertEqual(view['currentModel'],'test/m1');self.assertEqual(ks.job_runtime()['model'],'test/m1')
        self.request('runtime',kiloExecutable='C:/Kilo/kilo.exe');self.assertEqual(ks.job_runtime()['kiloExecutable'],'C:/Kilo/kilo.exe')
    def test_add_model_delete_and_no_legacy_model_fallback(self):
        provider=ks.settings_view()['providers']['test'];provider['models']['m2']={'name':'Model Two','tool_call':True};self.request('save_provider',providerId='test',provider=provider)
        self.assertEqual(ks.job_runtime('test/m2')['model'],'test/m2');self.request('select_model',model='test/m2');self.request('delete_provider',providerId='test')
        with self.assertRaises(ks.SettingsError):ks.job_runtime()
    def test_revision_conflict(self):
        view=ks.settings_view();self.global_file.write_text(self.global_file.read_text()+'\n')
        with self.assertRaises(ks.SettingsConflict):ks.update_settings(dict(action='select_model',model='test/m1',fileId=view['fileId'],revision=view['revision']))
    def test_jsonc_preserves_other_comments_and_trailing_commas(self):
        samples=['{\n "a": 1 // note\n}', '{"a":1, /* trailing */}', '{/* empty */}', '{"a":{"url":"http://test/a//b",},"x":[1,2,],}']
        for raw in samples:
            with self.subTest(raw=raw):
                updated=ks.set_top(raw,'model','test/m1');self.assertEqual(json.loads(ks.clean_jsonc(updated))['model'],'test/m1')
        raw='{"provider":{"x":{}}, // outside\n "permission": {"a":"deny"}}';updated=ks.set_top(raw,'provider',{'test':self.provider});self.assertIn('// outside',updated)
    def test_project_override_and_invalid_file(self):
        self.project.write_text(json.dumps({'provider':{'test':{'models':{'m1':{'name':'Project override'}}}}}))
        with patch.object(ks,'project_paths',return_value=[self.project]):
            view=ks.settings_view();self.assertEqual(view['models'][0]['name'],'Project override');self.assertEqual(view['models'][0]['origin'],str(self.project))
        with self.assertRaises(ks.SettingsError):ks.settings_view('arbitrary')
        with self.assertRaises(ks.SettingsError):self.request('save_provider',providerId='../bad',provider=self.provider)
    def test_real_models_endpoint(self):
        seen=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_GET(self):
                seen.append((self.path,self.headers.get('Authorization'),self.headers.get('X-Key')));self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'data':[{'id':'remote-model'}]}).encode())
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            p=ks.settings_view()['providers']['test'];p['options']['baseURL']=f'http://127.0.0.1:{server.server_port}/v1';self.request('save_provider',providerId='test',provider=p)
            result=ks.fetch_models('test');self.assertEqual(result['models'][0]['id'],'remote-model');self.assertEqual(seen,[('/v1/models','Bearer test-secret','header-secret')]);self.assertNotIn('secret',json.dumps(result))
        finally:server.shutdown();server.server_close();thread.join()
    def test_kilo_run_model_and_exe_snapshot(self):
        run=KiloRun(dict(id='id',token='token',filename='x',context={},selectedModel='chosen/model',kiloExecutable='chosen-kilo'))
        self.assertEqual(run.cfg['model'],'chosen/model');self.assertEqual(run.cfg['kiloExecutable'],'chosen-kilo')

    def test_real_http_settings_endpoints(self):
        import http.client
        from backend.index import Handler
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
        try:
            conn.request('GET','/api/kilo/settings');response=conn.getresponse();self.assertEqual(response.status,200);raw=response.read();self.assertNotIn(b'test-secret',raw);view=json.loads(raw)
            payload=dict(action='select_model',model='test/m1',fileId=view['fileId'],revision=view['revision'])
            conn.request('POST','/api/kilo/settings',body=json.dumps(payload),headers={'Content-Type':'application/json'});response=conn.getresponse();self.assertEqual(response.status,200);self.assertEqual(json.loads(response.read())['currentModel'],'test/m1')
            self.global_file.write_text(self.global_file.read_text()+'\n')
            conn.request('POST','/api/kilo/settings',body=json.dumps(payload),headers={'Content-Type':'application/json'});response=conn.getresponse();self.assertEqual(response.status,409);response.read()
            conn.request('POST','/api/kilo/settings',body=json.dumps(payload),headers={'Content-Type':'application/json','Origin':'http://other.example'});response=conn.getresponse();self.assertEqual(response.status,403);response.read()
            conn.close();conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
            conn.request('POST','/api/kilo/settings',body='action=runtime',headers={'Content-Type':'application/x-www-form-urlencoded'});response=conn.getresponse();self.assertEqual(response.status,415);response.read()
        finally:conn.close();server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main()
