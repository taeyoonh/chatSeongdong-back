import json
import os
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch
from mcp_server.rag_client import RagClient, RagError, Settings, load_env
from mcp_server.index import create_server

class RagTests(unittest.TestCase):
    def client(self): return RagClient(Settings())
    def test_request_contract(self):
        client=self.client()
        payload=client._build_search_request(query='필드 의미',message_id='J3.2I',dfi='1',dui='2',rule_type='send',top_k=3)
        self.assertEqual(set(payload),{'dataset_ids','question'})
        self.assertEqual(payload['dataset_ids'],['268158e49fba11f19801ef240dbe1ea1'])
        self.assertIn('message_id: J3.2I',payload['question']); self.assertIn('DFI: 1',payload['question'])
    def test_response_normalization_and_limit(self):
        data={'code':'0','data':{'chunks':[{'content_with_weight':'근거 원문','docnm_kwd':'규격.pdf','page':0,'similarity':0,'position_int':[[0,1,2]]},{'text':'두 번째','metadata':{'source':'B','section':'2.1'}}]}}
        result=self.client()._normalize_search_response(data,query='q',request_payload={},top_k=1)
        self.assertEqual(result['count'],1); self.assertEqual(result['retrieved_count'],2); self.assertTrue(result['truncated'])
        first=result['results'][0]; self.assertEqual(first['page'],0); self.assertEqual(first['score'],0); self.assertEqual(first['source'],'규격.pdf'); self.assertIn('position_int',first['metadata'])
    def test_invalid_response_and_zero_results(self):
        for data in [{'code':101,'message':'bad dataset'},{'foo':[]},{'results':[{'text':''}]}]:
            with self.subTest(data=data),self.assertRaises(RagError): self.client()._normalize_search_response(data,query='q',request_payload={})
        self.assertEqual(self.client()._normalize_search_response({'data':{'chunks':[]}},query='q',request_payload={})['count'],0)
    def test_env_precedence_and_headers(self):
        with tempfile.TemporaryDirectory() as temp,patch.dict(os.environ,{'RAG_SERVER_URL':'http://os-priority'},clear=True):
            path=Path(temp)/'.env';path.write_text('RAG_SERVER_URL=http://file\nRAG_API_TOKEN="secret" # comment\nRAG_EXTRA_HEADER_VALUE=abc#def\n',encoding='utf-8')
            load_env(path)
            self.assertEqual(os.environ['RAG_SERVER_URL'],'http://os-priority'); self.assertEqual(os.environ['RAG_API_TOKEN'],'secret'); self.assertEqual(os.environ['RAG_EXTRA_HEADER_VALUE'],'abc#def')
        settings=Settings(rag_api_token='secret',rag_extra_header_name='X-Key',rag_extra_header_value='extra')
        self.assertEqual(settings.headers()['Authorization'],'Bearer secret');self.assertEqual(settings.headers()['X-Key'],'extra');self.assertNotIn('secret',repr(settings))
    def test_real_http_contract(self):
        seen=[]
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self):
                self.send_response(200); self.end_headers(); self.wfile.write(b'OK')
            def do_POST(self):
                seen.append((self.headers.get('Authorization'),json.loads(self.rfile.read(int(self.headers['Content-Length'])))))
                self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'code':'0','data':{'chunks':[{'content':'Specification text','document_name':'doc'}]}}).encode())
        server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            client=RagClient(Settings(rag_server_url=f'http://127.0.0.1:{server.server_port}',rag_api_token='secret'))
            self.assertEqual(client.health()['body'],'OK');self.assertEqual(client.search(query='q')['results'][0]['content'],'Specification text')
            self.assertEqual(seen[0][0],'Bearer secret');self.assertEqual(seen[0][1]['question'],'q')
        finally: server.shutdown(); server.server_close();thread.join()
    def test_mcp_tools_and_failures(self):
        server=create_server(); names=set(server.tools);self.assertIn('search_rag',names);self.assertIn('rag_connection_check',names)
        with patch('mcp_server.knowledge.RagClient') as cls:
            cls.return_value.search.return_value={'ok':True,'results':[{'content':'原文','source':'doc'}]}
            response=server.call_tool({'name':'search_rag','arguments':{'query':'q','message_id':'K.0'}})
            self.assertNotIn('isError',response);cls.return_value.search.assert_called_once_with(query='q',message_id='K.0')
            cls.return_value.search.side_effect=RagError('timeout')
            self.assertTrue(server.call_tool({'name':'search_rag','arguments':{'query':'q'}})['isError'])
            cls.return_value.health.return_value={'ok':True}
            self.assertNotIn('isError',server.call_tool({'name':'rag_connection_check','arguments':{}}))
    def test_query_validation(self):
        for args in [{'query':''},{'query':'q','top_k':0},{'query':'q','top_k':21}]:
            with self.assertRaises(RagError): self.client().search(**args)

if __name__=='__main__': unittest.main()
