import csv
import io
import sys
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parents[1]
def fixture_bytes():
    stream=io.StringIO(newline=''); writer=csv.writer(stream)
    writer.writerow(['Time1','Time2','From','To','Track_ID','Altitude','Request_ID','Message','Note'])
    writer.writerows([
      ['2026-10-15 13:58:38','0','KTMOIS','KICCIS','20489','78','','J3.2','시험 시작'],
      ['2026-10-15 13:58:39','100','KTMOIS','KICCIS','20489','78','','J3.2','두 줄\r\n메모, "인용"'],
      ['2026-10-15 14:00:39','0','KTMOIS','KICCIS','20489','80','320','J3.2','수신 공백 이후'],
      ['2026-10-15 14:00:42','800','KICCIS','KTMOIS','20489','80','320','ACK','응답'],
    ])
    return stream.getvalue().encode('utf-8-sig')
def main():
    out=ROOT/'data/testzips'; out.mkdir(parents=True,exist_ok=True)
    for protocol in ('link16','mdil'):
        with ZipFile(out/f'{protocol}_test.zip','w',ZIP_DEFLATED) as archive:
            archive.writestr('J3.2I.csv' if protocol=='link16' else 'K.0.csv',fixture_bytes())
    print(out)
if __name__=='__main__': main()
