"""Preserve custom providers/MCP servers while installing this Python MCP entry."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def configure():
    target=ROOT/'kilo.json'
    config=json.loads(target.read_text(encoding='utf-8-sig')) if target.exists() else {}
    if target.exists(): (ROOT/'kilo.json.bak').write_bytes(target.read_bytes())
    config.setdefault('mcp',{})['log-analyzer']={'type':'local','command':[sys.executable,'-m','mcp_server.index'],'timeout':600000}
    permissions=config.setdefault('permission',{})
    for name in ('log-analyzer_*','mcp-rag2_*','mcp-rag-manager_*'): permissions.setdefault(name,'allow')
    for name in ('bash','edit','read','list','glob','grep','task','webfetch','websearch','todowrite'): permissions.setdefault(name,'deny')
    target.write_text(json.dumps(config,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('kilo.json의 log-analyzer 명령을 현재 Python으로 설정했습니다:',sys.executable)
if __name__=='__main__': configure()
