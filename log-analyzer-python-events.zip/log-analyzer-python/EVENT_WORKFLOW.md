# 이벤트 중심 분석 흐름

## 처리 순서

```text
서버: CSV 묶음 → 정규화·시간 정렬 → master.csv → Kilo 실행
AI: get_job_status → summarize_dataset → next_analysis_batch
    → label_event prepare (원본으로 RAG 선행 검색)
    → AI가 문서 근거를 읽고 해석
    → label_event submit (근거와 연결된 이벤트 초안)
    → query_messages / calculate_metrics (초안의 관련 메시지)
    → validate_event meaning: prepare → submit
    → validate_event boundary: prepare → submit
    → confirm_event
    → complete_analysis_batch → 다음 읽기 창
    → 전 구간·이벤트 확정 → finalize_analysis → build_report → verify_report
```

200행은 읽기 창이며 의미적 이벤트 경계가 아니다. 코릴레이션/교전 시작·종료 등 상황과 경계는
AI가 규격 근거와 로그 관계를 대조하여 판단한다. 진행 중인 이벤트는 확정하지 않은 같은 초안을
다음 읽기 창에서 이어갈 수 있다. 현재 창의 모든 행을 초안에 배정해야 다음 창으로 진행한다.
아직 읽지 않은 미래 ID는 사용할 수 없다. 이벤트 연결 상한은 5000행이며 더 큰 상황은 부모·하위
이벤트로 나눈다. 같은 시각의 파일명/행번호 정렬은 실제 인과관계를 뜻하지 않는다.

## 추가한 도구

| 도구 | 역할 |
|---|---|
| merge_csv | 시간순 master.csv 생성. 기존 prepare_dataset의 명시적 이름이며 준비 결과를 재사용 |
| label_event | prepare로 RAG 선행 검색 → submit으로 근거 기반 초안 저장. inspect로 조회 |
| validate_event | 의미·관계 검토와 시작·종료 경계 검토를 각각 준비하고 제출 |
| confirm_event | 같은 리비전의 두 검토를 완료한 이벤트만 최종 보고서용 테이블에 반영 |

직접 최종 저장을 허용하던 MCP `save_analysis`와 별도 `search_event_rag`는 노출하지 않는다.
필수 RAG 호출은 `label_event prepare`와 `validate_event prepare` 안에서 서버가 수행한다. 현재 도구는 호환용 prepare_dataset 포함 16개다.

## 초안과 관계

`label_event(action="submit", event, labelEvidenceId, evidenceQuote, rationale)`에는 clientId, category, action, title, description, status, messageLinks,
messageRoles, relations를 전달한다. action에는 started/ended도 사용할 수 있다.
messageRoles는 대상 원본 행마다 역할을 하나씩 지정한다. 여러 행은 relations로 연결되어야 한다.
설명에는 대상·관측·절차·시작/종료 이유를 기록한다. 이상/보류는 event.findings로 작성하며
각 Finding에도 실제 대상 messageLinks를 넣는다. status=anomaly에는 anomaly Finding이 필요하다.
Finding.analysisType은 metric(계산값과 규격 기준 대조) 또는 relationship(메시지 관계·절차 해석)이다.
metric 후보는 실제 계산을 수행한 뒤 해당 이벤트의 metricIds를 연결해야 RAG 검증을 시작할 수 있다.
그 검토의 관찰값도 저장 계산 원본으로 대체한다. relationship 후보도 실제 원본·관계와 규격 검증이 필요하다.
시각 불명 행이 포함된 이벤트는 시간 경계를 확정할 수 없으므로 undetermined로 둔다.

초안은 DB에 보존되지만 최종 CSV/Excel에는 나타나지 않는다. 수정할 때마다 revision이 증가한다.
확정 이벤트는 변경할 수 없으므로 후속 메시지가 필요한 이벤트를 성급히 확정하지 않는다.

## 계산 원본 보존

`query_messages`와 `calculate_metrics`는 eventClientId를 먼저 요구한다. 초안으로 지정한 메시지
범위만 조회·계산한다. 조회는 원본 필드 전체를 기본 반환한다. 계산에 messageLinks를 주면 초안의
부분집합으로 제한할 수 있다. 계산 조건, 정확한 원본 ID, 결과는 metric_results에 저장되고 metricId를 반환한다.

지원 계산은 first_last, intervals, field_changes, routes다. groupBy는 하나만 지원한다.
시간 불명·결과 잘림·그룹 제한은 명시하며 불완전한 계산 검토를 pass로 덮을 수 없다.
계산 추가는 초안 revision을 증가시켜 이전 검증을 무효화한다. 초안 범위 변경으로 대상이 빠진
계산은 삭제하지 않고 superseded 시각·사유를 남긴다.

## 규격 근거와 두 차례 검증

1. `validate_event(clientId, action="prepare", reviewType="meaning")`
2. 반환된 validationId/requiredChecks를 읽고 AI가 실제 관측과 규격을 대조한다.
3. `validate_event(clientId, action="submit", validationId, checks)`
4. 같은 리비전에 reviewType="boundary"로 prepare → submit을 별도로 수행한다.

meaning은 메시지 의미·주체 관계·상황 해석, boundary는 시작/종료·순서·필수 메시지를 검토한다.
prepare는 서버가 읽은 실제 원본·역할·관계·초안과 **저장 계산 원본**으로 원격 RAG를 직접 요청한다.
영문 규격에는 query로 구체적인 영문 메시지명·절차 질문을 보완한다. 일반 TXT/RAG 토글로 이 요청을
대체할 수 없다. 일반 search_rag만 토글을 따른다.

각 check는 code, verdict(pass/fail/undetermined), observed, expected, comparison, applicability,
quote, messageIds를 가진다. message_meaning은 전체 행을 검토해야 한다. 각 계산/Finding에도 별도
check가 필요하다. 계산 check의 messageIds는 저장 대상과 일치해야 하고 observed는 서버 원본으로 대체된다.
pass/fail에는 **해당 검증 요청의 실제 검색 본문에 있는 8자 이상 인용**이 필요하다. RAG 오류/0건은 보류만 허용한다.

confirm_event는 현재 revision의 meaning/boundary 두 종류에서 최신 검토를 확인한다.
미제출 prepare, 누락, fail은 거절한다. 초안 수정·계산 추가 이후에는 두 검토를 새로 해야 한다.
보류 검토가 남으면 이벤트와 Findings도 모두 undetermined여야 확정할 수 있다.

이 흐름은 실제 자료·계산·RAG 조회·검토 기록을 연결하도록 강제한다. 규격 적용과 상황 해석의
의미적 정확성을 코드가 자동 증명하는 것은 아니다. 두 검토는 같은 AI가 서로 다른 관점으로 수행한다.

## Excel 결과

모든 이벤트 확정 후 build_report가 final.csv와 final.xlsx를 생성한다. Excel은 외부 패키지 없이
스트리밍 OOXML로 작성한다. 화면의 분석 Excel 다운로드 또는
`GET /api/read-jobs/<작업 UUID>/xlsx`로 다운로드한다.

| 시트 | 내용 |
|---|---|
| Events | 확정 이벤트 제목·유형·시작/종료·판정·자연어 설명·문서 출처·원문 인용 |
| Messages | 모든 원본 행의 시간순 메시지·이벤트 라벨·설명·근거·행별 역할 |
| Findings | 이상/보류 판단과 사유 |
| Validation | 리비전별 관측·기대·비교·조건·원문 인용·검토 이력 |
| Metrics | 서버 계산 조건·대상·원본 결과와 대체된 계산의 사유 |
| Relations | 이벤트 내 메시지 간 관계 |

초안/미확정 이벤트가 있거나 원본 행이 확정 이벤트에 포함되지 않으면 전체 확정을 거절한다.
Excel 한 시트의 1,048,576행 또는 셀 32,767자 제한을 넘으면 오류를 반환하고 DB는 보존한다.
verify_report는 기존 DB/CSV 검사와 함께 Excel 생성 해시를 확인한다.

## 저장·재개·기존 데이터

원본과 계산의 기준은 SQLite다. event_label_evidence/event_drafts/event_validations/metric_results에 각 단계가 보존된다.
저장·검토·확정 후 data/results/<작업 UUID>/analysis-checkpoint.json 스냅샷도 갱신된다.
기존 초안은 get_job_status.eventDrafts와 label_event(clientId)로 다시 확인한다.

이전 버전의 완료 결과는 계속 조회할 수 있다. 예전 이벤트를 새 검증 완료로 자동 간주하지 않는다.
이전 미완료 작업을 새 흐름으로 확정하려면 기존 이벤트도 새 초안·두 검토·확정을 거쳐야 한다.
새 시험은 새 ZIP 업로드로 시작하는 것을 권장한다. DB 스키마 추가는 자동 수행하며 기존 데이터는 삭제하지 않는다.

## 라벨링 전 RAG 조회 강제

1. `label_event(action="prepare", clientId, messageLinks, query)`를 호출합니다. 아직 의미 라벨을 만들 필요 없이 읽은 메시지 범위를 지정합니다. 서버가 실제 원본 필드·시각·출처와 프로토콜을 원격 RAG에 전송하고 labelEvidenceId를 반환합니다. 이벤트 초안은 아직 저장하지 않습니다.
2. AI가 반환 문서를 읽고 메시지 역할·관계·시나리오·경계를 판단합니다. 필요하면 prepare를 여러 번 호출하여 질문을 보완할 수 있습니다. 각 호출은 검색 1회이며 자동 반복 검색은 아닙니다.
3. `label_event(action="submit", event, labelEvidenceId, evidenceQuote, rationale)`를 호출합니다. 이번 검색의 실제 8자 이상 원문 인용과 규격 적용 이유를 요구합니다. 근거 ID는 작업·이벤트·대상 메시지 집합·검색 당시 초안 리비전에 결합됩니다. 검색 범위 또는 리비전이 바뀌면 다시 prepare해야 합니다. 모델이 event.labelGrounding을 복사해 넣어도 서버가 검증 후 대체합니다.
4. 검색 오류/0건이면 인용을 만들 수 없고 이벤트·Finding을 모두 undetermined로만 저장합니다. 이후 별도의 의미·경계 검증도 그대로 수행해야 합니다.

일반 search_rag/TXT 토글은 유지하지만 라벨링 선행 조회는 항상 원격 RAG입니다. 모델은 대상 범위를 선택하고 문서 의미를 해석하며, 서버는 원본 전달·검색 수행·출처 연결·필수 절차를 강제합니다. 원문 인용의 존재가 해석의 정확성까지 증명하지는 않습니다.

검색 요청·응답·대상·리비전은 event_label_evidence에 저장하고 체크포인트에도 포함합니다. 확정 초안의 labelGrounding과 Excel Validation 시트에 라벨링 적용 이유·인용을 기록합니다. Excel의 grounded는 검색 근거 연결을 뜻하며 검증 통과를 뜻하지 않습니다. 기존 문서/도구 수는 16개를 유지하고 label_event의 입력 계약을 강화했습니다. 이전 호출 형태 label_event(event)는 저장을 거절합니다. 기존 미확정 초안은 새 prepare/submit으로 갱신해야 하며 이미 확정된 이전 초안은 새 작업에서 재분석해야 새 보고서를 생성할 수 있습니다. 기존 산출물 조회는 유지됩니다.
