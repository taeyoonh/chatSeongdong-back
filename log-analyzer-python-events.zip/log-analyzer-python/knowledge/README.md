# 로컬 TXT 근거 파일

토글 OFF일 때 사용할 실제 규격·메시지 정의·운용 절차를 `reference.txt`에 UTF-8로 저장하세요.
실제 규격 내용이 제공되지 않았으므로 빈 예시 파일이나 가짜 규격을 넣지 않았습니다.

다른 위치의 TXT를 사용하려면 `config/local-config.json`에 설정하세요.

```json
"localKnowledgePath": "C:/Users/77753/MDIL/docs/reference.txt"
```

상대 경로는 프로젝트 루트 기준입니다. 기본값은 `knowledge/reference.txt`입니다.
선택된 파일 하나만 읽습니다. 폴더를 검색하거나 임의 파일을 모델이 선택할 수 없습니다.
문서 제목/절 번호를 본문에 넣고 메시지별로 구분하면 검색 품질이 좋아집니다.
파일 최대 크기는 64MiB이며 UTF-8(권장), UTF-8 BOM, CP949를 지원합니다.
분석 도중 TXT를 변경하지 마세요. 로딩 후 변경을 감지하면 새 작업 시작을 요청합니다.
