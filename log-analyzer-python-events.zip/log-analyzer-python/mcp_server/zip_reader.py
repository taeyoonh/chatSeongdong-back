from zipfile import ZipFile
from pathlib import PurePosixPath
from lib.config import load_config
from .mcp_core import McpToolError
def read_csv_entries(zip_path):
    """Yield one CSV at a time; no archive member is extracted to the filesystem."""
    cfg=load_config(); expanded=0
    with ZipFile(zip_path) as archive:
        members=archive.infolist()
        if len(members)>cfg['maxZipEntries']: raise McpToolError('ZIP 항목 수 제한을 초과했습니다.')
        names=set()
        for info in members:
            name=info.filename.replace('\\','/'); part=PurePosixPath(name)
            if info.is_dir() or part.suffix.lower()!='.csv' or part.name.startswith('.'): continue
            if part.is_absolute() or '..' in part.parts or name in names: raise McpToolError(f'안전하지 않거나 중복된 ZIP 경로: {name}')
            names.add(name); expanded+=info.file_size
            if expanded>cfg['maxExpandedBytes']: raise McpToolError('ZIP 해제 용량 제한을 초과했습니다.')
            yield {'name':name,'buffer':archive.read(info)}
