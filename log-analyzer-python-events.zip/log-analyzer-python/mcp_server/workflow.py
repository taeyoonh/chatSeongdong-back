"""MCP workflow gates: ordered batches, per-item remote RAG, durable progress.

The model still decides the meaning of logs. These gates verify tool use,
coverage and provenance, not semantic correctness of the model's judgment.
"""
import json
import uuid
from lib.db import get_db, transaction
from lib.jobs import now
from lib.paths import RESULTS_DIR
from .auth import assert_job
from .mcp_core import McpToolError
from .analysis import finalize_analysis
from .ordered import ORDER, ordered_ids, rows_after

BATCH_SIZE = 200

def job_for(args):
    job = assert_job(args.get('uploadId'))
    if job['finalized_at'] is not None:
        raise McpToolError('확정된 분석은 변경할 수 없습니다.')
    return job

def active_batch(upload_id, batch_id):
    row = get_db().execute('SELECT * FROM analysis_batches WHERE upload_id=? AND id=? AND completed_at IS NULL', (upload_id, batch_id)).fetchone()
    if row is None:
        raise McpToolError('현재 열린 batchId가 필요합니다. next_analysis_batch를 호출하세요.')
    return row

def present(rows):
    return [dict(id=r['id'],tsMs=r['ts_ms'],source=r['source_file'],line=r['line_no'],fields=json.loads(r['data_json'])) for r in rows]

def next_analysis_batch(args):
    job = job_for(args); uid = job['id']
    with transaction() as db:
        if not db.execute('SELECT 1 FROM file_meta WHERE upload_id=?', (uid,)).fetchone():
            raise McpToolError('먼저 prepare_dataset를 호출하세요.')
        batch = db.execute('SELECT * FROM analysis_batches WHERE upload_id=? AND completed_at IS NULL', (uid,)).fetchone()
        previous = db.execute('SELECT * FROM analysis_batches WHERE upload_id=? AND completed_at IS NOT NULL ORDER BY start_offset DESC LIMIT 1', (uid,)).fetchone()
        offset = previous['start_offset']+previous['row_count'] if previous else 0
        previous_rows=ordered_ids(uid,json.loads(previous['ids_json'])) if previous else []
        if batch is None:
            rows = rows_after(uid,previous_rows[-1] if previous_rows else None,BATCH_SIZE)
            if not rows:
                return dict(ok=True,done=True,processed=offset)
            bid = uuid.uuid4().hex
            db.execute('INSERT INTO analysis_batches(id,upload_id,start_offset,row_count,ids_json) VALUES(?,?,?,?,?)', (bid,uid,offset,len(rows),json.dumps([r['id'] for r in rows])))
            batch = active_batch(uid,bid)
        rows = ordered_ids(uid,json.loads(batch['ids_json']))
        return dict(ok=True,done=False,batchId=batch['id'],offset=batch['start_offset'],rows=present(rows),
                    contextBefore=present(previous_rows[-20:]),
                    contextAfter=present(rows_after(uid,rows[-1],20)),
                    previousState=previous['carry_state'] if previous else '',
                    instruction='현재 rows의 모든 행을 이벤트 초안에 배정하세요. label_event prepare로 RAG 근거를 먼저 읽고 submit으로 초안 저장 → 필요 조회/계산 → validate_event 의미·경계 두 검증 → confirm_event. 긴 이벤트는 다음 구간에서 새 prepare/submit으로 이어가세요. 200행은 의미적 이벤트 경계가 아닙니다.')

def complete_analysis_batch(args):
    job = job_for(args); state = args.get('carryState')
    if not isinstance(state,str) or not state.strip():
        raise McpToolError('다음 구간으로 전달할 carryState(주체별 상태, 미완료 이벤트, 확인사항)가 필요합니다.')
    with transaction() as db:
        batch = active_batch(job['id'],args.get('batchId'))
        ids = set(json.loads(batch['ids_json']))
        covered = {r[0] for r in db.execute('''SELECT em.message_id FROM event_messages em JOIN events e ON e.id=em.event_id
JOIN analysis_item_audit a ON a.upload_id=e.upload_id AND a.client_id=e.client_id AND a.kind='event' WHERE a.batch_id=?
UNION SELECT fm.message_id FROM finding_messages fm JOIN findings f ON f.id=fm.finding_id
JOIN analysis_item_audit a ON a.upload_id=f.upload_id AND a.client_id=f.client_id AND a.kind='finding' WHERE a.batch_id=?''', (batch['id'],batch['id']))}
        for draft in db.execute('SELECT ids_json FROM event_drafts WHERE upload_id=?',(job['id'],)):
            covered.update(json.loads(draft['ids_json']))
        if ids-covered:
            raise McpToolError(f'현재 구간에 이벤트 초안으로 배정되지 않은 행이 {len(ids-covered)}개 있습니다.')
        db.execute('UPDATE analysis_batches SET carry_state=?,completed_at=? WHERE id=?', (state,now(),batch['id']))
    checkpoint(job['id'])
    return dict(ok=True,completedBatchId=batch['id'],processed=batch['start_offset']+batch['row_count'])

def guarded_finalize_analysis(args):
    job = job_for(args)
    with transaction() as db:
        total = db.execute('SELECT COUNT(*) FROM messages WHERE upload_id=?',(job['id'],)).fetchone()[0]
        covered = db.execute('SELECT COALESCE(SUM(row_count),0) FROM analysis_batches WHERE upload_id=? AND completed_at IS NOT NULL',(job['id'],)).fetchone()[0]
        pending = db.execute('SELECT 1 FROM analysis_batches WHERE upload_id=? AND completed_at IS NULL',(job['id'],)).fetchone()
        if pending or covered!=total:
            raise McpToolError('모든 구간의 순차 분석, RAG 조회, 저장, 완료 후에만 확정할 수 있습니다.')
        from .event_workflow import assert_confirmed
        assert_confirmed(job['id'])
        result = finalize_analysis(args)
    checkpoint(job['id'])
    return result

def checkpoint(uid):
    """SQLite is authoritative; retain readable snapshots after each save/completion."""
    db = get_db(); payload = dict(uploadId=uid,updatedAt=now())
    for table in ('analysis_batches','event_label_evidence','event_drafts','event_validations','metric_results','event_rag_evidence','analysis_item_audit','events','findings'):
        payload[table] = [dict(r) for r in db.execute(f'SELECT * FROM {table} WHERE upload_id=?',(uid,))]
    for table,owner,column in [('event_messages','events','event_id'),('finding_messages','findings','finding_id')]:
        payload[table] = [dict(r) for r in db.execute(f'SELECT l.* FROM {table} l JOIN {owner} o ON o.id=l.{column} WHERE o.upload_id=?',(uid,))]
    directory = RESULTS_DIR/uid; directory.mkdir(parents=True,exist_ok=True)
    target = directory/'analysis-checkpoint.json'; temp = target.with_suffix('.json.tmp')
    temp.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); temp.replace(target)
