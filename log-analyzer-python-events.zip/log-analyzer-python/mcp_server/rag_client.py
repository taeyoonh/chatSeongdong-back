"""Internal RAG adapter. Standard-library HTTP keeps the project pip-free.

API contract: POST {dataset_ids: [...], question: ...}. Search filters are
question text, not server-side filters. top_k limits normalized returned chunks.
"""
from __future__ import annotations

import json
import logging
import os
import ssl
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, HTTPSHandler

from lib.paths import APP_ROOT

logger = logging.getLogger('log_analyzer.rag_client')

class RagError(RuntimeError):
    """Configuration, connection, API, or response-shape failure."""

def load_env(path: Path) -> None:
    """Read simple KEY=value .env values; existing OS values take precedence.

    Supports export, quotes and comments, without variable interpolation.
    """
    if not path.is_file():
        return
    for number, line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('export '):
            line = line[7:].lstrip()
        if '=' not in line:
            raise RagError(f'.env line {number}: KEY=value가 필요합니다.')
        name, value = line.split('=', 1)
        name, value = name.strip(), value.strip()
        if not name or not name.replace('_', 'a').isalnum() or name[0].isdigit():
            raise RagError(f'.env line {number}: 올바르지 않은 변수명입니다.')
        if value.startswith(('"', "'")):
            quote = value[0]
            end = value.find(quote, 1)
            if end < 0 or (value[end+1:].strip() and not value[end+1:].strip().startswith('#')):
                raise RagError(f'.env line {number}: 따옴표를 확인하세요.')
            value = value[1:end]
        else:
            value = value.split(' #', 1)[0].rstrip()
        os.environ.setdefault(name, value)

def _dataset_ids(raw: str) -> tuple[str, ...]:
    try:
        values = json.loads(raw) if raw.strip().startswith('[') else raw.split(',')
    except ValueError as err:
        raise RagError('RAG_DATASET_IDS: JSON 문자열 배열 또는 쉼표 구분 목록이 필요합니다.') from err
    if not isinstance(values, list) or any(not isinstance(v, str) for v in values):
        raise RagError('RAG_DATASET_IDS는 문자열 목록이어야 합니다.')
    return tuple(dict.fromkeys(v.strip() for v in values if v.strip()))

@dataclass(frozen=True)
class Settings:
    rag_server_url: str = 'http://127.0.0.1:9000'
    rag_search_path: str = '/search'
    rag_health_path: str = '/health'
    rag_timeout_sec: float = 30
    rag_verify_ssl: bool = True
    rag_api_token: str = field(default='', repr=False)
    rag_auth_header: str = 'Authorization'
    rag_auth_scheme: str = 'Bearer'
    rag_extra_header_name: str = ''
    rag_extra_header_value: str = field(default='', repr=False)
    dataset_ids: tuple[str, ...] = ('268158e49fba11f19801ef240dbe1ea1',)

    @classmethod
    def from_env(cls) -> 'Settings':
        load_env(APP_ROOT / '.env')
        try:
            timeout = float(os.getenv('RAG_TIMEOUT_SEC', '30'))
        except ValueError as err:
            raise RagError('RAG_TIMEOUT_SEC는 양수여야 합니다.') from err
        import math
        if not math.isfinite(timeout) or timeout <= 0:
            raise RagError('RAG_TIMEOUT_SEC는 유한한 양수여야 합니다.')
        path = lambda key, default: '/' + (os.getenv(key, default).strip() or default).lstrip('/')
        return cls(
            rag_server_url=os.getenv('RAG_SERVER_URL', 'http://127.0.0.1:9000').strip().rstrip('/'),
            rag_search_path=path('RAG_SEARCH_PATH', '/search'),
            rag_health_path=path('RAG_HEALTH_PATH', '/health'),
            rag_timeout_sec=timeout,
            rag_verify_ssl=os.getenv('RAG_VERIFY_SSL', 'true').strip().lower() not in {'0','false','no','off'},
            rag_api_token=os.getenv('RAG_API_TOKEN', '').strip(),
            rag_auth_header=os.getenv('RAG_AUTH_HEADER', 'Authorization').strip(),
            rag_auth_scheme=os.getenv('RAG_AUTH_SCHEME', 'Bearer').strip(),
            rag_extra_header_name=os.getenv('RAG_EXTRA_HEADER_NAME', '').strip(),
            rag_extra_header_value=os.getenv('RAG_EXTRA_HEADER_VALUE', '').strip(),
            dataset_ids=_dataset_ids(os.getenv('RAG_DATASET_IDS', '268158e49fba11f19801ef240dbe1ea1')),
        )

    def headers(self) -> dict[str, str]:
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        if self.rag_api_token:
            if not self.rag_auth_header:
                raise RagError('RAG_AUTH_HEADER가 비어 있습니다.')
            headers[self.rag_auth_header] = (self.rag_auth_scheme + ' ' if self.rag_auth_scheme else '') + self.rag_api_token
        if self.rag_extra_header_name and self.rag_extra_header_value:
            headers[self.rag_extra_header_name] = self.rag_extra_header_value
        return headers

class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Do not forward configured authentication headers to redirect targets.
        return None

class RagClient:
    def __init__(self, settings: Settings | None = None):
        self.settings = settings or Settings.from_env()

    def _request(self, path: str, payload: dict | None = None) -> tuple[int, Any]:
        cfg = self.settings
        parsed = urlsplit(cfg.rag_server_url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise RagError('RAG_SERVER_URL은 사용자정보/쿼리/프래그먼트 없는 http(s) URL이어야 합니다.')
        url = cfg.rag_server_url + '/' + path.lstrip('/')
        context = ssl.create_default_context() if cfg.rag_verify_ssl else ssl._create_unverified_context()
        request = Request(url, data=json.dumps(payload, ensure_ascii=False).encode('utf-8') if payload is not None else None, headers=cfg.headers(), method='POST' if payload is not None else 'GET')
        opener = build_opener(_NoRedirect(), HTTPSHandler(context=context))
        # Only counts and lengths go to logs; query text, chunks and credentials do not.
        try:
            with opener.open(request, timeout=cfg.rag_timeout_sec) as response:
                raw = response.read().decode('utf-8-sig')
                status = response.status
        except HTTPError as err:
            raise RagError(f'RAG server returned HTTP {err.code}. 엔드포인트/인증 설정을 확인하세요.') from err
        except TimeoutError as err:
            raise RagError('RAG server timeout') from err
        except (URLError, OSError) as err:
            reason = getattr(err, 'reason', err)
            raise RagError(f'RAG server connection failed: {type(reason).__name__}') from err
        except UnicodeDecodeError as err:
            raise RagError('RAG response is not UTF-8') from err
        try:
            return status, json.loads(raw)
        except ValueError:
            if payload is None:
                return status, raw
            raise RagError('RAG response is not valid JSON')

    def health(self) -> dict[str, Any]:
        status, body = self._request(self.settings.rag_health_path)
        if isinstance(body, dict) and body.get('code') not in (None, 0, '0'):
            raise RagError(f"RAG API error: code={body['code']}")
        return {'ok': True, 'status_code': status, 'body': body}

    def search(self, *, query: str, message_id: str | None = None, dfi: str | None = None, dui: str | None = None, rule_type: str | None = None, top_k: int = 5) -> dict[str, Any]:
        if not isinstance(query, str) or not query.strip():
            raise RagError('query must not be empty')
        if not isinstance(top_k, int) or isinstance(top_k, bool) or not 1 <= top_k <= 20:
            raise RagError('top_k must be 1..20')
        payload = self._build_search_request(query=query.strip(), message_id=message_id, dfi=dfi, dui=dui, rule_type=rule_type, top_k=top_k)
        _, data = self._request(self.settings.rag_search_path, payload)
        if not isinstance(data, dict):
            raise RagError('Unexpected RAG response: expected a JSON object')
        result = self._normalize_search_response(data, query=query.strip(), request_payload=payload, top_k=top_k)
        logger.info('RAG normalized returned=%s retrieved=%s', result['count'], result['retrieved_count'])
        return result

    def _build_search_request(self, *, query: str, message_id: str | None, dfi: str | None, dui: str | None, rule_type: str | None, top_k: int) -> dict[str, Any]:
        if not self.settings.dataset_ids:
            raise RagError('RAG_DATASET_IDS가 비어 있습니다.')
        conditions = [f'{name}: {value}' for name, value in [('message_id',message_id),('DFI',dfi),('DUI',dui),('rule_type',rule_type)] if value]
        question = query + ('\n' + '\n'.join(conditions) if conditions else '')
        return {'dataset_ids': list(self.settings.dataset_ids), 'question': question}

    def _normalize_search_response(self, data: Any, *, query: str, request_payload: dict[str, Any], top_k: int = 5) -> dict[str, Any]:
        if isinstance(data, dict) and data.get('code') not in (None, 0, '0'):
            raise RagError(f"RAG API error: code={data['code']}, message={data.get('message') or data.get('msg') or ''}")
        def find_results(value):
            if isinstance(value, list): return value
            if isinstance(value, dict):
                for key in ('chunks','results','documents','items'):
                    if isinstance(value.get(key), list): return value[key]
                if 'data' in value: return find_results(value['data'])
            return None
        raw = find_results(data)
        if raw is None:
            raise RagError('Unsupported RAG response structure: expected chunks/results/documents/items or nested data')
        def first(mapping, *keys):
            return next((mapping[k] for k in keys if mapping.get(k) is not None and mapping[k] != ''), None)
        results = []
        for item in raw[:top_k]:
            if not isinstance(item, dict):
                raise RagError('Unexpected RAG result item: expected a JSON object')
            metadata = item.get('metadata') if isinstance(item.get('metadata'), dict) else {}
            content = first(item,'content_with_weight','content','text','page_content','chunk')
            if not isinstance(content, str) or not content.strip():
                raise RagError('RAG returned a result without readable text')
            source = first(item,'document_name','docnm_kwd','source','document','file_name')
            if source is None: source = first(metadata,'source','document','file_name')
            page = first(item,'page','page_number')
            if page is None: page = first(metadata,'page','page_number')
            section = first(item,'section','section_path')
            if section is None: section = first(metadata,'section','section_path')
            extra = dict(metadata)
            for key in ('positions','position_int','document_id','doc_id','dataset_id','kb_id','distance'):
                if key in item: extra[key] = item[key]
            results.append(dict(content=content,source=source,page=page,section=section,score=first(item,'score','similarity'),metadata=extra))
        return dict(ok=True,query=query,filters=request_payload.get('filters',{}),count=len(results),retrieved_count=len(raw),truncated=len(raw)>len(results),results=results)
