"""Deterministic local TXT retrieval; no network, model or embedding calls."""
from __future__ import annotations
import hashlib
import math
import re
from pathlib import Path
from .rag_client import RagError

class LocalTextClient:
    def __init__(self, path: str):
        self.path=Path(path)
        self._fingerprint=None
        self._chunks=None
        self._sha=None
    def _load(self):
        if self.path.suffix.lower()!='.txt': raise RagError('로컬 근거 파일은 .txt여야 합니다.')
        try:
            stat=self.path.stat()
            if not self.path.is_file(): raise RagError('지정된 TXT가 파일이 아닙니다.')
            if stat.st_size>64*1024*1024: raise RagError('로컬 TXT는 최대 64MiB까지 지원합니다.')
            fingerprint=(stat.st_mtime_ns,stat.st_size)
            if self._chunks is not None:
                if fingerprint!=self._fingerprint: raise RagError('분석 중 TXT가 변경되었습니다. 새 작업으로 시작하세요.')
                return
            raw=self.path.read_bytes()
        except OSError as err: raise RagError(f'로컬 TXT를 읽을 수 없습니다: {self.path.name}. localKnowledgePath 설정을 확인하세요.') from err
        try: text=raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            try: text=raw.decode('cp949')
            except UnicodeDecodeError as err: raise RagError('로컬 TXT는 UTF-8 또는 CP949 형식이어야 합니다.') from err
        if not text.strip(): raise RagError('로컬 TXT가 비어 있습니다. 실제 규격/운용 설명을 넣어주세요.')
        if '\x00' in text: raise RagError('로컬 TXT에 이진 데이터 또는 UTF-16 문자가 있습니다. UTF-8로 저장하세요.')
        self._sha=hashlib.sha256(raw).hexdigest()
        chunks=[]; lines=text.splitlines(); start=1; group=[]; length=0
        for number,line in enumerate(lines,1):
            # Split unusually long lines without silently dropping content.
            pieces=[line[i:i+2200] for i in range(0,len(line),2200)] or ['']
            for piece in pieces:
                if group and (length+len(piece)>2400 or number-start>=40):
                    content='\n'.join(group)
                    if content.strip(): chunks.append((start,previous,content))
                    group=[];length=0;start=number
                if not group: start=number
                group.append(piece);length+=len(piece)+1;previous=number
        if group and '\n'.join(group).strip(): chunks.append((start,len(lines),'\n'.join(group)))
        self._chunks=chunks;self._fingerprint=fingerprint
    def health(self):
        self._load()
        return dict(ok=True,knowledge_source='local_text',source=self.path.name,chunk_count=len(self._chunks),sha256=self._sha,note='지정 TXT를 읽을 수 있습니다. 검색은 로컬 키워드 방식입니다.')
    def search(self,*,query:str,message_id=None,dfi=None,dui=None,rule_type=None,top_k=5):
        if not isinstance(query,str) or not query.strip(): raise RagError('query must not be empty')
        if not isinstance(top_k,int) or isinstance(top_k,bool) or not 1<=top_k<=20: raise RagError('top_k must be 1..20')
        self._load()
        # Whitespace/underscore variants match names such as TRACK NUMBER.
        normalize=lambda s: re.sub(r'[\s_]+',' ',s.casefold())
        words=re.findall(r'[a-zA-Z][a-zA-Z0-9_.-]*|[가-힣]{2,}|\d+',query)
        stop={'의미','알려줘','확인','대한','관련','무엇','설명','검색','규격','정보','내용','the','and','what','meaning','please','define','is','of','to'}
        terms=list(dict.fromkeys(normalize(w) for w in words if normalize(w) not in stop))
        hints=[normalize(str(v).strip()) for v in (message_id,dfi,dui,rule_type) if v is not None and str(v).strip()]
        ranked=[]
        for i,(first,last,content) in enumerate(self._chunks):
            text=normalize(content);hits=[t for t in terms if t in text]
            hint_hits=[t for t in hints if t in text]
            if not hits and not hint_hits: continue
            score=sum(1+math.log1p(text.count(t)) for t in hits)+sum(3+math.log1p(text.count(t)) for t in hint_hits)
            ranked.append((score,i,first,last,content))
        ranked.sort(key=lambda r:(-r[0],r[1]))
        results=[dict(content=content,source=self.path.name,page=None,section=f'lines {first}-{last}',score=round(score,4),metadata=dict(knowledge_source='local_text',line_start=first,line_end=last,chunk_id=i+1,sha256=self._sha)) for score,i,first,last,content in ranked[:top_k]]
        return dict(ok=True,knowledge_source='local_text',query=query,filters={},count=len(results),retrieved_count=len(ranked),truncated=len(ranked)>len(results),results=results,note='로컬 TXT 키워드 검색 결과입니다. 의미적 적합성은 실제 로그와 대조하세요. 일치 결과가 없으면 검색어를 바꿔 조회하거나 판정 보류하세요.')
