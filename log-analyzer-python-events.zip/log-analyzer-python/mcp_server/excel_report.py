"""Streaming .xlsx export using OOXML and the Python standard library only."""
import hashlib
import json
import math
import os
import re
from itertools import chain
from zipfile import ZipFile, ZIP_DEFLATED
from xml.sax.saxutils import escape
from lib.db import get_db
from lib.time import ms_to_display
from .mcp_core import McpToolError
from .ordered import ORDER

NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def column_name(index):
    name=''
    while index:
        index,n=divmod(index-1,26); name=chr(65+n)+name
    return name

def cell(value,index,row,header=False):
    ref=column_name(index)+str(row); style=1 if header else 2
    if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value):
        return f'<c r="{ref}" s="{style}"><v>{value}</v></c>'
    text='' if value is None else str(value)
    if len(text)>32767: raise McpToolError(f'Excel 셀 {ref}의 텍스트가 32767자를 초과합니다. 원문은 DB에 유지됩니다.')
    text=re.sub(r'_x[0-9A-Fa-f]{4}_',lambda m:'_x005F_'+m[0][1:],text)
    text=re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',lambda m:f'_x{ord(m[0]):04X}_',text)
    return f'<c r="{ref}" t="inlineStr" s="{style}"><is><t xml:space="preserve">{escape(text)}</t></is></c>'

def write_sheet(archive,index,headers,rows):
    if len(headers)>16384: raise McpToolError('Excel의 최대 열 수를 초과합니다.')
    with archive.open(f'xl/worksheets/sheet{index}.xml','w') as stream:
        def write(text):stream.write(text.encode('utf-8'))
        write(f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="{NS}"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>')
        for i,h in enumerate(headers,1):
            width=60 if h in ('Description','EventDescription','EvidenceQuote','Observed','Expected','Comparison','Applicability','Result') else 22
            write(f'<col min="{i}" max="{i}" width="{width}" customWidth="1"/>')
        write('</cols><sheetData>')
        count=0
        for n,values in enumerate(chain([headers],rows),1):
            if n>1048576: raise McpToolError('메시지가 Excel 한 시트의 최대 행 수를 초과합니다. CSV는 유지됩니다.')
            write(f'<row r="{n}"'+(' ht="30" customHeight="1"' if n==1 else '')+'>')
            for i,value in enumerate(values,1):write(cell(value,i,n,n==1))
            write('</row>'); count=n-1
        write(f'</sheetData><autoFilter ref="A1:{column_name(len(headers))}{count+1}"/></worksheet>')
    return count

def export_excel(uid,directory,detail):
    from .report import original_headers, REPORT_COLUMNS, analysis_cells
    from .csv_merge import file_stats
    db=get_db(); original=original_headers(file_stats(uid))
    drafts={r['client_id']:dict(r) for r in db.execute("SELECT * FROM event_drafts WHERE upload_id=? AND state='confirmed'",(uid,))}
    refs={}; quotes={}; roles={}
    for cid,draft in drafts.items():
        event=json.loads(draft['data_json'])
        grounding=event.get('labelGrounding') or {}
        if grounding.get('evidenceQuote'): quotes.setdefault(cid,[]).append(grounding['evidenceQuote'])
        refs.setdefault(cid,[]).extend(str(h.get('source') or '')+(' § '+str(h['section']) if h.get('section') else '') for h in grounding.get('sources',[]))
        for role in event['messageRoles']:roles.setdefault(role['messageId'],[]).append(cid+': '+role['role'])
        for kind in ('meaning','boundary'):
            row=db.execute('SELECT * FROM event_validations WHERE upload_id=? AND client_id=? AND revision=? AND review_type=? AND review_json IS NOT NULL ORDER BY rowid DESC LIMIT 1',(uid,cid,draft['revision'],kind)).fetchone()
            if row:
                hits=json.loads(row['response_json']).get('results',[])
                for check in json.loads(row['review_json'])['checks']:
                    quote=check.get('quote','')
                    if quote:
                        quotes.setdefault(cid,[]).append(quote)
                        refs.setdefault(cid,[]).extend(str(h.get('source') or '')+(' § '+str(h['section']) if h.get('section') else '') for h in hits if quote in h.get('content',''))
    def texts(mapping,key):return '\n'.join(dict.fromkeys(mapping.get(key,[])))
    def event_rows():
        for e in db.execute('SELECT * FROM events WHERE upload_id=? ORDER BY start_ms IS NULL,start_ms,id',(uid,)):
            d=drafts.get(e['client_id'],{})
            yield [e['client_id'],e['title'],e['category']+'.'+e['action'],ms_to_display(e['start_ms']),ms_to_display(e['end_ms']),e['status'],e['description'],texts(refs,e['client_id']),texts(quotes,e['client_id']),d.get('revision'), 'confirmed' if d else 'legacy']
    def message_rows():
        for row in db.execute('SELECT * FROM messages WHERE upload_id=? ORDER BY '+ORDER,(uid,)):
            payload=json.loads(row['data_json']); events=detail['byMessage'].get(row['id'],{}).get('events',[])
            yield [row['id'],row['line_no'],row['ts_ms']]+[payload.get(h,'') for h in original]+analysis_cells(row,detail)+['\n'.join(roles.get(row['id'],[])),'\n'.join(dict.fromkeys(q for e in events for q in quotes.get(e['clientId'],[])))]
    def review_rows():
        for cid,draft in drafts.items():
            event=json.loads(draft['data_json']); g=event.get('labelGrounding') or {}
            evidence=db.execute('SELECT * FROM event_label_evidence WHERE id=?',(g.get('labelEvidenceId'),)).fetchone()
            if evidence:
                yield [cid,evidence['base_revision']+1,'label','label_grounding','grounded' if g.get('grounded') else 'undetermined',evidence['scope_json'],g.get('evidenceQuote',''),g.get('rationale',''),'RAG retrieved before labeling',g.get('evidenceQuote',''),draft['ids_json'],evidence['id']]
        for row in db.execute('SELECT * FROM event_validations WHERE upload_id=? AND review_json IS NOT NULL ORDER BY rowid',(uid,)):
            for c in json.loads(row['review_json'])['checks']:
                yield [row['client_id'],row['revision'],row['review_type'],c['code'],c['verdict'],c['observed'],c['expected'],c['comparison'],c['applicability'],c.get('quote',''),json.dumps(c['messageIds']),row['id']]
    def metric_rows():
        for row in db.execute('SELECT * FROM metric_results WHERE upload_id=? ORDER BY created_at',(uid,)):
            result=json.loads(row['result_json']); records=result.get('rows') or [{}]
            for record in records:yield [row['id'],row['event_client_id'],result['operation'],row['arguments_json'],row['scope_json'],json.dumps(record,ensure_ascii=False),json.dumps(result.get('selection'),ensure_ascii=False),row['superseded_reason'] or 'active']
    def relation_rows():
        for cid,draft in drafts.items():
            for relation in json.loads(draft['data_json'])['relations']:
                yield [cid,relation['fromMessageId'],relation['toMessageId'],relation['relation']]
    def finding_rows():
        analysis={f['clientId']:f for d in drafts.values() for f in json.loads(d['data_json']).get('findings',[])}
        for f in db.execute('SELECT * FROM findings WHERE upload_id=? ORDER BY start_ms IS NULL,start_ms,id',(uid,)):
            extra=analysis.get(f['client_id'],{})
            yield [f['client_id'],f['event_id'],f['title'],f['verdict'],extra.get('analysisType','legacy'),'; '.join(extra.get('metricIds',[])),f['description'],f['reference_json']]
    sheets=[
        ('Events',['EventID','Title','EventType','StartTime','EndTime','Status','Description','Reference','EvidenceQuote','Revision','State'],event_rows()),
        ('Messages',['MessageID','SourceRow','TimeMs']+original+REPORT_COLUMNS+['MessageRole','EvidenceQuote'],message_rows()),
        ('Findings',['FindingID','EventDbID','Title','Verdict','AnalysisType','MetricIDs','Description','Reference'],finding_rows()),
        ('Validation',['EventID','Revision','ReviewType','Check','Verdict','Observed','Expected','Comparison','Applicability','EvidenceQuote','MessageIDs','ValidationID'],review_rows()),
        ('Metrics',['MetricID','EventID','Operation','Arguments','MessageIDs','Result','Selection','State'],metric_rows()),
        ('Relations',['EventID','FromMessageID','ToMessageID','Relationship'],relation_rows()),
    ]
    path=directory/'final.xlsx'; temp=directory/'final.xlsx.part'; counts={}
    try:
        with ZipFile(temp,'w',ZIP_DEFLATED,compresslevel=6) as z:
            z.writestr('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(sheets)+1))+'</Types>')
            z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
            z.writestr('xl/workbook.xml',f'<workbook xmlns="{NS}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{name}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_,_) in enumerate(sheets,1))+'</sheets></workbook>')
            z.writestr('xl/_rels/workbook.xml.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
            z.writestr('xl/styles.xml',f'<styleSheet xmlns="{NS}"><fonts count="2"><font><sz val="11"/><name val="맑은 고딕"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="맑은 고딕"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF234D72"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="3"><xf/><xf fontId="1" fillId="2" applyFill="1" applyFont="1"><alignment vertical="center"/></xf><xf><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
            for i,(name,headers,rows) in enumerate(sheets,1): counts[name]=write_sheet(z,i,headers,rows)
        os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)
    digest=sha256(path)
    return dict(name='final.xlsx',sheets=counts,sha256=digest)

def sha256(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024),b''):digest.update(data)
    return digest.hexdigest()
