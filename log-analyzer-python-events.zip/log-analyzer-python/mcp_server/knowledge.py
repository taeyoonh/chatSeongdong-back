"""Evidence source is fixed by the backend per Kilo process, never by the model."""
import os
from pathlib import Path
from functools import lru_cache
from lib.config import load_config
from lib.paths import APP_ROOT
from .rag_client import RagClient,RagError
from .local_text_client import LocalTextClient

def local_knowledge_path():
    raw=os.getenv('LOG_ANALYZER_KNOWLEDGE_PATH') or load_config().get('localKnowledgePath','knowledge/reference.txt')
    path=Path(raw).expanduser()
    return (APP_ROOT/path).resolve() if not path.is_absolute() else path.resolve()

@lru_cache(maxsize=16)
def _local_client(path): return LocalTextClient(path)

def selected_client():
    mode=os.getenv('LOG_ANALYZER_KNOWLEDGE_SOURCE','rag')
    if mode=='rag': return mode,RagClient()
    if mode=='local_text': return mode,_local_client(str(local_knowledge_path()))
    raise RagError('알 수 없는 근거 소스 설정입니다.')

def search_knowledge(args):
    mode,client=selected_client()
    result=client.search(**args)
    result['knowledge_source']=mode
    return result

def check_knowledge():
    mode,client=selected_client()
    result=client.health()
    result['knowledge_source']=mode
    return result
