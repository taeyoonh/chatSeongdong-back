import os
from lib.jobs import get_job
from .mcp_core import McpToolError
def assert_job(upload_id):
    bound=os.getenv('LOG_ANALYZER_JOB_ID')
    if bound:
        if upload_id and str(upload_id)!=bound:raise McpToolError('현재 Kilo 실행에 연결된 작업만 사용할 수 있습니다.')
        upload_id=bound
    if not upload_id: raise McpToolError('uploadId(업로드 ID)가 필요합니다.')
    job=get_job(str(upload_id))
    if not job: raise McpToolError(f'존재하지 않는 업로드 ID입니다: {upload_id}')
    return job
