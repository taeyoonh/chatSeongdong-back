"""MCP stdio: newline-delimited JSON-RPC. stdout is reserved for protocol."""
import json
import sys
class McpToolError(ValueError): pass
class StdioMcpServer:
    def __init__(self,name,version):
        self.name=name; self.version=version; self.tools={}
    def register_tool(self,name,description,input_schema,handler):
        self.tools[name]=(description,input_schema,handler)
    def call_tool(self,params):
        name=params.get('name'); tool=self.tools.get(name)
        try:
            if not tool: raise McpToolError(f'Unknown tool: {name}')
            args=params.get('arguments',{})
            validate(args,tool[1])
            output=tool[2](args)
            return {'content':[{'type':'text','text':json.dumps(output if output is not None else {'ok':True},ensure_ascii=False)}]}
        except McpToolError as err:
            return {'content':[{'type':'text','text':json.dumps({'ok':False,'error':str(err)},ensure_ascii=False)}],'isError':True}
    def dispatch(self,line):
        try: msg=json.loads(line)
        except ValueError: return {'jsonrpc':'2.0','id':None,'error':{'code':-32700,'message':'Parse error'}}
        if not isinstance(msg,dict): return {'jsonrpc':'2.0','id':None,'error':{'code':-32600,'message':'Invalid Request'}}
        if msg.get('id') is None: return None
        result={'jsonrpc':'2.0','id':msg['id']}; method=msg.get('method'); params=msg.get('params') or {}
        try:
            if method=='initialize': value={'protocolVersion':params.get('protocolVersion','2025-06-18'),'capabilities':{'tools':{'listChanged':False}},'serverInfo':{'name':self.name,'version':self.version}}
            elif method=='ping': value={}
            elif method=='tools/list': value={'tools':[{'name':n,'description':t[0],'inputSchema':t[1]} for n,t in self.tools.items()]}
            elif method=='tools/call': value=self.call_tool(params)
            else:
                result['error']={'code':-32601,'message':f'Method not found: {method}'}; return result
            result['result']=value
        except Exception as err:
            print(f'[mcp] {type(err).__name__}: {err}',file=sys.stderr)
            result['error']={'code':-32603,'message':f'Internal error: {err}'}
        return result
    def start(self):
        for line in sys.stdin:
            if not line.strip(): continue
            result=self.dispatch(line)
            if result is not None: print(json.dumps(result,ensure_ascii=False),flush=True)

def validate(value,schema,path='arguments'):
    """Validate the subset of JSON Schema used by the published tool schemas."""
    if 'oneOf' in schema:
        matches=0
        for branch in schema['oneOf']:
            try: validate(value,branch,path); matches+=1
            except McpToolError: pass
        if matches!=1: raise McpToolError(f'{path}: 허용된 형식 중 하나가 필요합니다.')
        return
    kind=schema.get('type')
    valid={'object':isinstance(value,dict),'array':isinstance(value,list),'string':isinstance(value,str),'number':isinstance(value,(int,float)) and not isinstance(value,bool),'integer':isinstance(value,int) and not isinstance(value,bool),'null':value is None,'boolean':isinstance(value,bool)}
    if kind and not valid.get(kind,True): raise McpToolError(f'{path}: {kind} 형식이 필요합니다.')
    if 'enum' in schema and value not in schema['enum']: raise McpToolError(f'{path}: {schema["enum"]} 중 하나여야 합니다.')
    if kind=='object':
        props=schema.get('properties',{})
        for key in schema.get('required',[]):
            if key not in value: raise McpToolError(f'{path}.{key}: 필수 항목입니다.')
        for key,item in value.items():
            if key in props: validate(item,props[key],f'{path}.{key}')
            elif schema.get('additionalProperties') is False: raise McpToolError(f'{path}.{key}: 허용되지 않은 항목입니다.')
    elif kind=='array':
        if len(value)>schema.get('maxItems',100000): raise McpToolError(f'{path}: 항목이 너무 많습니다.')
        for i,item in enumerate(value): validate(item,schema.get('items',{}),f'{path}[{i}]')
