"""Stable indexed traversal, including equal timestamps and undated rows."""
from lib.db import get_db

ORDER = '(ts_ms IS NULL),ts_ms,source_file,line_no,id'

def ordered_ids(upload_id, ids):
    if not ids:
        return []
    return get_db().execute(
        'SELECT * FROM messages WHERE upload_id=? AND id IN ('+
        ','.join('?' for _ in ids)+') ORDER BY '+ORDER,
        (upload_id,*ids)).fetchall()

def rows_after(upload_id, last=None, limit=200):
    """Seek from a stored message key; never scan an OFFSET prefix."""
    db=get_db(); result=[]
    if last is None or last['ts_ms'] is not None:
        sql='SELECT * FROM messages WHERE upload_id=? AND ts_ms IS NOT NULL'
        params=[upload_id]
        if last is not None:
            sql+=' AND (ts_ms,source_file,line_no,id) > (?,?,?,?)'
            params.extend(last[k] for k in ('ts_ms','source_file','line_no','id'))
        sql+=' ORDER BY ts_ms,source_file,line_no,id LIMIT ?'
        result=list(db.execute(sql,(*params,limit)))
    remaining=limit-len(result)
    if remaining:
        sql='SELECT * FROM messages WHERE upload_id=? AND ts_ms IS NULL'
        params=[upload_id]
        if last is not None and last['ts_ms'] is None:
            sql+=' AND (source_file,line_no,id) > (?,?,?)'
            params.extend(last[k] for k in ('source_file','line_no','id'))
        sql+=' ORDER BY source_file,line_no,id LIMIT ?'
        result.extend(db.execute(sql,(*params,remaining)))
    return result
