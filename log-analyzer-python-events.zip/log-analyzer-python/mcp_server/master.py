"""Publish the complete, chronologically merged input before AI analysis."""
import csv
import json
import os
from lib.db import get_db
from lib.time import ms_to_display
from .csv_merge import file_stats, safe_parse
from .ordered import ORDER

def export_master_csv(upload_id, directory):
    directory.mkdir(parents=True,exist_ok=True)
    headers=list(dict.fromkeys(h for s in file_stats(upload_id) for h in safe_parse(s['headerOrder'],[])))
    # Allocate metadata columns without overwriting any original CSV fields.
    used=set(headers); meta=[]
    for base in ('_MessageId','_TimeMs','_Time','_SourceFile','_SourceLine'):
        name=base; n=2
        while name in used:
            name=f'{base}__{n}'; n+=1
        used.add(name); meta.append(name)
    output=directory/'master.csv'; temp=directory/'master.csv.part'
    db=get_db(); db.execute('BEGIN'); count=0
    try:
        with temp.open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.writer(stream); writer.writerow(meta+headers)
            for r in db.execute('SELECT * FROM messages WHERE upload_id=? ORDER BY '+ORDER,(upload_id,)):
                data=json.loads(r['data_json'])
                writer.writerow([r['id'],r['ts_ms'],ms_to_display(r['ts_ms']),r['source_file'],r['line_no']]+[data.get(h,'') for h in headers]); count+=1
            stream.flush(); os.fsync(stream.fileno())
        db.execute('COMMIT')
        os.replace(temp,output)
    except BaseException:
        if db.in_transaction:db.execute('ROLLBACK')
        temp.unlink(missing_ok=True)
        raise
    return dict(name='master.csv',rows=count,columns=len(meta)+len(headers),metadataColumns=meta)
