"""Run from project root: python -m mcp_server.index"""
import sys
from lib.db import close_db
from lib.jobs import get_job_view
from .mcp_core import StdioMcpServer, McpToolError
from .rag_client import RagError
from .knowledge import search_knowledge, check_knowledge
from .auth import assert_job
from .dataset import prepare_dataset
from .queries import summarize_dataset
from .workflow import guarded_finalize_analysis as finalize_analysis, next_analysis_batch, complete_analysis_batch
from .event_workflow import label_event, validate_event, confirm_event, query_messages, calculate_metrics, assert_confirmed
from .report import build_report,verify_report
S={'type':'string'}; N={'type':'number'}
TIME_ARG={'oneOf':[N,dict(type='string',description='epoch ms 또는 YYYY-MM-DD HH:MM:SS / HH:MM:SS')]}
def arr(items,**extra): return dict(type='array',items=items,**extra)
def obj(props,required=()): return dict(type='object',properties=props,required=list(required),additionalProperties=False)
def enum(*values): return dict(type='string',enum=list(values))
SELECTOR=obj(dict(sourceFile=S,fromMs=TIME_ARG,toMs=TIME_ARG,field=S,values=arr(S)))
LINK_SPEC=obj(dict(messageIds=arr({'type':'integer'},maxItems=5000),selector=SELECTOR))
EVENT=obj(dict(clientId=S,parentId=S,category=enum('track','platform','control','engagement','communication','other'),action=enum('observed','updated','correlated','changed','dropped'),title=S,subject={},startMs=TIME_ARG,endMs=TIME_ARG,description=S,status=enum('normal','anomaly','undetermined'),severity=enum('normal','warn','danger'),messageLinks=LINK_SPEC,evidenceId=S,evidenceQuote=S),('clientId','category','action','title','messageLinks','evidenceId','description'))
FINDING=obj(dict(clientId=S,eventId={'oneOf':[S,{'type':'null'}]},kind=enum('anomaly','review'),title=S,description=S,verdict=enum('anomaly','undetermined'),severity=enum('normal','warn','danger'),startMs=TIME_ARG,endMs=TIME_ARG,references=arr({'oneOf':[S,obj(dict(document=S,section=S),('document',))]}),messageLinks=LINK_SPEC,evidenceId=S,evidenceQuote=S),('clientId','title','messageLinks','evidenceId','description'))
def job_schema(extra=None,required=()): return obj(dict(uploadId=S)|dict(extra or {}),required)
ROLE=obj(dict(messageId={'type':'integer'},role=S),('messageId','role'))
RELATION=obj(dict(fromMessageId={'type':'integer'},toMessageId={'type':'integer'},relation=S),('fromMessageId','toMessageId','relation'))
DRAFT_FINDING=obj({k:v for k,v in FINDING['properties'].items() if k not in ('evidenceId','evidenceQuote','references','eventId')}|dict(analysisType=enum('metric','relationship'),metricIds=arr(S)),('clientId','title','description','verdict','messageLinks','analysisType'))
DRAFT_PROPS={k:v for k,v in EVENT['properties'].items() if k not in ('evidenceId','evidenceQuote')}
DRAFT_PROPS.update(action=enum('observed','updated','correlated','changed','dropped','started','ended'),messageRoles=arr(ROLE),relations=arr(RELATION),findings=arr(DRAFT_FINDING),metricIds=arr(S),labelGrounding=dict(type='object',description='inspect 반환값. 제출 시 서버가 재검증하여 대체합니다.'))
DRAFT=obj(DRAFT_PROPS,('clientId','category','action','title','description','messageLinks','messageRoles','relations'))
CHECK=obj(dict(code=S,verdict=enum('pass','fail','undetermined'),observed=S,expected=S,comparison=S,applicability=S,quote=S,messageIds=arr({'type':'integer'})),('code','verdict','observed','expected','comparison','applicability','quote','messageIds'))
def reviewed_report(args):
    job=assert_job(args.get('uploadId')); assert_confirmed(job['id']); return build_report(args)
def dataset(args):
    job=assert_job(args.get('uploadId')); return prepare_dataset(job['id'])
def status(args):
    from lib.db import get_db
    from .analysis import coverage_counts
    job=assert_job(args.get('uploadId')); view=get_job_view(job['id'])
    batch=get_db().execute('SELECT id,start_offset,row_count FROM analysis_batches WHERE upload_id=? AND completed_at IS NULL',(job['id'],)).fetchone()
    completed=get_db().execute('SELECT COALESCE(SUM(row_count),0) FROM analysis_batches WHERE upload_id=? AND completed_at IS NOT NULL',(job['id'],)).fetchone()[0]
    drafts=[dict(r) for r in get_db().execute('SELECT client_id AS clientId,revision,state FROM event_drafts WHERE upload_id=? ORDER BY updated_at',(job['id'],))]
    return dict(ok=True,status=view['status'],error=view['error'],files=view['files'],prepared=job['dataset_ready_at'] is not None,finalized=job['finalized_at'] is not None,processed=completed,activeBatch=dict(batch) if batch else None,coverage=coverage_counts(job['id']),eventDrafts=drafts)
def search_rag(args):
    try:
        return search_knowledge(args)
    except RagError as err:
        raise McpToolError(str(err)) from err

def rag_connection_check(args):
    try:
        return check_knowledge()
    except RagError as err:
        raise McpToolError(str(err)) from err

def create_server():
    server=StdioMcpServer('log-analyzer','0.4.0')
    definitions=[
      ('search_rag','작업별 근거 검색. 토글 ON은 사내 RAG, OFF는 서버에 지정된 TXT를 검색하며 모델이 소스를 바꿀 수 없습니다. 응답 knowledge_source를 확인하세요. 라벨링 및 이벤트 유효성 검토 도중 모르는 메시지 의미/필드/운용 절차/주기/판정 기준이 생길 때마다 호출하세요. 검색→실제 로그 대조→필요시 재검색을 반복하세요. 이미 확인한 동일 근거는 재사용할 수 있습니다. J/K 모두 검색 가능하며 ON의 검색 범위는 RAG_DATASET_IDS, OFF는 지정 TXT 파일입니다. 문서명·절·본문·점수를 반환. message_id/dfi/dui/rule_type은 질문 문자열 조건이며 강제 서버 필터가 아닙니다. top_k는 최대 20개의 반환 결과 수 상한입니다.',obj(dict(query=S,message_id=S,dfi=S,dui=S,rule_type=S,top_k={'type':'integer'}),('query',)),search_rag),
      ('rag_connection_check','선택된 근거 소스 확인. ON은 RAG health, OFF는 로컬 TXT 읽기 가능 여부를 검사합니다. ON health 성공이 검색 API 성공을 보장하지 않습니다.',obj({}),rag_connection_check),
      ('prepare_dataset','업로드 ZIP의 CSV를 DB에 통합하고 시간순 master.csv를 생성합니다. 이미 준비된 작업은 분석/배치를 보존하고 재사용합니다.',job_schema(),dataset),
      ('merge_csv','CSV 묶음을 정규화하여 시간순 master.csv를 생성합니다. 서버 선행 준비 결과가 있으면 그대로 재사용합니다.',job_schema(),dataset),
      ('summarize_dataset','총 행 수/시간 범위/히스토그램/파일 컬럼 및 field 값 분포. 실제 필드명을 확인하세요.',job_schema(dict(bucketSec=N,file=S,fromMs=TIME_ARG,toMs=TIME_ARG,field=S)),summarize_dataset),
      ('query_messages','label_event 초안의 실제 메시지 범위에서 원본을 조회합니다. 이벤트 후보를 먼저 지정하세요. 원본 필드 전체가 기본 반환됩니다.',job_schema(dict(eventClientId=S,sourceFile=S,fromMs=TIME_ARG,toMs=TIME_ARG,field=S,values=arr(S),fields=arr(S),limit=N,offset=N),('eventClientId',)),query_messages),
      ('calculate_metrics','이벤트 초안의 원본 행을 직접 계산하고 조건·대상·결과를 DB에 보존합니다. metricId를 반환하며 초안 리비전이 증가합니다. 이후 두 RAG 검증에서 계산 원본을 반드시 검토합니다.',job_schema(dict(eventClientId=S,messageLinks=LINK_SPEC,operation=enum('first_last','intervals','field_changes','routes'),groupBy=arr(S),field=S,fields=arr(S),sourceFile=S,fromMs=TIME_ARG,toMs=TIME_ARG,thresholdMs=N,limit=N),('eventClientId','operation')),calculate_metrics),
      ('next_analysis_batch','시간순으로 다음 200행을 엽니다. 현재 구간 완료 전 재호출은 동일 구간 반환. 전후 20행은 문맥이며 저장 대상 아님. previousState를 이어받으세요.',job_schema(),next_analysis_batch),
      ('label_event','prepare: clientId/messageLinks로 실제 원본을 원격 RAG에서 먼저 검색합니다. 반환 근거로 의미·역할·관계·이벤트를 판단하세요. submit: event/labelEvidenceId/evidenceQuote/rationale로 근거에 연결된 초안 저장. 수정 시에도 다시 prepare해야 하며 범위·리비전·원문 인용을 검사합니다. 근거가 없으면 undetermined만 가능. inspect: clientId로 조회.',job_schema(dict(action=enum('prepare','submit','inspect'),event=DRAFT,clientId=S,messageLinks=LINK_SPEC,query=S,labelEvidenceId=S,evidenceQuote=S,rationale=S)),label_event),
      ('validate_event','prepare: 의미(meaning) 또는 경계(boundary) 검증용 RAG를 서버가 실제 로그·관계·저장 계산으로 직접 조회합니다. query에 구체적인 영문 메시지명·절차 질문을 보완할 수 있습니다. submit: requiredChecks마다 관측·기대·조건·비교·원문 인용을 제출합니다. 두 종류 모두 같은 리비전에서 반복 검증하세요.',job_schema(dict(clientId=S,action=enum('prepare','submit'),reviewType=enum('meaning','boundary'),query=S,validationId=S,checks=arr(CHECK),conclusion=S),('clientId','action')),validate_event),
      ('confirm_event','현재 리비전의 meaning/boundary 검증을 모두 통과한 이벤트만 확정합니다. fail은 수정·재검증, 근거 부족은 undetermined만 허용합니다. 확정 전 초안은 최종 CSV/Excel에 기록되지 않습니다.',job_schema(dict(clientId=S),('clientId',)),confirm_event),
      ('complete_analysis_batch','현재 200행이 모두 이벤트 초안/확정 이벤트에 포함됐는지 확인하고 읽기 진행을 완료합니다. 긴 이벤트는 다음 구간에서 초안을 이어갈 수 있습니다. carryState에 진행 중 이벤트와 다음 확인사항을 기록하세요.',job_schema(dict(batchId=S,carryState=S),('batchId','carryState')),complete_analysis_batch),
      ('finalize_analysis','모든 구간의 순차 처리 및 complete_analysis_batch 완료 후 한 번 확정. 미완료 구간이 있으면 거부. 확정 이후 변경 불가.',job_schema(),finalize_analysis),
      ('build_report','모든 이벤트 검증·확정 후 원본+분석 CSV, 상세 Excel, 타임라인 생성. Excel에는 이벤트 자연어 설명·근거 인용·검증 이력·저장 계산을 기록합니다.',job_schema(dict(agentSummary=S)),reviewed_report),
      ('verify_report','DB·CSV·참조·이벤트시간·커버리지·보고서 교차 검증. completed/verification_failed 확정. 구조 검증이며 AI 판정 정확성 보증은 아닙니다.',job_schema(),verify_report),
      ('get_job_status','작업 상태/오류/파일 통계 조회.',job_schema(),status)]
    for definition in definitions: server.register_tool(*definition)
    return server
if __name__=='__main__':
    if hasattr(sys.stdin,'reconfigure'): sys.stdin.reconfigure(encoding='utf-8')
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8',errors='strict')
    try: create_server().start()
    finally: close_db()
