"""AI judgments only. MCP never invents protocol-specific normality rules."""
import json
from contextlib import nullcontext
from lib.db import get_db,transaction
from lib.jobs import now
from .auth import assert_job
from .mcp_core import McpToolError
from .csv_merge import file_stats,safe_parse
from .queries import base_where,add_field_filter,time_range_ms,parse_time_arg
EVENT_STATUSES=('normal','anomaly','undetermined')
MAX_LINKS=5000
def str_val(value,what):
    if not isinstance(value,str) or not value.strip(): raise McpToolError(f'{what}: 비어 있지 않은 문자열이 필요합니다.')
    return value.strip()
def check_enum(value,allowed,what,fallback=None):
    value=fallback if value in (None,'') else value
    if value not in allowed: raise McpToolError(f'{what}: {allowed} 중 하나여야 합니다.')
    return value
def parse_time(value,anchor,what):
    return None if value in (None,'') else parse_time_arg(value,anchor,what)
def resolve_links(upload_id,links,label):
    if not isinstance(links,dict): raise McpToolError(f'{label}: messageLinks가 필요합니다.')
    if ('messageIds' in links)==('selector' in links): raise McpToolError(f'{label}: messageIds/selector 중 하나가 필요합니다.')
    db=get_db()
    if 'messageIds' in links:
        raw=links['messageIds']
        if not isinstance(raw,list) or not raw or any(not isinstance(v,int) or isinstance(v,bool) for v in raw): raise McpToolError(f'{label}: 정수 messageIds 목록이 필요합니다.')
        ids=list(dict.fromkeys(raw))
        if len(ids)>MAX_LINKS: raise McpToolError(f'{label}: 최대 {MAX_LINKS}개까지 연결할 수 있습니다.')
        for offset in range(0,len(ids),500):
            chunk=ids[offset:offset+500]
            count=db.execute('SELECT COUNT(*) FROM messages WHERE upload_id=? AND id IN ('+','.join('?' for _ in chunk)+')',[upload_id,*chunk]).fetchone()[0]
            if count!=len(chunk): raise McpToolError(f'{label}: 다른 데이터셋 또는 존재하지 않는 메시지 ID입니다.')
    else:
        sel=links['selector']; stats=file_stats(upload_id)
        if not isinstance(sel,dict) or not sel: raise McpToolError(f'{label}: 범위를 지정한 selector가 필요합니다.')
        where,params=base_where(upload_id,stats,sel); add_field_filter(where,params,stats,sel)
        ids=[r[0] for r in db.execute('SELECT id FROM messages WHERE '+' AND '.join(where)+' LIMIT ?',[*params,MAX_LINKS+1])]
        if len(ids)>MAX_LINKS: raise McpToolError(f'{label}: 최대 {MAX_LINKS}개입니다. 시간/필드 범위를 좁히세요.')
        if not ids: raise McpToolError(f'{label}: 선택된 메시지가 없습니다.')
    return ids
def normalize_refs(refs):
    out=[]
    for item in refs or []:
        if isinstance(item,str) and item.strip(): out.append(dict(document=item.strip(),section=None))
        elif isinstance(item,dict):
            doc=item.get('document') or item.get('title') or item.get('name')
            if doc: out.append(dict(document=str(doc).strip(),section=str(item['section']).strip() if item.get('section') else None))
    return out[:10]
def replace_link_rows(db,table,row_id,ids):
    column={'event_messages':'event_id','finding_messages':'finding_id'}[table]
    db.execute(f'DELETE FROM {table} WHERE {column}=?',(row_id,))
    db.executemany(f'INSERT INTO {table}({column},message_id) VALUES(?,?)',((row_id,i) for i in ids))
def save_analysis(args, _guard=None, _db=None):
    job=assert_job(args.get('uploadId')); evs=args.get('events') or []; fnds=args.get('findings') or []
    if not evs and not fnds: raise McpToolError('events 또는 findings 배열이 필요합니다.')
    anchor,_=time_range_ms(file_stats(job['id'])); ev_parsed=[]; fn_parsed=[]
    for i,e in enumerate(evs):
        label=f'events[{i}]'; e=dict(e)
        for key in ('clientId','category','action','title'): e[key]=str_val(e.get(key),label+'.'+key)
        check_enum(e['category'],('track','platform','control','engagement','communication','other'),label+'.category')
        check_enum(e['action'],('observed','updated','correlated','changed','dropped','started','ended'),label+'.action')
        e['status']=check_enum(e.get('status'),EVENT_STATUSES,label+'.status','undetermined')
        if e.get('severity'): check_enum(e['severity'],('normal','warn','danger'),label+'.severity')
        for key in ('startMs','endMs'): e[key]=parse_time(e.get(key),anchor,label+'.'+key)
        if e['startMs'] is not None and e['endMs'] is not None and e['startMs']>e['endMs']: raise McpToolError(label+': 시작 시간이 종료 시간보다 늦습니다.')
        e['ids']=resolve_links(job['id'],e.get('messageLinks'),label); ev_parsed.append(e)
    for i,f in enumerate(fnds):
        label=f'findings[{i}]'; f=dict(f)
        for key in ('clientId','title'): f[key]=str_val(f.get(key),label+'.'+key)
        f['verdict']=check_enum(f.get('verdict'),('anomaly','undetermined'),label+'.verdict','anomaly')
        f['kind']=check_enum(f.get('kind'),('anomaly','review'),label+'.kind','anomaly')
        if f.get('severity'): check_enum(f['severity'],('normal','warn','danger'),label+'.severity')
        for key in ('startMs','endMs'): f[key]=parse_time(f.get(key),anchor,label+'.'+key)
        if f['startMs'] is not None and f['endMs'] is not None and f['startMs']>f['endMs']: raise McpToolError(label+': 시작 시간이 종료 시간보다 늦습니다.')
        f['ids']=resolve_links(job['id'],f.get('messageLinks'),label); fn_parsed.append(f)
    for items in (ev_parsed,fn_parsed):
        if len({x['clientId'] for x in items})!=len(items): raise McpToolError('같은 호출 안에 clientId가 중복되었습니다.')
    # Links resolve by stable IDs returned by SQLite RETURNING, including UPDATE paths.
    with (transaction() if _db is None else nullcontext(_db)) as db:
        if _guard:
            _guard(db)
            # The workflow derives references from the real server response.
            for parsed,original in zip(fn_parsed,fnds):
                parsed['references']=original.get('references',[])
        state=db.execute('SELECT finalized_at FROM jobs WHERE id=?',(job['id'],)).fetchone()
        if state['finalized_at'] is not None: raise McpToolError('확정된 분석은 변경할 수 없습니다. 새 업로드로 다시 분석하세요.')
        for e in ev_parsed:
            row=db.execute('''INSERT INTO events(upload_id,client_id,parent_id,category,action,title,subject_json,start_ms,end_ms,description,status,severity,created_at)
VALUES(?,?,NULL,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(upload_id,client_id) DO UPDATE SET category=excluded.category,action=excluded.action,title=excluded.title,subject_json=excluded.subject_json,start_ms=excluded.start_ms,end_ms=excluded.end_ms,description=excluded.description,status=excluded.status,severity=excluded.severity RETURNING id''',(job['id'],e['clientId'],e['category'],e['action'],e['title'],json.dumps(e.get('subject'),ensure_ascii=False),e['startMs'],e['endMs'],e.get('description',''),e['status'],e.get('severity'),now())).fetchone()
            e['rowId']=row['id']; replace_link_rows(db,'event_messages',e['rowId'],e['ids'])
        # Two passes allow a child to appear before its parent in a batch.
        for e in ev_parsed:
            parent=None
            if e.get('parentId'):
                p=db.execute('SELECT id FROM events WHERE upload_id=? AND client_id=?',(job['id'],e['parentId'])).fetchone()
                if not p: raise McpToolError(f"parent 이벤트가 없습니다: {e['parentId']}")
                parent=p['id']
            db.execute('UPDATE events SET parent_id=? WHERE id=?',(parent,e['rowId']))
        graph={r['id']:r['parent_id'] for r in db.execute('SELECT id,parent_id FROM events WHERE upload_id=?',(job['id'],))}
        for key in graph:
            seen=set(); node=key
            while node is not None:
                if node in seen: raise McpToolError('이벤트 상하위 관계에 순환이 있습니다.')
                seen.add(node); node=graph.get(node)
        for f in fn_parsed:
            event=None
            if f.get('eventId'):
                e=db.execute('SELECT id FROM events WHERE upload_id=? AND client_id=?',(job['id'],f['eventId'])).fetchone()
                if not e: raise McpToolError(f"참조 이벤트가 없습니다: {f['eventId']}")
                event=e['id']
            row=db.execute('''INSERT INTO findings(upload_id,client_id,event_id,kind,title,description,verdict,severity,start_ms,end_ms,reference_json,created_at)
VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(upload_id,client_id) DO UPDATE SET event_id=excluded.event_id,kind=excluded.kind,title=excluded.title,description=excluded.description,verdict=excluded.verdict,severity=excluded.severity,start_ms=excluded.start_ms,end_ms=excluded.end_ms,reference_json=excluded.reference_json RETURNING id''',(job['id'],f['clientId'],event,f['kind'],f['title'],f.get('description',''),f['verdict'],f.get('severity'),f['startMs'],f['endMs'],json.dumps(normalize_refs(f.get('references')),ensure_ascii=False),now())).fetchone()
            replace_link_rows(db,'finding_messages',row['id'],f['ids'])
        db.execute("UPDATE jobs SET status='analyzing',error=NULL,updated_at=? WHERE id=?",(now(),job['id']))
    ev_links=sum(len(e['ids']) for e in ev_parsed); fn_links=sum(len(f['ids']) for f in fn_parsed)
    return dict(ok=True,saved=dict(events=len(ev_parsed),findings=len(fn_parsed)),linkedMessages=dict(eventLinks=ev_links,findingLinks=fn_links,uniqueMessages=len({i for x in ev_parsed+fn_parsed for i in x['ids']})))

def linked_sets(upload_id):
    db=get_db()
    def ids(sql): return {r[0] for r in db.execute(sql,(upload_id,))}
    return dict(anomalyFindings=ids("SELECT DISTINCT fm.message_id FROM finding_messages fm JOIN findings f ON f.id=fm.finding_id WHERE f.upload_id=? AND f.verdict='anomaly'"),undeterminedFindings=ids("SELECT DISTINCT fm.message_id FROM finding_messages fm JOIN findings f ON f.id=fm.finding_id WHERE f.upload_id=? AND f.verdict='undetermined'"),inAnyEvent=ids('SELECT DISTINCT em.message_id FROM event_messages em JOIN events e ON e.id=em.event_id WHERE e.upload_id=?'),inNormalEvents=ids("SELECT em.message_id FROM event_messages em JOIN events e ON e.id=em.event_id WHERE e.upload_id=? GROUP BY em.message_id HAVING SUM(CASE WHEN e.status<>'normal' THEN 1 ELSE 0 END)=0"))
def status_for(message_id,sets):
    if message_id in sets['anomalyFindings']: return 'anomaly'
    if message_id in sets['undeterminedFindings']: return 'undetermined'
    if message_id in sets['inAnyEvent']: return 'normal' if message_id in sets['inNormalEvents'] else 'undetermined'
    return 'unreviewed'
def refs_text(refs):
    texts=[]
    for r in refs:
        if isinstance(r,str): texts.append(r)
        elif isinstance(r,dict) and r.get('document'): texts.append(r['document']+(' § '+r['section'] if r.get('section') else ''))
    return '; '.join(dict.fromkeys(texts))
def per_message_detail(upload_id):
    db=get_db(); sets=linked_sets(upload_id); events={}; findings={}
    event_refs={}
    for v in db.execute("SELECT v.* FROM event_validations v JOIN event_drafts d ON d.upload_id=v.upload_id AND d.client_id=v.client_id AND d.revision=v.revision WHERE v.upload_id=? AND d.state='confirmed' AND v.review_json IS NOT NULL AND v.rowid=(SELECT MAX(v2.rowid) FROM event_validations v2 WHERE v2.upload_id=v.upload_id AND v2.client_id=v.client_id AND v2.revision=v.revision AND v2.review_type=v.review_type)",(upload_id,)):
        hits=safe_parse(v['response_json'],{}).get('results',[])
        for c in safe_parse(v['review_json'],{}).get('checks',[]):
            quote=c.get('quote','')
            if quote:
                event_refs.setdefault(v['client_id'],[]).extend(dict(document=str(h['source']),section=str(h['section']) if h.get('section') else None) for h in hits if h.get('source') and quote in h.get('content',''))
    for r in db.execute('SELECT em.message_id m,e.client_id,e.category,e.action,e.title,e.description FROM event_messages em JOIN events e ON e.id=em.event_id WHERE e.upload_id=? ORDER BY e.id',(upload_id,)):
        events.setdefault(r['m'],[]).append(dict(clientId=r['client_id'],type=r['category']+'.'+r['action'],title=r['title'],description=r['description'],references=event_refs.get(r['client_id'],[])))
    for r in db.execute('SELECT fm.message_id m,f.* FROM finding_messages fm JOIN findings f ON f.id=fm.finding_id WHERE f.upload_id=? ORDER BY f.id',(upload_id,)):
        findings.setdefault(r['m'],[]).append(dict(clientId=r['client_id'],title=r['title'],description=r['description'],verdict=r['verdict'],references=safe_parse(r['reference_json'],[])))
    by_message={}
    for key in events.keys()|findings.keys():
        evs=events.get(key,[]); fnds=findings.get(key,[]); status=status_for(key,sets); reason=''; reference=refs_text([ref for e in evs for ref in e['references']])
        selected=[f for f in fnds if status=='anomaly' or f['verdict']=='undetermined']
        if status in ('anomaly','undetermined'):
            reason=' / '.join(f['description'] or f['title'] for f in selected) or ' / '.join(e['title'] for e in evs) or '이벤트 근거 확인 필요'
            if status=='undetermined': reason='판정 보류 ('+reason+')'
            reference=refs_text([r for f in selected for r in f['references']]+[ref for e in evs for ref in e['references']])
        by_message[key]=dict(status=status,events=evs,findings=fnds,reason=reason,reference=reference)
    return dict(byMessage=by_message,sets=sets)
def coverage_counts(upload_id):
    sets=linked_sets(upload_id); total=get_db().execute('SELECT COUNT(*) FROM messages WHERE upload_id=?',(upload_id,)).fetchone()[0]
    result=dict(total=total,anomaly=0,undetermined=0,normal=0,unreviewed=0)
    keys=sets['anomalyFindings']|sets['undeterminedFindings']|sets['inAnyEvent']
    for key in keys: result[status_for(key,sets)]+=1
    result['reviewed']=len(keys); result['unreviewed']=total-len(keys)
    return result
def finalize_analysis(args):
    job=assert_job(args.get('uploadId')); cov=coverage_counts(job['id']); warnings=[]
    if cov['total'] and cov['reviewed']==0: warnings.append('이벤트/Finding에 연결된 메시지가 없습니다.')
    elif cov['total'] and cov['unreviewed']/cov['total']>.5: warnings.append(f"미분석 메시지가 {cov['unreviewed']}개입니다. 요약에 미분석 범위를 설명하세요.")
    get_db().execute('UPDATE jobs SET finalized_at=COALESCE(finalized_at,?),updated_at=? WHERE id=?',(now(),now(),job['id']))
    return dict(ok=True,finalized=True,coverage=cov,warnings=warnings)
