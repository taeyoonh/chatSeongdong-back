# 시험 로그 분석기 — 이벤트 초안·반복 검증·확정 후 Excel

Python 3.10 이상과 설치된 Kilo CLI가 필요합니다. Python 외부 패키지는 필요하지 않습니다.
첨부 프로젝트의 UUID 작업 ID 및 웹 API 구조를 유지한 수정본입니다.
숫자 ID·프로젝트 테이블 기반 REST API v0.4로 변환한 프로젝트는 아닙니다.

## 실행

Windows에서는 `start.bat`을 실행합니다. 또는 프로젝트 폴더에서:

```bat
py -3 run.py
```

실행 후 `http://127.0.0.1:3000/`에 접속합니다. Kilo 실행 경로, Provider와 모델은
화면의 Kilo 설정에서 관리합니다. MCP를 실행하는 Python이 다른 경우:

```bat
py -3 scripts/configure_mcp.py
```

서버 IP/포트·파일 크기 등은 `config/local-config.json`에서 설정합니다.
파일이 없으면 `local-config.example.json`을 사용합니다.

## 이번 수정 내용

- Kilo 전체 실행 시간 제한과 그 제한을 넘겨 프로세스를 종료하던 코드를 제거했습니다.
  명시적인 서버 종료는 Kilo 프로세스 트리를 중단합니다.
  RAG HTTP 요청, 업로드 연결 및 MCP 개별 도구 요청의 시간 제한과는 별개입니다.
- 작업 액세스 토큰 생성·전달·검증을 제거했습니다. Kilo가 실행한 MCP는
  `LOG_ANALYZER_JOB_ID` 환경변수로 해당 작업에 연결됩니다. 다른 작업 ID 사용은 거절합니다.
  RAG 서버 인증과 모델 Provider API 키는 그대로 필요합니다.
- 서버가 Kilo를 실행하기 전에 데이터 준비와 `master.csv` 생성을 완료합니다.
- 준비된 작업에 `prepare_dataset`를 다시 호출해도 메시지 ID·이벤트·진행 배치를 보존합니다.
  새 원본은 새 작업으로 업로드합니다. 강제 초기화는 내부 Python 함수의 `force=True`만 지원하며 MCP에는 노출하지 않습니다.
- 순차 분석의 다음 200행 조회에서 `OFFSET`을 제거했습니다. 마지막 메시지의 정렬 키 다음을
  인덱스로 찾습니다. 완료 전 재요청은 동일 배치의 저장된 메시지 ID를 반환합니다.
- 실패한 작업은 화면의 **기존 분석 이어서 실행** 버튼으로 동일 Job을 재개합니다.
  완성된 master가 없어졌다면 DB에서 다시 생성합니다. 기존 분석·배치를 초기화하지 않습니다.

## 데이터 정렬과 master.csv

여러 CSV를 정규화해 SQLite `messages` 테이블에 저장합니다. 물리적 삽입 순서에 의존하지 않습니다.
다음 공통 정렬 기준으로 master와 분석 배치를 구성합니다.

1. 시각이 있는 메시지 먼저
2. `ts_ms` 오름차순
3. 원본 파일명
4. 원본 행번호
5. 메시지 ID

시각 해석이 불가능한 행은 마지막에 파일명·행번호·ID 순으로 배치하며 임의의 시간을 부여하지 않습니다.
동일 시각의 파일명 순서는 재현 가능한 정렬용이며 실제 인과 순서를 뜻하지 않습니다.

경로: `data/results/<작업 UUID>/master.csv`

CSV는 UTF-8 BOM을 사용하며 모든 파일의 원본 필드를 합집합으로 보존합니다.
앞에 `_MessageId`, `_TimeMs`, `_Time`, `_SourceFile`, `_SourceLine` 메타데이터 열을 붙입니다.
원본에 같은 이름이 있으면 메타데이터 쪽에 `__2` 등의 접미사를 붙여 원본을 보존합니다.
`_TimeMs`는 밀리초 정밀도의 정렬 시각이며 `_Time`은 초 단위 표시용 문자열입니다.
master에는 분석 열을 넣지 않습니다. 분석 결과는 DB 및 `final.csv` / `final.xlsx`에서 관리합니다.

완성 전에는 `master.csv.part`에 기록한 후 교체합니다. master 생성에 실패하면 Kilo는 시작하지 않습니다.
`GET /api/read-jobs/<작업 UUID>/master`로 다운로드할 수도 있습니다.

## 이벤트 초안·검증·확정 흐름

설계와 호출 인자는 [EVENT_WORKFLOW.md](EVENT_WORKFLOW.md)에 정리했습니다.

```text
master.csv → 시간순 200행 읽기 → label_event prepare(RAG) → 근거 확인 → submit(초안)
→ 초안 범위 조회·계산 → validate_event 의미 검토 + 경계 검토
→ confirm_event → 다음 읽기 구간
→ 전 이벤트 확정 → finalize_analysis → build_report(CSV·Excel) → verify_report
```

200행은 읽기 단위이며 이벤트 경계가 아닙니다. 진행 중 이벤트 초안은 다음 구간까지 이어갑니다.
초안 수정·계산 추가는 이전 검증을 무효화하며, 두 종류의 최신 검토 완료 전 확정은 거절합니다.
라벨링 전에는 원본으로, 검증 시에는 실제 로그·역할·관계·저장 계산 원본으로 원격 RAG를 요청합니다.
직접 저장하던 MCP save_analysis/search_event_rag는 새 label_event/validate_event/confirm_event 흐름으로 대체했습니다.
최종 Excel은 화면의 분석 Excel 다운로드 또는 /api/read-jobs/<작업 UUID>/xlsx로 받습니다.

## 저장과 재개

- 원본 ZIP: `data/uploads/<작업 UUID>/upload.zip`
- 통합 원본 CSV: `data/results/<작업 UUID>/master.csv`
- 분석·근거·배치·다음 구간 메모: SQLite `data/app.db`
- 저장/배치 완료 후 스냅샷: `data/results/<작업 UUID>/analysis-checkpoint.json`
- 최종 결과 CSV: `data/results/<작업 UUID>/final.csv`
- 최종 상세 Excel: `data/results/<작업 UUID>/final.xlsx`
- 실행 로그: `data/logs/<작업 UUID>.log` (상태 API는 전체 누적 로그 반환)

서버 재시작 시 진행 중 작업은 실패 상태로 표시합니다. 같은 작업을 열고 이어서 실행 버튼을 누르면
이미 확정된 경우 보고서 생성/검증을 수행하고, 미확정이면 기존 열린 배치를 이어서 분석합니다.
`POST /api/read-jobs/<작업 UUID>/resume`도 동일하게 동작합니다.
자동 재실행은 하지 않으며 DB 및 업로드 폴더를 함께 보존해야 합니다.
화면의 실행 피드는 표시량을 제한할 수 있지만 API의 로그는 전체 보존됩니다.

## RAG 설정

`.env.example`을 `.env`로 복사해 서버 주소·데이터셋·인증을 설정합니다.
RAG 호출은 `POST {dataset_ids: [...], question: ...}`입니다.
`top_k`는 수신 결과 수 제한이며 서버 검색 파라미터로 전송하지 않습니다.

## 테스트

```bat
py -3 -m unittest discover -v
```

정렬·동일 시각·시각 미해석 경계·인덱스 범위 검색·master 필드 통합·중복 열 보존·생성 실패·재준비 보존·
실제 HTTP/stdio·모의 Kilo 실행과 명시적 종료·RAG 강제 및 배치 누락 차단을 검사합니다.
사내 RAG 및 실제 모델 접근은 별도 실행 환경에서 확인해야 합니다.

로컬 실행용 프로젝트입니다. 작업 토큰 제거를 외부 공개 서비스용 사용자 인증으로 대체한 것은 아닙니다.

라벨링 전 RAG 조회가 필수입니다. `label_event prepare → 원문 확인 → submit` 후 기존 의미·경계 검증을 수행합니다. 상세 호출 계약·이전 데이터 처리 정책은 [EVENT_WORKFLOW.md](EVENT_WORKFLOW.md)를 참조하세요.
