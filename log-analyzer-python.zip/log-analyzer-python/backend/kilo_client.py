import json
import os
import re
import subprocess
import threading
from lib.config import load_config
from lib.paths import APP_ROOT
MASKED='***'
SECRET_KEY_RE=re.compile(r'(token|secret|password|passwd|authorization|credential|api[_-]?key)',re.I)
def build_prompt(job):
    context=job.get('context',{})
    return '\n'.join(['시작: 시험 로그 분석 작업을 수행하세요.',f"업로드 ID: {job['id']}",f"액세스 토큰: {job['token']}",f"근거 소스: {'사내 RAG 서버 (ON)' if job.get('knowledgeSource','rag')=='rag' else '지정 로컬 TXT (OFF)'}. search_rag는 선택된 소스만 검색합니다. 다른 소스로 전환하지 마세요.",f"파일명: {job['filename']} (ZIP. 서버에 저장되어 있으니 파일 탐색·생성이 필요 없습니다.)",f"컨텍스트: 프로젝트={context.get('project','')} / 시험={context.get('test','')} / 프로토콜={context.get('protocol','')}",'위 업로드 ID와 액세스 토큰으로 에이전트 워크플로우를 순서대로 완수하세요.'])
def redact(value):
    if isinstance(value,dict): return {k:MASKED if SECRET_KEY_RE.search(k) else redact(v) for k,v in value.items()}
    if isinstance(value,list): return [redact(v) for v in value]
    return value

def brief_input(value):
    if value is None: return ''
    if isinstance(value,str):
        try: value=json.loads(value)
        except ValueError: return '[문자열 입력 생략]'
    if not isinstance(value,dict): return str(value)[:80]
    value=redact(value); parts=[]
    for k,v in list(value.items())[:3]:
        text=json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else str(v)
        parts.append(f'{k}={text[:60]}')
    return ' '.join(parts)
def summarize_event(event):
    kind=event.get('type',event.get('kind','event')); error=event.get('error')
    if error:
        if isinstance(error,dict): return 'error: '+str(error.get('name','Error'))+' '+str(error.get('message') or (error.get('data') or {}).get('message') or error)[:300]
        return 'error: '+str(error)[:300]
    part=event.get('part') or {}
    if kind=='tool_use':
        state=part.get('state') or {}; name=part.get('tool','tool')
        if state.get('status')=='error': return f"tool {name} 오류: {str(state.get('error',''))[:200]}"
        return f"tool {name} ({brief_input(state.get('input'))})"
    if kind=='text': return 'text: '+re.sub(r'\s+',' ',str(part.get('text','')))[:300]
    return kind+(': '+str(event.get('text') or event.get('message'))[:300] if event.get('text') or event.get('message') else '')
class KiloRun:
    def __init__(self,job,on_log=lambda line:None):
        cfg={**load_config()}
        if job.get('selectedModel'): cfg['model']=job['selectedModel']
        if job.get('kiloExecutable'): cfg['kiloExecutable']=job['kiloExecutable']
        self.job=job; self.error=None; self.ok=False; self.child=None; self.stopped=False
        self._log=lambda line:on_log(str(line).replace(job['token'],MASKED) if job.get('token') else str(line))
        self.cfg=cfg
    def stop(self):
        self.stopped=True
        if self.child and self.child.poll() is None:
            if os.name=='nt': subprocess.run(['taskkill','/PID',str(self.child.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=False)
            else:
                import signal
                try: os.killpg(self.child.pid,signal.SIGKILL)
                except ProcessLookupError: pass
    def run(self):
        cfg=self.cfg; args=[cfg['kiloExecutable'],'run',build_prompt(self.job),'--format','json','--auto','--dir',str(APP_ROOT),'--agent',cfg['agent'],'-m',cfg['model'],'--title','log-'+self.job['id'][:8]]
        try:
            options=dict(cwd=APP_ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',bufsize=1,env={**os.environ,'PYTHONUTF8':'1','LOG_ANALYZER_KNOWLEDGE_SOURCE':self.job.get('knowledgeSource','rag'),'LOG_ANALYZER_KNOWLEDGE_PATH':self.job.get('knowledgePath') or ''})
            if os.name=='nt': options['creationflags']=subprocess.CREATE_NO_WINDOW|subprocess.CREATE_NEW_PROCESS_GROUP
            else: options['start_new_session']=True
            self.child=subprocess.Popen(args,**options)
            if self.stopped: self.stop()
        except OSError as err:
            self.error=f'kilo 프로세스를 시작하지 못했습니다: {err}'; self._log(self.error); return dict(ok=False,error=self.error)
        tail=[]; model_errors=[]
        def pump(stream,is_error=False):
            for line in stream:
                line=line.strip()
                if self.job.get('token'): line=line.replace(self.job['token'],MASKED)
                if not line: continue
                if is_error:
                    tail.append(line); del tail[:-20]; self._log('stderr: '+line[:500])
                else:
                    try:
                        event=json.loads(line); summary=summarize_event(event)
                        if event.get('error') or event.get('type')=='error': model_errors.append(summary)
                        self._log(summary)
                    except (ValueError,TypeError,AttributeError): self._log(line[:500])
            stream.close()
        readers=[threading.Thread(target=pump,args=(self.child.stdout,),daemon=True),threading.Thread(target=pump,args=(self.child.stderr,True),daemon=True)]
        for reader in readers: reader.start()
        try: code=self.child.wait(timeout=cfg['kiloTimeoutMs']/1000)
        except subprocess.TimeoutExpired:
            self._log(f"timeout after {cfg['kiloTimeoutMs']}ms, killing"); self.stop(); self.child.wait(); code=None; self.error=f"kilo 실행 시간이 {round(cfg['kiloTimeoutMs']/60000)}분을 초과했습니다."
        for reader in readers: reader.join(timeout=3)
        if self.error is None:
            if self.stopped: self.error='서버 종료로 분석이 중단되었습니다.'
            elif model_errors: self.error=model_errors[-1]
            elif code!=0: self.error=f'kilo 프로세스 종료 (code {code}). '+ '\n'.join(tail)[-1000:]
        self.ok=self.error is None
        if self.error and self.job.get('token'): self.error=self.error.replace(self.job['token'],MASKED)
        return dict(ok=self.ok,error=self.error)
def run_kilo_job(job,on_log=lambda line:None): return KiloRun(job,on_log)
