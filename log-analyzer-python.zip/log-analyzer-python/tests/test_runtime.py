import http.client
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
from backend.index import Handler
from backend.kilo_client import KiloRun,build_prompt,brief_input
from lib import db
from lib.jobs import create_job,new_job_id,new_token,get_job_view

class RuntimeTests(unittest.TestCase):
    def test_real_stdio_mcp_process(self):
        requests=[dict(jsonrpc='2.0',id=1,method='initialize',params={'protocolVersion':'2025-06-18'}),dict(jsonrpc='2.0',method='notifications/initialized'),dict(jsonrpc='2.0',id=2,method='tools/list')]
        run=subprocess.run([sys.executable,'-m','mcp_server.index'],input='\n'.join(map(json.dumps,requests))+'\n',text=True,encoding='utf-8',capture_output=True,timeout=10)
        self.assertEqual(run.returncode,0,run.stderr); results=[json.loads(x) for x in run.stdout.splitlines()]; self.assertEqual(len(results),2); self.assertEqual(len(results[1]['result']['tools']),11)
    def test_prompt_context_and_recursive_redaction(self):
        prompt=build_prompt(dict(id='id',token='secret',filename='a.zip',context={'project':'P','test':'T','protocol':'MDIL'})); self.assertIn('프로젝트=P',prompt); self.assertIn('프로토콜=MDIL',prompt)
        self.assertNotIn('sensitive',brief_input({'x':{'accessToken':'sensitive'}}))
    def test_cli_stdout_final_line_and_error(self):
        # Real subprocess, fake external Kilo command; no model/network required.
        with tempfile.TemporaryDirectory() as temp:
            script=Path(temp)/'fake.py'; script.write_text("import json,sys\nprint(json.dumps({'type':'error','error':{'name':'APIError','message':'Response ended unexpectedly secret'}}),end='')\n",encoding='utf-8')
            original=subprocess.Popen
            def fake(args,**kwargs): return original([sys.executable,str(script)],**kwargs)
            logs=[]
            with patch('backend.kilo_client.subprocess.Popen',side_effect=fake):
                outcome=KiloRun(dict(id='id',token='secret',filename='x',context={}),logs.append).run()
            self.assertFalse(outcome['ok']); self.assertIn('Response ended unexpectedly',outcome['error']); self.assertNotIn('secret',outcome['error']); self.assertNotIn('secret','\n'.join(logs))
    def test_cli_timeout(self):
        with tempfile.TemporaryDirectory() as temp:
            script=Path(temp)/'fake.py'; script.write_text('import time\ntime.sleep(20)\n')
            original=subprocess.Popen
            def fake(args,**kwargs): return original([sys.executable,str(script)],**kwargs)
            run=KiloRun(dict(id='id',token='t',filename='x',context={}))
            run.cfg={**run.cfg,'kiloTimeoutMs':50}
            with patch('backend.kilo_client.subprocess.Popen',side_effect=fake): outcome=run.run()
            self.assertFalse(outcome['ok']); self.assertIsNotNone(run.child.poll())
    def test_http_upload_and_json_routes(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); upload=root/'uploads'; upload.mkdir()
            with patch.object(db,'DB_PATH',root/'app.db'),patch('backend.index.UPLOADS_DIR',upload),patch('backend.index.job_runtime',return_value={'model':'test/model','kiloExecutable':'kilo'}),patch('backend.index.start_analysis') as start:
                db.close_db(); server=ThreadingHTTPServer(('127.0.0.1',0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
                conn=http.client.HTTPConnection('127.0.0.1',server.server_port,timeout=5)
                try:
                    conn.request('GET','/api/unknown'); r=conn.getresponse(); self.assertEqual(r.status,404); self.assertIn('application/json',r.getheader('Content-Type')); r.read()
                    conn.request('GET','/'); r=conn.getresponse(); self.assertEqual(r.status,200); self.assertIn(b'directStartBtn',r.read())
                    conn.request('POST','/api/read-jobs?filename=a.zip&project=P&test=T&protocol=MDIL',body=b'zip bytes',headers={'Content-Type':'application/zip'}); r=conn.getresponse(); self.assertEqual(r.status,200); accepted=json.loads(r.read()); start.assert_called_once_with(accepted['id'])
                    conn.request('GET','/api/read-jobs/'+accepted['id']); r=conn.getresponse(); view=json.loads(r.read()); self.assertEqual(view['context']['protocol'],'MDIL'); self.assertEqual(view['selectedModel'],'test/model');self.assertNotIn('token',view)
                    conn.request('GET','/api/read-jobs'); r=conn.getresponse(); self.assertEqual(len(json.loads(r.read())),1)
                    conn.request('GET','/api/read-jobs/'+accepted['id']+'/events'); r=conn.getresponse(); self.assertEqual(json.loads(r.read()),{'events':[]})
                    conn.request('GET','/api/read-jobs/'+accepted['id']+'/csv'); r=conn.getresponse(); self.assertEqual(r.status,404); r.read()
                    conn.request('POST','/api/read-jobs',body=b''); r=conn.getresponse(); self.assertEqual(r.status,400); r.read()
                    conn.request('POST','/api/read-jobs',body=b'123',headers={'Origin':'http://other.example'}); r=conn.getresponse(); self.assertEqual(r.status,403); r.read()
                    local=root/'reference.txt';local.write_text('K.0 TN Originator identifies the unit.',encoding='utf-8')
                    with patch('backend.index.local_knowledge_path',return_value=local):
                        conn.request('POST','/api/read-jobs?knowledgeSource=local_text',body=b'zip bytes');r=conn.getresponse();self.assertEqual(r.status,200);offline=json.loads(r.read())
                        conn.request('GET','/api/read-jobs/'+offline['id']);r=conn.getresponse();view=json.loads(r.read());self.assertEqual(view['knowledgeSource'],'local_text');self.assertEqual(view['knowledgePath'],str(local))
                    with patch('backend.index.local_knowledge_path',return_value=root/'missing.txt'):
                        conn.request('POST','/api/read-jobs?knowledgeSource=local_text',body=b'zip bytes');r=conn.getresponse();self.assertEqual(r.status,400);self.assertIn('TXT',json.loads(r.read())['error'])
                    conn.request('POST','/api/read-jobs?knowledgeSource=invalid',body=b'zip bytes');r=conn.getresponse();self.assertEqual(r.status,400);r.read()
                    conn.request('GET','/%2e%2e/lib/config.py'); r=conn.getresponse(); self.assertEqual(r.status,404); r.read()
                finally:
                    conn.close(); server.shutdown(); server.server_close(); thread.join(); db.close_db()

if __name__=='__main__': unittest.main()
