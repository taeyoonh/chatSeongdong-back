import csv
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from unittest.mock import patch
from lib import paths,db
from lib.jobs import create_job,new_job_id,new_token,get_job_view,set_job_status
from lib.time import parse_time_value,ms_to_display
from mcp_server.dataset import prepare_dataset
from mcp_server.queries import summarize_dataset,query_messages,calculate_metrics
from mcp_server.analysis import save_analysis,finalize_analysis,coverage_counts
from mcp_server.report import build_report,verify_report
from mcp_server.auth import assert_job
from mcp_server.csv_merge import parse_csv_entry
from mcp_server.mcp_core import McpToolError
from mcp_server.index import create_server
from scripts.make_test_zip import fixture_bytes

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); root=Path(self.temp.name)
        self.patches=[patch.object(db,'DB_PATH',root/'app.db'),patch('mcp_server.dataset.UPLOADS_DIR',root/'uploads'),patch('mcp_server.dataset.RESULTS_DIR',root/'results'),patch('mcp_server.report.RESULTS_DIR',root/'results')]
        for p in self.patches: p.start()
        db.close_db(); self.id=new_job_id(); self.token=new_token(); self.args=dict(uploadId=self.id,accessToken=self.token)
        create_job(id=self.id,filename='test.zip',project='P',test='T',protocol='Link-16',token=self.token)
        upload=root/'uploads'/self.id; upload.mkdir(parents=True)
        with ZipFile(upload/'upload.zip','w') as archive: archive.writestr('J3.2I.csv',fixture_bytes())
        self.root=root
    def tearDown(self):
        db.close_db()
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()
    def prepare(self):
        prepare_dataset(self.id); return query_messages(self.args|{'fields':['Track_ID','Altitude']})['rows']
    def event(self,id,ids,status='normal',**kwargs):
        return dict(clientId=id,category='track',action='observed',title=id,status=status,messageLinks={'messageIds':ids})|kwargs
    def finding(self,id,ids,verdict='anomaly',**kwargs):
        return dict(clientId=id,title=id,verdict=verdict,description='RAG 근거 확인 필요',messageLinks={'messageIds':ids})|kwargs
    def test_end_to_end_multiline_csv(self):
        rows=self.prepare(); ids=[r['id'] for r in rows]
        save_analysis(self.args|{'events':[self.event('EV-1',ids)] ,'findings':[self.finding('FN-1',[ids[2]],eventId='EV-1')]})
        self.assertEqual(finalize_analysis(self.args)['coverage'],dict(total=4,anomaly=1,normal=3,undetermined=0,unreviewed=0,reviewed=4))
        result=build_report(self.args|{'agentSummary':'합성 데이터 시험 요약'})
        self.assertEqual(result['rowCount'],4); verified=verify_report(self.args)
        self.assertTrue(verified['verified'],verified['errors']); self.assertEqual(get_job_view(self.id)['status'],'completed')
        with (self.root/'results'/self.id/'final.csv').open(encoding='utf-8-sig',newline='') as stream: exported=list(csv.DictReader(stream))
        self.assertEqual(exported[1]['Note'],'두 줄\r\n메모, "인용"'); self.assertEqual(exported[2]['AnalysisStatus'],'anomaly')
    def test_auth(self):
        with self.assertRaises(McpToolError): assert_job(self.id,'wrong')
        self.assertNotIn('token',get_job_view(self.id,False))
    def test_field_summary_and_file_filter(self):
        self.prepare(); summary=summarize_dataset(self.args|{'file':'J3.2I.csv','field':'Track_ID'})
        self.assertEqual(summary['fieldValues'][0]['value'],'20489'); self.assertEqual(summary['fieldValues'][0]['count'],4)
        with self.assertRaises(McpToolError): summarize_dataset(self.args|{'file':'missing.csv'})
    def test_all_metric_operations(self):
        self.prepare()
        for op,extra in [('first_last',{'groupBy':['Track_ID']}),('intervals',{'field':'Track_ID','thresholdMs':30000}),('field_changes',{'groupBy':['Track_ID'],'fields':['Altitude']}),('routes',{'fields':['From','To']})]:
            with self.subTest(op=op):
                result=calculate_metrics(self.args|dict(operation=op)|extra); self.assertTrue(result['rows'])
                if op=='intervals': self.assertEqual(result['rows'][0]['maxGapMs'],119900)
                if op=='field_changes': self.assertEqual(result['rows'][0]['totalChanges'],1)
        with self.assertRaises(McpToolError): query_messages(self.args|{'field':'Track_ID'})
    def test_event_upsert_keeps_real_id_and_links(self):
        ids=[r['id'] for r in self.prepare()]
        save_analysis(self.args|{'events':[self.event('EV-1',[ids[0]]),self.event('EV-2',[ids[1]])]})
        before=db.get_db().execute("SELECT id FROM events WHERE client_id='EV-1'").fetchone()[0]
        save_analysis(self.args|{'events':[self.event('EV-1',[ids[2]])]})
        after=db.get_db().execute("SELECT id FROM events WHERE client_id='EV-1'").fetchone()[0]
        self.assertEqual(before,after)
        self.assertEqual(query_messages(self.args|{'eventIds':['EV-1']})['rows'][0]['id'],ids[2])
        self.assertEqual(query_messages(self.args|{'eventIds':['EV-2']})['rows'][0]['id'],ids[1])
    def test_finding_upsert_keeps_links(self):
        ids=[r['id'] for r in self.prepare()]
        save_analysis(self.args|{'findings':[self.finding('FN-1',[ids[0]]),self.finding('FN-2',[ids[1]])]})
        save_analysis(self.args|{'findings':[self.finding('FN-1',[ids[2]])]})
        self.assertEqual(query_messages(self.args|{'findingIds':['FN-1']})['rows'][0]['id'],ids[2])
        self.assertEqual(query_messages(self.args|{'findingIds':['FN-2']})['rows'][0]['id'],ids[1])
    def test_overlap_status_precedence_and_disjoint_counts(self):
        ids=[r['id'] for r in self.prepare()]
        save_analysis(self.args|{'events':[self.event('NORMAL',ids[:3]),self.event('PENDING',[ids[1]],status='undetermined')],'findings':[self.finding('A',[ids[2]]),self.finding('U',[ids[2]],verdict='undetermined')]})
        c=coverage_counts(self.id)
        self.assertEqual((c['anomaly'],c['normal'],c['undetermined'],c['unreviewed']),(1,1,1,1)); self.assertEqual(c['reviewed'],3)
    def test_selector_links_and_cross_upload_rejection(self):
        self.prepare()
        ev=self.event('EV',[]); ev['messageLinks']={'selector':{'sourceFile':'J3.2I.csv','field':'Altitude','values':['80']}}
        self.assertEqual(save_analysis(self.args|{'events':[ev]})['linkedMessages']['uniqueMessages'],2)
        other=new_job_id(); create_job(id=other,filename='x',project='p',test='t',protocol='MDIL',token=new_token())
        row=db.get_db().execute('INSERT INTO messages(upload_id,line_no,source_file,data_json) VALUES(?,?,?,?) RETURNING id',(other,2,'x.csv','{}')).fetchone()[0]
        with self.assertRaises(McpToolError): save_analysis(self.args|{'events':[self.event('X',[row])]})
    def test_parent_order_cycle_rollback(self):
        ids=[r['id'] for r in self.prepare()]
        save_analysis(self.args|{'events':[self.event('CHILD',[ids[0]],parentId='PARENT'),self.event('PARENT',[ids[1]])]})
        with self.assertRaises(McpToolError): save_analysis(self.args|{'events':[self.event('PARENT',[ids[2]],parentId='CHILD')]})
        self.assertIsNone(db.get_db().execute("SELECT parent_id FROM events WHERE client_id='PARENT'").fetchone()[0])
    def test_finalize_freezes_and_report_requires_finalize(self):
        ids=[r['id'] for r in self.prepare()]
        with self.assertRaises(McpToolError): build_report(self.args)
        save_analysis(self.args|{'events':[self.event('E',ids)]}); finalize_analysis(self.args)
        with self.assertRaises(McpToolError): save_analysis(self.args|{'events':[self.event('E',ids)]})
    def test_mcp_finalize_and_verify_handlers(self):
        self.prepare(); server=create_server()
        def call(name,args): return server.call_tool({'name':name,'arguments':args})
        result=call('finalize_analysis',self.args); self.assertNotIn('isError',result)
        call('build_report',self.args); result=call('verify_report',self.args)
        self.assertNotIn('isError',result); self.assertFalse(json.loads(result['content'][0]['text'])['verified'])
        self.assertTrue(call('query_messages',{'uploadId':self.id})['isError'])
        self.assertIsNone(server.dispatch(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized'})))
        self.assertEqual(len(server.dispatch(json.dumps({'jsonrpc':'2.0','id':1,'method':'tools/list'}))['result']['tools']),11)
    def test_csv_tamper_detected(self):
        ids=[r['id'] for r in self.prepare()]; save_analysis(self.args|{'events':[self.event('E',ids)]}); finalize_analysis(self.args); build_report(self.args)
        output=self.root/'results'/self.id/'final.csv'; output.write_text(output.read_text(encoding='utf-8-sig').replace('20489','99999'),encoding='utf-8-sig')
        result=verify_report(self.args); self.assertFalse(result['verified']); self.assertTrue(any('CSV 내용' in e for e in result['errors']))
    def test_timestamp_validation_rollover_and_date(self):
        self.assertIsNone(parse_time_value('2026-02-30 12:00:00'))
        parsed=parse_csv_entry('2026-10-15_test.csv',b'Time,Value\n23:59:59,1\n00:00:01,2\n')
        self.assertEqual(parsed['lastMs']-parsed['firstMs'],2000)
        parsed=parse_csv_entry('x.csv',b'Date,Time,V\n2026-10-15,12:00:00,1\n')
        self.assertFalse(parsed['timeOnly']); self.assertTrue(ms_to_display(parsed['firstMs']).startswith('2026-10-15'))
    def test_encoding_duplicate_headers_and_double_ms(self):
        parsed=parse_csv_entry('x.csv','Time,내용\n12:00:00,한글\n'.encode('cp949')); self.assertEqual(parsed['rows'][0]['data']['내용'],'한글')
        parsed=parse_csv_entry('x.csv',b'Time,X,X\n12:00:00,a,b\n');self.assertEqual(parsed['rows'][0]['data']['X'],'a');self.assertEqual(parsed['rows'][0]['data']['X__2'],'b')
        parsed=parse_csv_entry('x.csv',b'Time1,Time2\n2026-10-15 12:00:00.500,500\n')
        self.assertEqual(parsed['firstMs']%1000,500)
    def test_zip_path_rejected(self):
        with ZipFile(self.root/'uploads'/self.id/'upload.zip','w') as z: z.writestr('../x.csv',b'Time,X\n12:00:00,1\n')
        with self.assertRaises(McpToolError): prepare_dataset(self.id)
    def test_single_timestamp_report_valid(self):
        with ZipFile(self.root/'uploads'/self.id/'upload.zip','w') as z: z.writestr('x.csv',b'Time,X\n2026-10-15 12:00:00,1\n')
        prepare_dataset(self.id); ids=[r['id'] for r in query_messages(self.args)['rows']]; save_analysis(self.args|{'events':[self.event('E',ids)]}); finalize_analysis(self.args); build_report(self.args)
        self.assertTrue(verify_report(self.args)['verified'])
    def test_reprepare_removes_old_csv_and_links(self):
        ids=[r['id'] for r in self.prepare()]; save_analysis(self.args|{'events':[self.event('E',ids)]}); finalize_analysis(self.args); build_report(self.args)
        prepare_dataset(self.id); self.assertFalse((self.root/'results'/self.id/'final.csv').exists()); self.assertEqual(coverage_counts(self.id)['reviewed'],0)

    def test_j_headers_trailing_comma_and_duplicate_collision(self):
        parsed=parse_csv_entry('J13.5C1.csv',b'Time1,Time2,Sender,Receiver,X,X,X__2,\n2026-10-15 12:00:00,1,S,R,a,b,c,\n')
        self.assertEqual(parsed['headers'],['Time1','Time2','Sender','Receiver','X','X__3','X__2','Unnamed_8'])
        self.assertEqual([parsed['rows'][0]['data'][h] for h in parsed['headers']][4:],['a','b','c',''])
        self.assertTrue(parsed['warnings'])
    def test_extra_cells_preserved_and_short_rows_filled(self):
        parsed=parse_csv_entry('J3.2I.csv',b'Time,X\n12:00:00,a\n12:00:01,b,extra\n12:00:02\n')
        self.assertEqual(parsed['headers'],['Time','X','ExtraColumn_3'])
        self.assertEqual(parsed['rows'][0]['data']['ExtraColumn_3'],'');self.assertEqual(parsed['rows'][1]['data']['ExtraColumn_3'],'extra');self.assertEqual(parsed['rows'][2]['data']['X'],'')
    def test_utf16_and_excel_separator(self):
        parsed=parse_csv_entry('J13.5C1.csv','sep=;\nTime1;Time2;WORD FORMAT;\n2026-10-15 12:00:00;1;1;\n'.encode('utf-16'))
        self.assertEqual(parsed['count'],1);self.assertEqual(parsed['rows'][0]['lineNo'],3);self.assertEqual(parsed['rows'][0]['data']['WORD FORMAT'],'1')
    def test_j_normalization_full_pipeline_and_failure_status(self):
        with ZipFile(self.root/'uploads'/self.id/'upload.zip','w') as z:
            z.writestr('J13.5C1.csv',b'Time1,Time2,SPARE,SPARE,\n2026-10-15 12:00:02,1,a,b,\n')
            z.writestr('J3.2I.csv',b'Time1,Time2,TN\n2026-10-15 12:00:01,1,123\n')
        prepared=prepare_dataset(self.id);self.assertEqual(prepared['rowCount'],2);self.assertTrue(get_job_view(self.id)['datasetWarnings'])
        rows=query_messages(self.args)['rows'];self.assertEqual(rows[0]['source'],'J3.2I.csv');ids=[r['id'] for r in rows]
        save_analysis(self.args|{'events':[self.event('E',ids)]});finalize_analysis(self.args);build_report(self.args);self.assertTrue(verify_report(self.args)['verified'])
        with (self.root/'results'/self.id/'final.csv').open(encoding='utf-8-sig',newline='') as stream:
            exported=list(csv.DictReader(stream));self.assertEqual(exported[1]['SPARE'],'a');self.assertEqual(exported[1]['SPARE__2'],'b')
        with ZipFile(self.root/'uploads'/self.id/'upload.zip','w') as z:z.writestr('J13.5C1.csv',b'Time,X\n"unclosed,1\n')
        with self.assertRaises(McpToolError):prepare_dataset(self.id)
        self.assertEqual(get_job_view(self.id)['status'],'failed');self.assertEqual(coverage_counts(self.id)['total'],0)

if __name__=='__main__': unittest.main()
