import sqlite3
import threading
from contextlib import contextmanager
from .paths import DB_PATH, ensure_dirs
_local = threading.local()
def get_db():
    if getattr(_local, 'db', None) is None:
        ensure_dirs()
        db = sqlite3.connect(DB_PATH, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA busy_timeout=10000')
        db.execute('PRAGMA foreign_keys=ON')
        migrate(db)
        _local.db = db
    return _local.db

def migrate(db):
    db.executescript('''
CREATE TABLE IF NOT EXISTS jobs(
 id TEXT PRIMARY KEY, filename TEXT, project TEXT, test TEXT, protocol TEXT,
 status TEXT NOT NULL DEFAULT 'queued', error TEXT, token TEXT, policy TEXT,
 created_at INTEGER, updated_at INTEGER, result_json TEXT, report_json TEXT,
 verification_json TEXT, finalized_at INTEGER);
CREATE TABLE IF NOT EXISTS file_meta(
 upload_id TEXT NOT NULL, name TEXT NOT NULL, row_count INTEGER NOT NULL DEFAULT 0,
 first_ms INTEGER, last_ms INTEGER, first_time TEXT, last_time TEXT,
 header_order TEXT NOT NULL DEFAULT '[]', PRIMARY KEY(upload_id,name));
''')
    cols = {r['name'] for r in db.execute('PRAGMA table_info(jobs)')}
    if 'finalized_at' not in cols:
        db.execute('ALTER TABLE jobs ADD COLUMN finalized_at INTEGER')
    if 'knowledge_source' not in cols:
        db.execute("ALTER TABLE jobs ADD COLUMN knowledge_source TEXT NOT NULL DEFAULT 'rag'")
    if 'knowledge_path' not in cols:
        db.execute("ALTER TABLE jobs ADD COLUMN knowledge_path TEXT")
    for column in ('selected_model','kilo_executable'):
        if column not in cols: db.execute(f'ALTER TABLE jobs ADD COLUMN {column} TEXT')
    if 'dataset_warnings_json' not in cols:db.execute('ALTER TABLE jobs ADD COLUMN dataset_warnings_json TEXT')
    exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='messages'").fetchone()
    legacy = exists and 'id' not in {r['name'] for r in db.execute('PRAGMA table_info(messages)')}
    if legacy:
        # Legacy v1 has no event/finding links. Roll back the complete rebuild on failure.
        db.execute('BEGIN IMMEDIATE')
        db.execute('ALTER TABLE messages RENAME TO messages_v1')
    try:
        db.execute('''CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY, upload_id TEXT NOT NULL, line_no INTEGER NOT NULL,
 ts_ms INTEGER, source_file TEXT NOT NULL, data_json TEXT NOT NULL)''')
        if legacy:
            db.execute('INSERT INTO messages SELECT rowid,upload_id,line_no,ts_ms,source_file,data_json FROM messages_v1')
            db.execute('DROP TABLE messages_v1')
            db.execute('COMMIT')
    except Exception:
        if legacy: db.execute('ROLLBACK')
        raise
    db.executescript('''
CREATE INDEX IF NOT EXISTS idx_messages_order ON messages(upload_id,ts_ms IS NULL,ts_ms,source_file,line_no);
CREATE INDEX IF NOT EXISTS idx_messages_file ON messages(upload_id,source_file,line_no);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY, upload_id TEXT NOT NULL, client_id TEXT NOT NULL,
 parent_id INTEGER REFERENCES events(id) ON DELETE CASCADE,
 category TEXT NOT NULL, action TEXT NOT NULL, title TEXT NOT NULL,
 subject_json TEXT NOT NULL DEFAULT 'null', start_ms INTEGER, end_ms INTEGER,
 description TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'undetermined',
 severity TEXT, created_at INTEGER NOT NULL, UNIQUE(upload_id,client_id));
CREATE INDEX IF NOT EXISTS idx_events_upload ON events(upload_id,start_ms IS NULL,start_ms);
CREATE TABLE IF NOT EXISTS event_messages(
 event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
 message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 PRIMARY KEY(event_id,message_id));
CREATE INDEX IF NOT EXISTS idx_event_messages_msg ON event_messages(message_id);
CREATE TABLE IF NOT EXISTS findings(
 id INTEGER PRIMARY KEY, upload_id TEXT NOT NULL, client_id TEXT NOT NULL,
 event_id INTEGER REFERENCES events(id) ON DELETE SET NULL,
 kind TEXT NOT NULL DEFAULT 'anomaly', title TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '', verdict TEXT NOT NULL DEFAULT 'anomaly',
 severity TEXT, start_ms INTEGER, end_ms INTEGER,
 reference_json TEXT NOT NULL DEFAULT '[]', created_at INTEGER NOT NULL,
 UNIQUE(upload_id,client_id));
CREATE INDEX IF NOT EXISTS idx_findings_upload ON findings(upload_id,start_ms IS NULL,start_ms);
CREATE TABLE IF NOT EXISTS finding_messages(
 finding_id INTEGER NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
 message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
 PRIMARY KEY(finding_id,message_id));
CREATE INDEX IF NOT EXISTS idx_finding_messages_msg ON finding_messages(message_id);
''')
@contextmanager
def transaction(db=None):
    db = db or get_db()
    db.execute('BEGIN IMMEDIATE')
    try:
        yield db
        db.execute('COMMIT')
    except BaseException:
        db.execute('ROLLBACK')
        raise
def close_db():
    db = getattr(_local, 'db', None)
    if db is not None:
        db.close()
        _local.db = None
