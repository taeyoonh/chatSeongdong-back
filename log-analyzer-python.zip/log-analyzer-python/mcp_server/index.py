"""Run from project root: python -m mcp_server.index"""
import sys
from lib.db import close_db
from lib.jobs import get_job_view
from .mcp_core import StdioMcpServer, McpToolError
from .rag_client import RagError
from .knowledge import search_knowledge, check_knowledge
from .auth import assert_job
from .dataset import prepare_dataset
from .queries import summarize_dataset,query_messages,calculate_metrics
from .analysis import save_analysis,finalize_analysis
from .report import build_report,verify_report
S={'type':'string'}; N={'type':'number'}
TIME_ARG={'oneOf':[N,dict(type='string',description='epoch ms 또는 YYYY-MM-DD HH:MM:SS / HH:MM:SS')]}
def arr(items,**extra): return dict(type='array',items=items,**extra)
def obj(props,required=()): return dict(type='object',properties=props,required=list(required),additionalProperties=False)
def enum(*values): return dict(type='string',enum=list(values))
SELECTOR=obj(dict(sourceFile=S,fromMs=TIME_ARG,toMs=TIME_ARG,field=S,values=arr(S)))
LINK_SPEC=obj(dict(messageIds=arr({'type':'integer'},maxItems=5000),selector=SELECTOR))
EVENT=obj(dict(clientId=S,parentId=S,category=enum('track','platform','control','engagement','communication','other'),action=enum('observed','updated','correlated','changed','dropped'),title=S,subject={},startMs=TIME_ARG,endMs=TIME_ARG,description=S,status=enum('normal','anomaly','undetermined'),severity=enum('normal','warn','danger'),messageLinks=LINK_SPEC),('clientId','category','action','title','messageLinks'))
FINDING=obj(dict(clientId=S,eventId={'oneOf':[S,{'type':'null'}]},kind=enum('anomaly','review'),title=S,description=S,verdict=enum('anomaly','undetermined'),severity=enum('normal','warn','danger'),startMs=TIME_ARG,endMs=TIME_ARG,references=arr({'oneOf':[S,obj(dict(document=S,section=S),('document',))]}),messageLinks=LINK_SPEC),('clientId','title','messageLinks'))
def job_schema(extra=None,required=()): return obj(dict(uploadId=S,accessToken=S)|dict(extra or {}),('uploadId','accessToken',*required))
def dataset(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken')); return prepare_dataset(job['id'])
def status(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken')); view=get_job_view(job['id'],False)
    return dict(ok=True,status=view['status'],error=view['error'],files=view['files'])
def search_rag(args):
    try:
        return search_knowledge(args)
    except RagError as err:
        raise McpToolError(str(err)) from err

def rag_connection_check(args):
    try:
        return check_knowledge()
    except RagError as err:
        raise McpToolError(str(err)) from err

def create_server():
    server=StdioMcpServer('log-analyzer','0.3.0')
    definitions=[
      ('search_rag','작업별 근거 검색. 토글 ON은 사내 RAG, OFF는 서버에 지정된 TXT를 검색하며 모델이 소스를 바꿀 수 없습니다. 응답 knowledge_source를 확인하세요. 라벨링 및 이벤트 유효성 검토 도중 모르는 메시지 의미/필드/운용 절차/주기/판정 기준이 생길 때마다 호출하세요. 검색→실제 로그 대조→필요시 재검색을 반복하세요. 이미 확인한 동일 근거는 재사용할 수 있습니다. J/K 모두 검색 가능하며 ON의 검색 범위는 RAG_DATASET_IDS, OFF는 지정 TXT 파일입니다. 문서명·절·본문·점수를 반환. message_id/dfi/dui/rule_type은 질문 문자열 조건이며 강제 서버 필터가 아닙니다. top_k는 최대 20개의 반환 결과 수 상한입니다.',obj(dict(query=S,message_id=S,dfi=S,dui=S,rule_type=S,top_k={'type':'integer'}),('query',)),search_rag),
      ('rag_connection_check','선택된 근거 소스 확인. ON은 RAG health, OFF는 로컬 TXT 읽기 가능 여부를 검사합니다. ON health 성공이 검색 API 성공을 보장하지 않습니다.',obj({}),rag_connection_check),
      ('prepare_dataset','업로드 ZIP의 모든 CSV를 파싱·통합합니다. 최초 한 번만 호출하세요. 재호출하면 분석이 초기화됩니다.',job_schema(),dataset),
      ('summarize_dataset','총 행 수/시간 범위/히스토그램/파일 컬럼 및 field 값 분포. 실제 필드명을 확인하세요.',job_schema(dict(bucketSec=N,file=S,fromMs=TIME_ARG,toMs=TIME_ARG,field=S)),summarize_dataset),
      ('query_messages','sourceFile/시간/field+values/eventIds/findingIds로 필터링. fields로 원본 컬럼 지정. 반환 id는 메시지 연결에 사용. offset을 증가시켜 모든 페이지를 조회하세요.',job_schema(dict(sourceFile=S,fromMs=TIME_ARG,toMs=TIME_ARG,field=S,values=arr(S),fields=arr(S),eventIds=arr({'oneOf':[N,S]}),findingIds=arr({'oneOf':[N,S]}),limit=N,offset=N)),query_messages),
      ('calculate_metrics','객관적 지표만 계산합니다. first_last/intervals/field_changes/routes. groupBy는 첫 필드 사용. intervals는 field도 지원. truncated=true면 시간 범위를 나누세요.',job_schema(dict(operation=enum('first_last','intervals','field_changes','routes'),groupBy=arr(S),field=S,fields=arr(S),sourceFile=S,fromMs=TIME_ARG,toMs=TIME_ARG,thresholdMs=N,limit=N),('operation',)),calculate_metrics),
      ('save_analysis','AI 이벤트/판정을 배치 upsert. clientId 재사용 시 대체. messageLinks에는 messageIds 또는 selector 중 하나. 정상은 이벤트 status=normal, 이상/보류는 findings로 대상 메시지 연결. 모든 구간을 분석하세요.',job_schema(dict(events=arr(EVENT),findings=arr(FINDING))),save_analysis),
      ('finalize_analysis','모든 save_analysis 이후 한 번 확정. 커버리지 반환. 확정 이후 변경 불가.',job_schema(),finalize_analysis),
      ('build_report','확정된 분석으로 원본+8개 분석 컬럼의 CSV/타임라인 생성. agentSummary는 선택된 소스의 근거와 미분석 범위를 포함한 한국어 시험 요약.',job_schema(dict(agentSummary=S)),build_report),
      ('verify_report','DB·CSV·참조·이벤트시간·커버리지·보고서 교차 검증. completed/verification_failed 확정. 구조 검증이며 AI 판정 정확성 보증은 아닙니다.',job_schema(),verify_report),
      ('get_job_status','작업 상태/오류/파일 통계 조회.',job_schema(),status)]
    for definition in definitions: server.register_tool(*definition)
    return server
if __name__=='__main__':
    if hasattr(sys.stdin,'reconfigure'): sys.stdin.reconfigure(encoding='utf-8')
    if hasattr(sys.stdout,'reconfigure'): sys.stdout.reconfigure(encoding='utf-8',errors='strict')
    try: create_server().start()
    finally: close_db()
