import csv
import json
import os
from lib.paths import RESULTS_DIR,ensure_dirs
from lib.db import get_db
from lib.jobs import get_job_view,set_job_status,set_job_result
from lib.time import ms_to_display,ms_to_clock
from lib.evidence import make_evidence
from .csv_merge import file_stats,total_row_count,safe_parse
from .analysis import per_message_detail,coverage_counts,refs_text
from .auth import assert_job
from .mcp_core import McpToolError
from .queries import ORDER_CLAUSE,time_range_ms
POLICY='v2'
REPORT_COLUMNS=['SourceFile','EventID','EventType','EventDescription','AnalysisStatus','IsAnomaly','AnomalyReason','Reference']
STATUS_LABEL=dict(normal='정상',anomaly='이상',undetermined='판정 보류',unreviewed='미분석')
def original_headers(stats): return list(dict.fromkeys(h for s in stats for h in safe_parse(s['headerOrder'],[])))
def analysis_cells(row,detail):
    st=detail['byMessage'].get(row['id'],{}); status=st.get('status','unreviewed'); events=st.get('events',[])
    return [row['source_file'],'; '.join(e['clientId'] for e in events),'; '.join(e['type'] for e in events),' | '.join(e['title'] for e in events),status,'1' if status=='anomaly' else '0' if status=='normal' else '',st.get('reason',''),st.get('reference','')]
def export_final_csv(upload_id,out_dir,detail):
    headers=original_headers(file_stats(upload_id))
    if set(headers)&set(REPORT_COLUMNS): raise McpToolError('원본 CSV 헤더가 분석 컬럼 이름과 충돌합니다: '+', '.join(set(headers)&set(REPORT_COLUMNS)))
    ensure_dirs(); out_dir.mkdir(parents=True,exist_ok=True); output=out_dir/'final.csv'; temporary=out_dir/'final.csv.part'; count=0
    try:
        with temporary.open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.writer(stream); writer.writerow(headers+REPORT_COLUMNS)
            cursor=get_db().execute('SELECT id,source_file,data_json FROM messages WHERE upload_id=? ORDER BY '+ORDER_CLAUSE,(upload_id,))
            for row in cursor:
                data=safe_parse(row['data_json'],{}); writer.writerow([data.get(h,'') for h in headers]+analysis_cells(row,detail)); count+=1
        os.replace(temporary,output)
    except BaseException:
        temporary.unlink(missing_ok=True); raise
    return dict(outPath=str(output),rows=count,columns=len(headers)+len(REPORT_COLUMNS))
def evidence_for(upload_id,table=None,column=None,row_id=None,limit=12,descending=False):
    db=get_db()
    if table:
        assert (table,column) in (('event_messages','event_id'),('finding_messages','finding_id'))
        sql=f'SELECT m.* FROM messages m JOIN {table} l ON l.message_id=m.id WHERE m.upload_id=? AND l.{column}=? AND m.ts_ms IS NOT NULL ORDER BY m.ts_ms,m.source_file,m.line_no LIMIT ?'; params=(upload_id,row_id,limit)
    else:
        sql='SELECT * FROM messages WHERE upload_id=? AND ts_ms IS NOT NULL ORDER BY ts_ms '+('DESC' if descending else 'ASC')+',source_file,line_no LIMIT ?'; params=(upload_id,limit)
    rows=[dict(r) for r in db.execute(sql,params)]
    if descending: rows.reverse()
    for r in rows: r['data']=safe_parse(r['data_json'],{})
    return make_evidence(rows,limit)
def build_timeline(upload_id,first,last):
    entries=[]; db=get_db(); stats=file_stats(upload_id)
    if first is not None: entries.append(dict(ms=first,time=ms_to_clock(first),severity='normal',title='시험 시작',description=f'{ms_to_display(first)}에 첫 메시지가 수신되었습니다 (파일 {len(stats)}개, 메시지 {total_row_count(upload_id):,}개).',rows=evidence_for(upload_id,limit=2)))
    if first is not None and last is not None and last>first: entries.append(dict(ms=last,time=ms_to_clock(last),severity='normal',title='시험 종료',description=f'{ms_to_display(last)}에 마지막 메시지가 수신되었습니다.',rows=evidence_for(upload_id,limit=2,descending=True)))
    events=[dict(r) for r in db.execute('SELECT * FROM events WHERE upload_id=? ORDER BY start_ms IS NULL,start_ms,id',(upload_id,))]
    findings=[dict(r) for r in db.execute('SELECT * FROM findings WHERE upload_id=? ORDER BY start_ms IS NULL,start_ms,id',(upload_id,))]
    parents={e['id']:e for e in events}
    for e in [e for e in events if e['parent_id'] is None][:60]:
        entries.append(dict(ms=e['start_ms'] if e['start_ms'] is not None else float('inf'),time=ms_to_clock(e['start_ms']) if e['start_ms'] is not None else '시각 미상',endTime=ms_to_clock(e['end_ms']),severity=e['severity'] or ('danger' if e['status']=='anomaly' else 'warn' if e['status']=='undetermined' else 'normal'),title=e['title'],description=f"{e['category']}.{e['action']} · 판정: {STATUS_LABEL[e['status']]} — {e['description']}",eventId=e['client_id'],rows=evidence_for(upload_id,'event_messages','event_id',e['id'])))
    for f in findings[:40]:
        stamp=f['start_ms'] if f['start_ms'] is not None else parents.get(f['event_id'],{}).get('start_ms'); reference=refs_text(safe_parse(f['reference_json'],[]))
        entries.append(dict(ms=stamp if stamp is not None else float('inf'),time=ms_to_clock(stamp) if stamp is not None else '시각 미상',severity=f['severity'] or ('danger' if f['verdict']=='anomaly' else 'warn'),title=('재확인: ' if f['kind']=='review' else '이상징후: ')+f['title'],description=f['description']+(' — 근거: '+reference if reference else ''),findingId=f['client_id'],rows=evidence_for(upload_id,'finding_messages','finding_id',f['id'])))
    entries.sort(key=lambda e:e['ms'])
    for e in entries: e.pop('ms')
    return dict(list=entries,eventCount=len(events),findingCount=len(findings),timelineTruncated=len([e for e in events if e['parent_id'] is None])>60 or len(findings)>40)
def build_report(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken'))
    if job['finalized_at'] is None: raise McpToolError('finalize_analysis를 먼저 호출하세요.')
    stats=file_stats(job['id'])
    if not stats: raise McpToolError('prepare_dataset를 먼저 실행하세요.')
    first,last=time_range_ms(stats); detail=per_message_detail(job['id']); info=export_final_csv(job['id'],RESULTS_DIR/job['id'],detail); timeline=build_timeline(job['id'],first,last); coverage=coverage_counts(job['id'])
    result=dict(firstTime=ms_to_display(first),lastTime=ms_to_display(last),durationMs=max(0,last-first) if first is not None and last is not None else 0,fileCount=len(stats),rowCount=info['rows'],coverage=coverage,eventCount=timeline['eventCount'],findingCount=timeline['findingCount'],events=timeline['list'],timelineTruncated=timeline['timelineTruncated'],agentSummary=args.get('agentSummary','').strip(),knowledgeSource=job['knowledge_source'],policy=POLICY)
    report={'files':[{k:s[k] for k in ('name','rowCount','firstTime','lastTime')} for s in stats]}
    set_job_result(job['id'],result=result,report=report,policy=POLICY); set_job_status(job['id'],'report_ready')
    return dict(ok=True,policy=POLICY,rowCount=info['rows'],fileCount=len(stats),coverage=coverage,timelineEvents=len(result['events']),csv=dict(rows=info['rows'],columns=info['columns']))
def verify_report(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken')); db=get_db()
    if job['status'] not in ('report_ready','verification_failed','completed'): raise McpToolError('save_analysis → finalize_analysis → build_report 순으로 진행하세요.')
    checks=[]; errors=[]; warnings=[]
    def check(name,ok,detail):
        checks.append(dict(name=name,ok=bool(ok),detail=detail))
        if not ok: errors.append(name+': '+detail)
    stats=file_stats(job['id']); total=db.execute('SELECT COUNT(*) FROM messages WHERE upload_id=?',(job['id'],)).fetchone()[0]; meta=sum(s['rowCount'] for s in stats)
    check('메시지 수: file_meta ↔ messages',meta==total,f'file_meta={meta} / messages={total}')
    problems=[]
    for s in stats:
        row=db.execute('SELECT COUNT(*) n,MIN(ts_ms) f,MAX(ts_ms) l FROM messages WHERE upload_id=? AND source_file=?',(job['id'],s['name'])).fetchone()
        if (row['n'],row['f'],row['l'])!=(s['rowCount'],s['firstMs'],s['lastMs']): problems.append(s['name'])
    check('파일별 통계: file_meta ↔ messages',not problems,', '.join(problems) or f'{len(stats)}개 파일 일치')
    output=RESULTS_DIR/job['id']/'final.csv'; detail=per_message_detail(job['id'])
    if not output.exists(): check('최종 CSV 존재',False,'final.csv가 없습니다.')
    else:
        with output.open(encoding='utf-8-sig',newline='') as stream:
            reader=csv.reader(stream); header=next(reader,[]); expected=original_headers(stats)+REPORT_COLUMNS
            check('CSV 헤더: 원본 및 분석 컬럼',header==expected,'전체 헤더 및 순서 비교')
            cursor=iter(db.execute('SELECT id,source_file,data_json FROM messages WHERE upload_id=? ORDER BY '+ORDER_CLAUSE,(job['id'],))); count=0; mismatches=0
            for cells in reader:
                count+=1; source=next(cursor,None)
                if source is None: mismatches+=1; continue
                data=safe_parse(source['data_json'],{}); wanted=[str(data.get(h,'')) for h in original_headers(stats)]+analysis_cells(source,detail)
                if cells!=wanted: mismatches+=1
            check('CSV 행 수: messages ↔ final.csv',count==total,f'final.csv={count} / messages={total}')
            check('CSV 내용: 원본/순서/분석값 일치',mismatches==0,f'불일치 {mismatches}행')
    for table,owner,column in [('event_messages','events','event_id'),('finding_messages','findings','finding_id')]:
        count=db.execute(f'SELECT COUNT(*) FROM {table} l JOIN {owner} o ON o.id=l.{column} LEFT JOIN messages m ON m.id=l.message_id WHERE o.upload_id=? AND (m.id IS NULL OR m.upload_id<>o.upload_id)',(job['id'],)).fetchone()[0]
        check('메시지 참조: '+table,count==0,f'잘못된 참조 {count}건')
    windows=db.execute('SELECT e.client_id,e.start_ms,e.end_ms,MIN(m.ts_ms) f,MAX(m.ts_ms) l,COUNT(m.ts_ms) c FROM events e LEFT JOIN event_messages em ON em.event_id=e.id LEFT JOIN messages m ON m.id=em.message_id WHERE e.upload_id=? GROUP BY e.id',(job['id'],))
    problems=[]
    for e in windows:
        if e['c'] and ((e['start_ms'] is not None and e['start_ms']>e['f']+2000) or (e['end_ms'] is not None and e['end_ms']<e['l']-2000)): problems.append(e['client_id'])
    check('이벤트 시간: 관련 메시지 포함',not problems,', '.join(problems[:5]) or '모든 이벤트 구간 일치')
    cov=coverage_counts(job['id']); check('분석 상태: 판정된 메시지 존재',cov['total']>0 and cov['reviewed']>0,json.dumps(cov,ensure_ascii=False)); check('분석 상태: 합계 일치',sum(cov[k] for k in ('normal','anomaly','undetermined','unreviewed'))==total,'상태별 중복 없이 집계')
    if cov['total'] and cov['unreviewed']/cov['total']>.5: warnings.append(f"미분석 메시지가 {round(cov['unreviewed']/cov['total']*100)}%입니다. 정상으로 간주하지 않습니다.")
    missing=db.execute('SELECT COUNT(*) FROM messages WHERE upload_id=? AND ts_ms IS NULL',(job['id'],)).fetchone()[0]
    if missing: warnings.append(f'시각을 해석하지 못한 메시지가 {missing}개입니다. CSV 끝에 정렬했습니다.')
    view=get_job_view(job['id']); stored=view['result'] or {}; expected_timeline=build_timeline(job['id'],*time_range_ms(stats))
    consistent=stored.get('policy')==POLICY and stored.get('coverage')==cov and stored.get('rowCount')==total and stored.get('events')==expected_timeline['list']
    check('보고서: DB ↔ 결과 데이터',consistent,'타임라인·커버리지·행 수 비교')
    verification=dict(verified=not errors,errors=errors,warnings=warnings,checks=checks)
    set_job_result(job['id'],result=view['result'],report=view['report'],verification=verification,policy=POLICY); set_job_status(job['id'],'verification_failed' if errors else 'completed')
    return dict(ok=True,verified=not errors,errors=errors,warnings=warnings,coverage=cov)
