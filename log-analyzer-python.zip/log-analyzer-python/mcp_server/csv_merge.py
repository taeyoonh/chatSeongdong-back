import csv
import io
import json
import re
from datetime import datetime,timedelta
from lib.db import get_db,transaction
from lib.time import parse_time_value,ms_to_display,TIME_ONLY_RE
from .mcp_core import McpToolError
def norm_name(name): return re.sub(r'\s+',' ',str(name or '').lstrip('\ufeff')).strip()
def date_from_filename(filename):
    m=re.search(r'(\d{4})[_/.-](\d{1,2})[_/.-](\d{1,2})',filename)
    if not m: return None
    try: return datetime(*map(int,m.groups()))
    except ValueError: return None
def detect_time_columns(headers):
    lower=[h.lower() for h in headers]
    idx=lambda key: lower.index(key) if key in lower else -1
    if idx('time1')>=0 or idx('time2')>=0: return dict(mode='time12',time1=idx('time1'),time2=idx('time2'))
    single=next((i for i,h in enumerate(lower) if h in ('time','timestamp','datetime','date_time','dt')),-1)
    return dict(mode='single',single=single,date=idx('date')) if single>=0 else dict(mode='none')
def ts_for_row(row,info,anchor):
    cell=lambda i: str(row[i]).strip() if 0<=i<len(row) else ''
    if info['mode']=='time12':
        base=parse_time_value(cell(info['time1']),anchor)
        if base is None: base=parse_time_value(cell(info['time2']),anchor)
        if base is None: return None
        raw=cell(info['time2'])
        try:
            n=float(raw)
            if raw and 0<=n<=999:
                # Time2 carries millisecond-of-second, do not add it twice.
                return (base//1000)*1000+int(n)
            if n>1e9: return int(n if n>1e12 else n*1000)
        except ValueError: pass
        return base
    if info['mode']=='single':
        raw=cell(info['single'])
        if info['date']>=0 and TIME_ONLY_RE.fullmatch(raw):
            full=cell(info['date'])+' '+raw
            return parse_time_value(full,anchor)
        return parse_time_value(raw,anchor)
    return None

def unique_headers(raw_headers):
    normalized=[norm_name(h) for h in raw_headers]
    reserved={h for h in normalized if h};used=set();headers=[];changes=[]
    for i,base in enumerate(normalized,1):
        name=base or f'Unnamed_{i}'
        if name in used or (not base and name in reserved):
            n=2;stem=name
            while f'{stem}__{n}' in used or f'{stem}__{n}' in reserved:n+=1
            name=f'{stem}__{n}'
        used.add(name);headers.append(name)
        if name!=raw_headers[i-1]:changes.append(dict(column=i,original=raw_headers[i-1],normalized=name))
    return headers,changes

def parse_csv_entry(name,buffer):
    if buffer.startswith((b'\xff\xfe',b'\xfe\xff')):
        try:text=buffer.decode('utf-16')
        except UnicodeDecodeError as err:raise McpToolError(f'{name}: UTF-16 CSV를 읽을 수 없습니다.') from err
    else:
        try:text=buffer.decode('utf-8-sig')
        except UnicodeDecodeError:
            try:text=buffer.decode('cp949')
            except UnicodeDecodeError as err:raise McpToolError(f'{name}: UTF-8/UTF-16/CP949 CSV가 아닙니다.') from err
    if '\x00' in text:raise McpToolError(f'{name}: 텍스트 CSV가 아닌 데이터 또는 BOM 없는 UTF-16 파일입니다. UTF-8로 저장하세요.')
    directive=re.match(r'^sep=([,;\t])\r?\n',text,re.I)
    offset=1 if directive else 0
    reader=csv.reader(io.StringIO(text[directive.end():] if directive else text,newline=''),delimiter=directive.group(1) if directive else ',',strict=True)
    try:
        header=next((r for r in reader if r and any(str(v).strip() for v in r)),None)
        if not header:raise McpToolError(f'{name}: CSV 헤더를 찾을 수 없습니다.')
        headers,changes=unique_headers(header)
        info=detect_time_columns(headers);anchor=date_from_filename(name) or datetime.now()
        rows=[];first=last=None;time_only=False;previous=None;extra_columns=[]
        for values in reader:
            if not values or not any(str(v).strip() for v in values):continue
            # Exporters can append a comma or emit unnamed fields. Keep every
            # value by position; never overwrite a duplicate dictionary key.
            if len(values)>len(headers):
                for position in range(len(headers)+1,len(values)+1):
                    candidate=f'ExtraColumn_{position}';n=2
                    while candidate in headers:
                        candidate=f'ExtraColumn_{position}__{n}';n+=1
                    headers.append(candidate);extra_columns.append(dict(column=position,normalized=candidate))
            primary=values[info.get('time1',-1)] if info['mode']=='time12' and 0<=info.get('time1',-1)<len(values) else values[info['single']] if info['mode']=='single' and info['single']<len(values) else ''
            only=bool(TIME_ONLY_RE.fullmatch(primary.strip())) and info.get('date',-1)<0
            time_only |= only
            stamp=ts_for_row(values,info,anchor)
            if only and stamp is not None and previous is not None and stamp<previous-12*3600000:
                anchor+=timedelta(days=1);stamp=ts_for_row(values,info,anchor)
            if stamp is not None:
                previous=stamp;first=stamp if first is None else min(first,stamp);last=stamp if last is None else max(last,stamp)
            rows.append(dict(lineNo=reader.line_num+offset,tsMs=stamp,data={h:values[i] if i<len(values) else '' for i,h in enumerate(headers)}))
        for row in rows:
            for h in headers:row['data'].setdefault(h,'')
    except csv.Error as err:raise McpToolError(f'{name}:{reader.line_num+offset}: CSV 파싱 실패: {err}') from err
    warnings=[]
    if changes:warnings.append(dict(code='header_normalized',file=name,message=f'{name}: 컬럼명을 구분해 병합했습니다. 값은 원래 열 위치대로 보존합니다.',columns=changes))
    if extra_columns:warnings.append(dict(code='extra_columns_preserved',file=name,message=f'{name}: 헤더보다 많은 셀을 별도 컬럼으로 보존했습니다.',columns=extra_columns))
    return dict(name=name,headers=headers,count=len(rows),rows=rows,firstMs=first,lastMs=last,firstTime=ms_to_display(first),lastTime=ms_to_display(last),timeOnly=time_only,warnings=warnings)

def clear_dataset(upload_id):
    with transaction() as db:
        db.execute('DELETE FROM findings WHERE upload_id=?',(upload_id,))
        db.execute('DELETE FROM events WHERE upload_id=?',(upload_id,))
        db.execute('DELETE FROM messages WHERE upload_id=?',(upload_id,))
        db.execute('DELETE FROM file_meta WHERE upload_id=?',(upload_id,))
        db.execute('UPDATE jobs SET result_json=NULL,report_json=NULL,verification_json=NULL,finalized_at=NULL WHERE id=?',(upload_id,))
def store_file(upload_id,parsed):
    with transaction() as db:
        db.executemany('INSERT INTO messages(upload_id,line_no,ts_ms,source_file,data_json) VALUES(?,?,?,?,?)',((upload_id,r['lineNo'],r['tsMs'],parsed['name'],json.dumps(r['data'],ensure_ascii=False)) for r in parsed['rows']))
        db.execute('''INSERT INTO file_meta(upload_id,name,row_count,first_ms,last_ms,first_time,last_time,header_order) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(upload_id,name) DO UPDATE SET row_count=excluded.row_count,first_ms=excluded.first_ms,last_ms=excluded.last_ms,first_time=excluded.first_time,last_time=excluded.last_time,header_order=excluded.header_order''',(upload_id,parsed['name'],parsed['count'],parsed['firstMs'],parsed['lastMs'],parsed['firstTime'],parsed['lastTime'],json.dumps(parsed['headers'],ensure_ascii=False)))
def file_stats(upload_id):
    return [dict(r) for r in get_db().execute('SELECT name,row_count AS rowCount,first_time AS firstTime,last_time AS lastTime,first_ms AS firstMs,last_ms AS lastMs,header_order AS headerOrder FROM file_meta WHERE upload_id=? ORDER BY name',(upload_id,))]
def total_row_count(upload_id): return get_db().execute('SELECT COALESCE(SUM(row_count),0) FROM file_meta WHERE upload_id=?',(upload_id,)).fetchone()[0]
def safe_parse(text,fallback=None):
    try: return json.loads(text)
    except (ValueError,TypeError): return fallback
