import secrets
from lib.jobs import get_job
from .mcp_core import McpToolError
def assert_job(upload_id,token):
    if not upload_id: raise McpToolError('uploadId(업로드 ID)가 필요합니다.')
    if not token: raise McpToolError('accessToken(액세스 토큰)이 필요합니다.')
    job=get_job(str(upload_id))
    if not job: raise McpToolError(f'존재하지 않는 업로드 ID입니다: {upload_id}')
    if not secrets.compare_digest(str(job['token'] or ''),str(token)): raise McpToolError('액세스 토큰이 올바르지 않습니다.')
    return job
