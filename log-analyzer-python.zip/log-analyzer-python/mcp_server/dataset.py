import time
import json
from lib.db import get_db
from lib.paths import UPLOADS_DIR,RESULTS_DIR
from lib.jobs import set_job_status
from .zip_reader import read_csv_entries
from .csv_merge import parse_csv_entry,clear_dataset,store_file,total_row_count
from .mcp_core import McpToolError
def zip_path_for(upload_id): return UPLOADS_DIR/upload_id/'upload.zip'
def _prepare_dataset(upload_id):
    started=time.monotonic(); set_job_status(upload_id,'extracting'); clear_dataset(upload_id)
    output=RESULTS_DIR/upload_id/'final.csv'
    output.unlink(missing_ok=True)
    files=[]; time_only=[];warnings=[]
    for entry in read_csv_entries(zip_path_for(upload_id)):
        parsed=parse_csv_entry(entry['name'],entry['buffer']); store_file(upload_id,parsed)
        warnings.extend(parsed.get('warnings',[]))
        if parsed['timeOnly']: time_only.append(parsed['name'])
        files.append({k:parsed[k] for k in ('name','firstTime','lastTime')}|{'rowCount':parsed['count']})
    if not files: raise McpToolError('ZIP 안에 CSV 파일이 없습니다.')
    set_job_status(upload_id,'reading')
    if time_only:warnings.append({'code':'date_anchored','message':'날짜 없이 파일명/실행 일자로 해석한 파일: '+', '.join(time_only)})
    get_db().execute('UPDATE jobs SET dataset_warnings_json=? WHERE id=?',(json.dumps(warnings,ensure_ascii=False),upload_id))
    return dict(ok=True,uploadId=upload_id,fileCount=len(files),rowCount=total_row_count(upload_id),files=files,warnings=warnings,elapsedMs=int((time.monotonic()-started)*1000))


def prepare_dataset(upload_id):
    get_db().execute('UPDATE jobs SET dataset_warnings_json=NULL WHERE id=?',(upload_id,))
    try:
        return _prepare_dataset(upload_id)
    except Exception as err:
        # Never leave a failed import looking like an ongoing extraction, and
        # never expose a partially imported dataset as ready for analysis.
        clear_dataset(upload_id)
        message=str(err) if isinstance(err,McpToolError) else f'ZIP/CSV 준비 실패 ({type(err).__name__}): {err}'
        set_job_status(upload_id,'failed',message)
        if isinstance(err,McpToolError):raise
        raise McpToolError(message) from err
