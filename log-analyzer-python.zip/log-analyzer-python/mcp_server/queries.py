import json
from datetime import datetime
from lib.db import get_db
from lib.jobs import set_job_status
from lib.time import parse_time_value,ms_to_display
from lib.evidence import median,percentile
from .auth import assert_job
from .mcp_core import McpToolError
from .csv_merge import file_stats,safe_parse
ORDER_CLAUSE='(ts_ms IS NULL),ts_ms,source_file,line_no'
CORE_FIELDS=['Time1','Time2','From','From Unit','Sender','To','To Unit','Receiver']
MAX_SUBJECTS=500
MAX_ROWS_PER_SUBJECT=20000
def json_path(field): return '$.'+json.dumps(str(field),ensure_ascii=False)
def mark_analyzing(upload_id):
    row=get_db().execute('SELECT status FROM jobs WHERE id=?',(upload_id,)).fetchone()
    if row and row['status'] in ('reading','extracting','analyzing'): set_job_status(upload_id,'analyzing')
def metas_with_fields(upload_id):
    stats=file_stats(upload_id)
    if not stats: raise McpToolError('prepare_dataset를 먼저 호출하세요.')
    return stats
def all_headers(stats): return sorted({h for s in stats for h in safe_parse(s['headerOrder'],[])})
def check_field(stats,field,what='field'):
    if not isinstance(field,str) or field not in all_headers(stats): raise McpToolError(f'{what}: 존재하지 않는 필드 {field!r}. 사용 가능한 필드: {all_headers(stats)}')
    return field
def check_fields(stats,fields,what='fields'):
    if not isinstance(fields,list) or not fields: raise McpToolError(f'{what}: 필드 목록이 필요합니다.')
    return [check_field(stats,f,what) for f in fields]
def time_range_ms(stats):
    first=[s['firstMs'] for s in stats if s['firstMs'] is not None]; last=[s['lastMs'] for s in stats if s['lastMs'] is not None]
    return (min(first) if first else None,max(last) if last else None)
def parse_time_arg(value,anchor=None,what='time'):
    if isinstance(value,(int,float)) and not isinstance(value,bool):
        try: return int(value)
        except (ValueError,OverflowError): pass
    if isinstance(value,str):
        parsed=parse_time_value(value,datetime.fromtimestamp(anchor/1000) if anchor is not None else None)
        if parsed is not None: return parsed
    raise McpToolError(f'{what}: epoch ms 또는 YYYY-MM-DD HH:MM:SS/HH:MM:SS가 필요합니다.')
def base_where(upload_id,stats,opts):
    where=['upload_id=?']; params=[upload_id]
    if opts.get('sourceFile'):
        if opts['sourceFile'] not in [s['name'] for s in stats]: raise McpToolError(f"존재하지 않는 파일: {opts['sourceFile']}")
        where.append('source_file=?'); params.append(opts['sourceFile'])
    anchor,_=time_range_ms(stats); times={}
    for key,op in (('fromMs','>='),('toMs','<=')):
        if opts.get(key) is not None:
            times[key]=parse_time_arg(opts[key],anchor,key); where.append('ts_ms'+op+'?'); params.append(times[key])
    if len(times)==2 and times['fromMs']>times['toMs']: raise McpToolError('fromMs는 toMs보다 늦을 수 없습니다.')
    return where,params
def add_field_filter(where,params,stats,args):
    if args.get('field'):
        check_field(stats,args['field']); values=args.get('values')
        if not isinstance(values,list) or not values: raise McpToolError('field에는 비어 있지 않은 values가 필요합니다.')
        where.append('json_extract(data_json,?) IN ('+','.join('?' for _ in values)+')'); params.extend([json_path(args['field']),*map(str,values)])
def bounded(value,default=200,maximum=500):
    try: return min(maximum,max(1,int(value if value is not None else default)))
    except (ValueError,TypeError,OverflowError): raise McpToolError('limit은 정수여야 합니다.')
def summarize_dataset(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken')); stats=metas_with_fields(job['id']); db=get_db()
    if args.get('field'): check_field(stats,args['field'])
    where,params=base_where(job['id'],stats,{'sourceFile':args.get('file'),'fromMs':args.get('fromMs'),'toMs':args.get('toMs')}); cond=' AND '.join(where)
    total=db.execute('SELECT COUNT(*) n,MIN(ts_ms) f,MAX(ts_ms) l FROM messages WHERE '+cond,params).fetchone(); first,last=total['f'],total['l']
    target=((last or 0)-(first or 0))/32
    nice=[1000,5000,10000,15000,30000,60000,120000,300000,600000,900000,1800000,3600000,7200000,14400000]
    bucket=max(1000,int(args['bucketSec']*1000)) if args.get('bucketSec') else next((b for b in nice if b>=target),nice[-1])
    histogram=[]
    if first is not None:
        rows=db.execute('SELECT CAST((ts_ms-?)/? AS INTEGER) b,COUNT(*) c FROM messages WHERE '+cond+' AND ts_ms IS NOT NULL GROUP BY b ORDER BY b',[first,bucket,*params])
        histogram=[dict(fromMs=first+r['b']*bucket,toMs=first+(r['b']+1)*bucket,count=r['c'],**{'from':ms_to_display(first+r['b']*bucket)}) for r in rows]
    values=None
    if args.get('field'):
        p=json_path(args['field'])
        rows=db.execute('SELECT json_extract(data_json,?) v,COUNT(*) c,MIN(ts_ms) f,MAX(ts_ms) l FROM messages WHERE '+cond+" AND json_extract(data_json,?) IS NOT NULL AND json_extract(data_json,?)<>'' AND ts_ms IS NOT NULL GROUP BY v ORDER BY c DESC,f LIMIT 200",[p,*params,p,p])
        values=[dict(value=str(r['v']),count=r['c'],firstTime=ms_to_display(r['f']),lastTime=ms_to_display(r['l'])) for r in rows]
    mark_analyzing(job['id'])
    return dict(ok=True,rowCount=total['n'],fileCount=len(stats),firstTime=ms_to_display(first),lastTime=ms_to_display(last),timeSpanMs=last-first if first is not None and last is not None else 0,bucketSec=bucket/1000,histogram=histogram,fieldValues=values,files=[{k:s[k] for k in ('name','rowCount','firstTime','lastTime')}|{'columns':safe_parse(s['headerOrder'],[])} for s in stats])
def resolve_refs(upload_id,refs,table):
    if table not in ('events','findings'): raise ValueError('Invalid reference table')
    ids=[]
    for ref in refs:
        row=get_db().execute(f'SELECT id FROM {table} WHERE upload_id=? AND '+('id=?' if isinstance(ref,int) else 'client_id=?'),(upload_id,ref)).fetchone()
        if not row: raise McpToolError(f'{table}: 참조할 수 없는 ID {ref}')
        ids.append(row['id'])
    return ids
def query_messages(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken')); stats=metas_with_fields(job['id']); db=get_db(); where,params=base_where(job['id'],stats,args)
    add_field_filter(where,params,stats,args)
    for key,table,links,column in [('eventIds','events','event_messages','event_id'),('findingIds','findings','finding_messages','finding_id')]:
        if args.get(key):
            ids=resolve_refs(job['id'],args[key],table); where.append(f'id IN (SELECT message_id FROM {links} WHERE {column} IN ('+','.join('?' for _ in ids)+'))'); params.extend(ids)
    cond=' AND '.join(where); limit=bounded(args.get('limit'),100); offset=max(0,int(args.get('offset',0)))
    count=db.execute('SELECT COUNT(*) FROM messages WHERE '+cond,params).fetchone()[0]
    rows=db.execute('SELECT * FROM messages WHERE '+cond+' ORDER BY '+ORDER_CLAUSE+' LIMIT ? OFFSET ?',[*params,limit,offset]).fetchall()
    projection=check_fields(stats,args['fields']) if args.get('fields') else [h for h in all_headers(stats) if h in CORE_FIELDS] or all_headers(stats)
    result=[]
    for r in rows:
        data=safe_parse(r['data_json'],{}); result.append(dict(id=r['id'],time=ms_to_display(r['ts_ms']),source=r['source_file'],line=r['line_no'],fields={h:str(data[h]) for h in projection if data.get(h) not in (None,'')}))
    mark_analyzing(job['id']); return dict(ok=True,total=count,returned=len(result),offset=offset,limit=limit,rows=result)
def top_subjects(db,cond,params,path,limit):
    return db.execute('SELECT json_extract(data_json,?) v,COUNT(*) c FROM messages WHERE '+cond+" AND json_extract(data_json,?) IS NOT NULL AND json_extract(data_json,?)<>'' GROUP BY v ORDER BY c DESC,v LIMIT ?",[path,*params,path,path,limit]).fetchall()
def calculate_metrics(args):
    job=assert_job(args.get('uploadId'),args.get('accessToken')); stats=metas_with_fields(job['id']); db=get_db(); where,params=base_where(job['id'],stats,args); cond=' AND '.join(where); op=args.get('operation'); limit=bounded(args.get('limit'))
    subject=(args.get('groupBy') or [args.get('field')])[0]; rows=[]; out=dict(ok=True,operation=op)
    if op=='routes':
        fields=args.get('fields') or []
        headers=all_headers(stats)
        a=check_field(stats,fields[0]) if fields else next((h for h in ('Sender','From','SRC','S') if h in headers),None)
        b=check_field(stats,fields[1]) if len(fields)>1 else next((h for h in ('Receiver','To','DST','D') if h in headers),None)
        if not a or not b: raise McpToolError('fields에 [송신,수신] 컬럼명을 지정하세요.')
        p,q=json_path(a),json_path(b)
        result=db.execute('SELECT json_extract(data_json,?) s,json_extract(data_json,?) r,COUNT(*) c,MIN(ts_ms) f,MAX(ts_ms) l FROM messages WHERE '+cond+" AND json_extract(data_json,?) IS NOT NULL AND json_extract(data_json,?)<>'' AND json_extract(data_json,?) IS NOT NULL AND json_extract(data_json,?)<>'' AND ts_ms IS NOT NULL GROUP BY s,r ORDER BY c DESC LIMIT ?",[p,q,*params,p,p,q,q,limit])
        rows=[dict(**{'from':str(r['s'])},to=str(r['r']),count=r['c'],firstTime=ms_to_display(r['f']),lastTime=ms_to_display(r['l'])) for r in result]; out.update(fromField=a,toField=b)
    elif op=='first_last':
        check_field(stats,subject,'groupBy/field'); p=json_path(subject)
        distinct=db.execute('SELECT COUNT(DISTINCT json_extract(data_json,?)) FROM messages WHERE '+cond+" AND json_extract(data_json,?)<>''",[p,*params,p]).fetchone()[0]
        result=db.execute('SELECT json_extract(data_json,?) v,COUNT(*) c,MIN(ts_ms) f,MAX(ts_ms) l FROM messages WHERE '+cond+" AND json_extract(data_json,?) IS NOT NULL AND json_extract(data_json,?)<>'' AND ts_ms IS NOT NULL GROUP BY v ORDER BY c DESC,f LIMIT ?",[p,*params,p,p,limit])
        rows=[dict(value=str(r['v']),count=r['c'],firstTime=ms_to_display(r['f']),lastTime=ms_to_display(r['l']),firstMs=r['f'],lastMs=r['l']) for r in result]; out.update(subjectField=subject,distinctValues=distinct)
    elif op in ('intervals','field_changes'):
        if subject: check_field(stats,subject,'groupBy/field')
        if op=='field_changes':
            check_field(stats,subject,'groupBy'); check_fields(stats,args.get('fields'))
        subjects=top_subjects(db,cond,params,json_path(subject),limit) if subject else [{'v':None}]
        for s in subjects:
            w=list(where); pp=list(params)
            if subject: w.append('json_extract(data_json,?)=?'); pp.extend([json_path(subject),s['v']])
            # Fetch one extra row so truncation is visible to the agent.
            raw=db.execute('SELECT ts_ms,data_json FROM messages WHERE '+' AND '.join(w)+' AND ts_ms IS NOT NULL ORDER BY '+ORDER_CLAUSE+' LIMIT ?',[*pp,MAX_ROWS_PER_SUBJECT+1]).fetchall()
            truncated=len(raw)>MAX_ROWS_PER_SUBJECT; raw=raw[:MAX_ROWS_PER_SUBJECT]
            base={'value':str(s['v'])} if subject else {}; base.update(count=len(raw),truncated=truncated)
            if op=='intervals':
                if len(raw)<2: continue
                ts=[r['ts_ms'] for r in raw]; gaps=[(b-a,a,b) for a,b in zip(ts,ts[1:])]; vals=[g[0] for g in gaps]
                base.update(minGapMs=min(vals),medianGapMs=median(vals),p95GapMs=percentile(vals,.95),maxGapMs=max(vals),firstTime=ms_to_display(ts[0]),lastTime=ms_to_display(ts[-1]),longestGaps=[dict(gapMs=g,startMs=a,start=ms_to_display(a),endMs=b,end=ms_to_display(b)) for g,a,b in sorted(gaps,reverse=True)[:5]])
                if args.get('thresholdMs') is not None: base.update(thresholdMs=args['thresholdMs'],gapsOverThreshold=sum(g>args['thresholdMs'] for g in vals))
            else:
                last={}; changes=[]; total=0
                for r in raw:
                    data=safe_parse(r['data_json'],{})
                    for field in args['fields']:
                        value=str(data.get(field,'')).strip()
                        if not value: continue
                        if field in last and last[field]!=value:
                            total+=1
                            if len(changes)<200: changes.append(dict(time=ms_to_display(r['ts_ms']),ms=r['ts_ms'],field=field,**{'from':last[field],'to':value}))
                        last[field]=value
                base.update(totalChanges=total,changes=changes,changesTruncated=total>len(changes),lastValues=last,firstTime=ms_to_display(raw[0]['ts_ms']) if raw else None,lastTime=ms_to_display(raw[-1]['ts_ms']) if raw else None)
            rows.append(base)
        out.update(subjectField=subject)
        if op=='field_changes': out['fields']=args['fields']
    else: raise McpToolError('operation: first_last/intervals/field_changes/routes 중 하나를 사용하세요.')
    mark_analyzing(job['id']); out['rows']=rows; return out
