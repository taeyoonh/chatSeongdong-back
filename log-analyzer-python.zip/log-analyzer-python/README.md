# 시험 로그 분석기 — Python 이식 프로젝트

제공된 Node.js v2 코드의 서버·공용 라이브러리·MCP 도구를 Python으로 옮긴 프로젝트입니다.
브라우저는 HTML/CSS/JavaScript를 사용합니다. Node.js, npm, Express, yauzl, csv-parse 및 Python 외부 패키지는 필요하지 않습니다. **Kilo CLI와 모델/RAG API는 여전히 외부 실행 환경으로 필요합니다.** 사내 RAG를 호출하는 클라이언트와 MCP 검색 도구는 프로젝트에 포함되어 있습니다.

## Kilo 설정·모델 관리 (이번 버전)

서버 실행 후 화면 왼쪽 상단 **⚙ Kilo 설정** 버튼을 누르세요. 모델을 바꾸기 위해 `local-config.json`을 직접 수정할 필요가 없습니다.

1. **전역 설정 파일**: 서버 PC의 `~/.config/kilo` 및 `XDG_CONFIG_HOME/kilo`에서 JSON/JSONC 설정 파일을 찾습니다. `KILO_CONFIG`가 가리키는 기존 파일도 목록에 포함합니다. 없으면 기본 `kilo.jsonc`를 새로 만들 대상으로 표시합니다.
2. **Provider 추가·편집**: ID, 표시 이름, SDK 패키지, baseURL, 새 API 키를 입력하고 상세 JSON의 `models`·modalities·reasoning·tool_call·limit 등을 편집합니다. 하나 이상의 모델이 필요합니다. 제공된 실제 사내 키는 배포 ZIP에 넣지 않았습니다.
3. **모델 추가**: model ID/표시 이름 입력 → 편집 중 provider에 추가 → provider 저장. 또는 저장된 provider를 선택해 **서버 /models 조회** → 모델 선택 → 편집 중 provider에 추가 → 저장하세요. 서버가 OpenAI 호환 `/models`를 제공하지 않으면 ID를 직접 입력합니다. 모델 목록 조회는 자동 호출하지 않습니다.
4. **기본 모델 적용**: 등록된 모델을 선택하면 선택된 전역 파일의 `model`과 이 분석기의 기본값을 함께 저장합니다. 업로드 화면의 **분석 모델**에서 해당 작업만 다른 모델을 선택할 수도 있습니다.
5. **Kilo 실행 경로 저장**: exe 경로/명령도 같은 화면에서 변경할 수 있습니다.

Provider 상세 JSON은 provider ID 내부의 객체만 입력하세요. 전체 provider 맵이나 바깥 `provider` 키는 넣지 않습니다. 예시(실제 주소/키로 수정):

```json
{
  "name": "Gemma 4 31B Think Off",
  "npm": "@ai-sdk/openai-compatible",
  "options": {"baseURL": "http://실제서버/v1", "apiKey": "실제키"},
  "models": {
    "gemma-4-31B-it": {
      "name": "Gemma 4 31B Think Off",
      "reasoning": false,
      "tool_call": true,
      "modalities": {"input": ["text"], "output": ["text"]}
    }
  }
}
```

위 구조의 baseURL·표시 이름·SDK는 구조화된 입력칸이 저장 시 우선합니다. 모델 상세 옵션은 JSON에서 편집합니다. `tool_call` 값으로 모델 선택/실행을 제한하지 않으며 값도 임의로 변경하지 않습니다. 전역 `disabled_providers`/`enabled_providers`로 비활성화된 provider는 사용 불가로 표시합니다.

읽기 응답에서 API 키와 헤더 값은 `__KEEP_SECRET__`로 마스킹합니다. 이 표시는 그대로 저장하면 기존 비밀값이 유지됩니다. 새 API 키 입력란은 비워 두면 유지하고 입력하면 변경합니다. 실제 키는 Kilo 전역 설정에 저장하며 브라우저 localStorage에는 저장하지 않습니다. 기존 전역 파일을 저장하기 전 원본 백업을 같은 폴더에 만들고, 읽은 이후 파일이 변경됐으면 409로 중단합니다. JSONC의 수정 대상 provider/model 항목 내부 주석은 정규화하지만 다른 최상위 설정과 그 주석은 유지합니다. provider 삭제도 원본 백업 후 선택 파일에서만 수행합니다.

전역 설정 저장은 다른 Kilo 프로젝트의 동작에도 영향을 줄 수 있습니다. 프로젝트 설정/환경 오버라이드가 있으면 전역 설정보다 우선할 수 있어 모델 목록에 설정 출처를 표시합니다. 이 목록은 지원하는 로컬 설정 파일을 병합한 등록 모델 목록이며 Kilo CLI의 모든 내장 모델 카탈로그를 조회한 것은 아닙니다. 프로젝트 내부/조직 정책/설치 버전에 따른 실제 최종 설정은 Kilo 동작으로 확인해야 합니다. 이 UI는 provider/model 및 이 분석기의 Kilo 실행 경로를 관리하며 permission/MCP 등 다른 최상위 설정의 전체 편집기는 아닙니다.

새 작업은 선택 모델 ID와 Kilo 실행 경로를 DB에 저장해서 실행합니다. 진행 중 작업의 모델 선택은 바꾸지 않습니다. 모델 설정이 없거나 삭제된 모델을 선택했다면 업로드 전에 설정 안내를 반환합니다. 기본 모델과 실행 경로는 `data/kilo-ui-settings.json`, 실제 provider/인증은 선택한 Kilo 전역 파일에 저장합니다. 기존 local-config의 model은 더 이상 작업 모델 결정에 사용하지 않습니다. 서버 실행 경로의 초기값은 기존 local-config/자동 탐색을 지원하고 UI 저장 이후에는 UI 값이 우선합니다.

설정 API는 서버 PC의 localhost 접속에서만 사용 가능합니다. 다른 출처의 요청과 JSON이 아닌 쓰기를 차단합니다. 실제 Kilo 전역 설정은 실행한 Windows 사용자 계정의 파일입니다. 다른 PC/다른 계정의 설정을 편집하는 기능이 아닙니다.

관련 API:

| Method | 경로 | 기능 |
|---|---|---|
| GET | `/api/kilo/settings` | 전역 파일·provider·등록 모델·기본값 조회, 비밀값 마스킹 |
| POST | `/api/kilo/settings` | provider 저장/삭제, 기본 모델/실행 경로 저장 |
| POST | `/api/kilo/models/fetch` | 선택 provider의 baseURL + `/models` 조회 |

공식 설정 형식 참고: [Kilo Settings](https://kilo.ai/docs/getting-started/settings), [Custom Models](https://kilo.ai/docs/code-with-ai/agents/custom-models). 서버 모델 조회의 `{env:VAR}` 키 참조는 OS 환경변수에서 읽으며 `{file:...}` 참조는 UI의 모델 목록 조회에서 지원하지 않습니다. 이 제약은 Kilo 자체의 인증 처리와는 별개입니다.

## 근거 소스 선택

업로드 카드의 **사내 RAG 사용** 토글에서 선택하세요. 기본값은 ON입니다.

| 토글 | 검색 소스 | 필요한 설정 |
|---|---|---|
| ON | 사내 RAG API | `.env`의 실제 서버 주소/경로/인증/데이터셋 |
| OFF | 서버에 지정된 TXT 한 파일 | `localKnowledgePath`와 실제 TXT 내용 |

ON/OFF와 관계없이 에이전트는 `search_rag`를 호출합니다. 백엔드가 작업별 선택을 저장하고 Kilo/MCP 자식 프로세스에 전달하므로 모델이 호출마다 소스를 임의 변경하지 않습니다. 분석 중에는 토글을 잠급니다. 선택 소스 실패 시 다른 소스로 자동 우회하지 않습니다. TXT OFF는 **근거 조회만 로컬**이며 Kilo가 사용하는 언어 모델까지 로컬로 바꾸는 기능은 아닙니다.

TXT의 실제 규격 내용은 제공되지 않았으므로 파일은 사용자가 준비해야 합니다. 기본 위치:

```text
프로젝트 루트/knowledge/reference.txt
```

다른 고정 위치는 `config/local-config.json`에서 설정하세요. 예시의 사용자명/위치를 실제 환경에 맞게 바꾸세요.

```json
"localKnowledgePath": "C:/Users/77753/MDIL/docs/reference.txt"
```

이 속성은 기존 설정 JSON의 다른 항목들과 함께 넣습니다. 상대 경로는 프로젝트 루트 기준입니다. 실제 규격·메시지 정의·상태 코드·운용 절차를 UTF-8 TXT로 저장하세요. 소제목/메시지 번호/필드명이 들어 있으면 찾기 쉽습니다. TXT 파일 경로는 브라우저에서 입력하지 않고 서버 설정으로 정합니다.

OFF의 검색은 본문을 약 2400자/40줄 이하로 분할하고 키워드·메시지 번호 일치 점수로 상위 구간을 반환합니다. 임베딩 기반 의미 검색이 아니므로 긴 질문으로 찾지 못하면 메시지 번호와 실제 필드명 등 핵심어로 다시 검색해야 합니다. 무관한 내용을 근거로 채우지 않으며 0건이면 빈 결과입니다. 파일명과 `lines 시작-끝`, SHA256을 반환합니다. 이 위치를 finding의 references에 저장하도록 에이전트 지침도 변경했습니다.

UTF-8/BOM/CP949와 최대 64MiB TXT를 지원합니다. 파일 누락·빈 파일은 업로드 전에 오류로 표시합니다. MCP가 파일을 읽은 뒤 파일의 크기/수정 시각 변경을 감지하면 새 분석을 요청합니다. 분석 도중에는 파일을 수정하지 마세요.

작업 목록/상세와 결과에는 `knowledgeSource`가 저장됩니다. 로컬 TXT의 고정 경로도 작업에 저장합니다. 기존 DB는 컬럼을 자동 추가하며 과거 작업의 기본 소스는 rag입니다. 서버를 종료하고 백업 후 업데이트하세요.

## 빠른 실행 — Windows

Python 3.10 이상(권장 3.12), Kilo CLI가 설치되어 있어야 합니다.
압축을 풀고 프로젝트 루트에서 명령 프롬프트를 여세요.

```bat
py -3 --version
copy config\local-config.example.json config\local-config.json
py -3 scripts\configure_mcp.py
py -3 run.py
```

브라우저에서 http://127.0.0.1:3000/ 을 여세요. HTML 파일을 직접 더블클릭하지 마세요.
`start.bat`으로도 서버를 실행할 수 있습니다. 종료는 서버 창에서 Ctrl+C입니다.

가상환경이 있다면 같은 Python으로 설정과 서버를 실행하세요.

```bat
.venv\Scripts\python.exe scripts\configure_mcp.py
.venv\Scripts\python.exe run.py
```

추가 pip 설치는 없습니다. Linux에서는 `python3` 명령을 사용하면 됩니다.

## 반드시 확인할 설정

`config/local-config.json` 예시:

```json
{
  "host": "127.0.0.1",
  "port": 3000,
  "agent": "log-analyst",
  "kiloTimeoutMs": 3600000,
  "maxUploadBytes": 1073741824,
  "maxExpandedBytes": 2147483648,
  "maxZipEntries": 10000,
  "kiloExecutable": "C:\\Users\\77753\\.vscode\\extensions\\kilocode.kilo-code-7.4.17\\bin\\kilo.exe"
}
```

- 모델은 이제 웹 화면의 **Kilo 설정** 또는 업로드 카드의 **분석 모델**에서 선택합니다. local-config의 model 값은 분석 모델 선택에 사용하지 않습니다.
- `kiloExecutable`: 실제 설치 경로로 바꾸세요. 빈 문자열이면 `KILO_EXE` 환경변수 → VS Code 확장 설치 경로 → PATH의 `kilo` 순으로 찾습니다.
- 값은 서버 시작 시 읽습니다. 수정 후 서버를 재시작하세요.
- 잘못된 JSON은 조용히 무시하지 않고 시작 오류로 알립니다.
- 업로드는 기본 1GiB(기존 화면 표기는 1GB), 해제된 CSV 합계는 2GiB입니다. 한 CSV는 메모리에서 파싱하므로 큰 파일은 충분한 RAM이 필요합니다.

## Kilo 모델/RAG 설정 이전

이 프로젝트의 `kilo.json`은 로컬 로그 분석 MCP와 권한을 정의합니다. 모델 provider는 기존 Kilo 설정을 계속 사용하거나 병합하세요. RAG 검색은 같은 MCP 서버 안의 `search_rag`이 직접 사내 API를 호출하므로 별도 RAG MCP 서버는 필요하지 않습니다. 실제 사내 API 주소/키는 `.env`에 입력하세요.

기존 프로젝트 설정을 가져올 경우 기존 `kilo.json`을 이 프로젝트에 복사한 뒤 아래를 실행하면, 다른 provider/MCP 항목을 유지하면서 `log-analyzer` 명령만 현재 Python으로 바꿉니다. 기존 파일은 `kilo.json.bak`으로 백업합니다.

```bat
py -3 scripts\configure_mcp.py
```

변경되는 MCP 항목:

```json
"log-analyzer": {
  "type": "local",
  "command": ["C:\\실제\\Python\\python.exe", "-m", "mcp_server.index"],
  "timeout": 600000
}
```

백엔드는 프로젝트 루트에서 다음 형태로 기존 CLI를 실행합니다.

```text
kilo run <작업 프롬프트> --format json --auto --dir <프로젝트 루트> --agent log-analyst -m <설정 model> --title log-<ID>
```

CLI 플래그는 제공된 원본과 동일합니다. 설치된 Kilo 버전의 지원 여부는 해당 PC에서 확인해야 합니다. 에이전트 원문은 제공되지 않아 `.kilo/agent/log-analyst.md`를 v2 도구 흐름에 맞춰 새로 작성했습니다.

**Python 이식은 모델 서버의 `Response ended unexpectedly` 오류를 해결한다고 보장하지 않습니다.** 외부 모델 연결 오류는 작업 로그와 실패 이유에 표시하며, 모델이 0 코드로 종료해도 완료 도구를 호출하지 않았다면 성공으로 처리하지 않습니다.

## 분석 흐름

1. 프로젝트/시험/프로토콜 선택 → ZIP 업로드
2. Python 백엔드가 작업과 토큰 생성 → Kilo 실행
3. 에이전트가 `prepare_dataset` → `summarize_dataset`/`query_messages`/`calculate_metrics` 및 내장 `search_rag` RAG 검색
4. `save_analysis`로 모든 구간의 이벤트/Finding·메시지 연결 저장
5. `finalize_analysis`로 분석 확정 → `build_report` → `verify_report`
6. 화면 타임라인/관련 메시지 확인 및 통합 CSV 다운로드

판정 우선순위는 **anomaly > undetermined > 모든 연결 이벤트가 normal인 메시지 > unreviewed**입니다. anomaly 이벤트만 있고 직접 연결된 anomaly Finding이 없으면 그 메시지는 undetermined입니다. 원본 v2의 구분을 유지합니다.
확정 이후에는 분석을 수정할 수 없습니다. 재분석은 새 ZIP 업로드로 진행합니다.
검증은 구조적 일치 검증이며 AI 판단이나 ICD 해석의 정확성을 증명하지 않습니다.

원본 README에 남아 있던 `run_rules` 및 `rules/v1.cjs`는 제공된 실제 v2 구현에 존재하지 않아 추가하지 않았습니다. 판정은 AI 에이전트가 수행합니다.

## API (원본 경로 유지)

| Method | URL | 기능 |
|---|---|---|
| POST | `/api/read-jobs?filename=...&project=...&test=...&protocol=...` | ZIP 바이트 업로드, Content-Length 필요 |
| GET | `/api/read-jobs` | 작업 목록 |
| GET | `/api/read-jobs/{id}` | 상태/파일/보고서/마지막 로그 30줄 |
| GET | `/api/read-jobs/{id}/csv` | 최종 CSV 다운로드 |
| GET | `/api/read-jobs/{id}/events` | 전체 이벤트 목록 |
| GET | `/api/read-jobs/{id}/events/{eid}` | 이벤트/Finding 및 최대 500개 관련 메시지 |
| GET | `/api/health` | Python 웹서버 동작 확인(모델 연결 확인 아님) |

작업 액세스 토큰은 MCP 작업 인증용이며 웹 API 인증이 아닙니다. 원본과 같이 로컬 사용을 전제로 합니다. 외부 공개 서비스용 인증은 구현하지 않았습니다.

## 파일 대응

| 원본 | Python 프로젝트 |
|---|---|
| backend/index.cjs | backend/index.py |
| backend/kilo-client.cjs (설명 중 kilo_clinet) | backend/kilo_client.py |
| lib/config.cjs | lib/config.py |
| lib/db.cjs | lib/db.py |
| lib/evidence.cjs | lib/evidence.py |
| lib/jobs.cjs | lib/jobs.py |
| lib/paths.cjs | lib/paths.py |
| lib/time.cjs | lib/time.py |
| mcp-server/analysis.cjs | mcp_server/analysis.py |
| mcp-server/auth.cjs | mcp_server/auth.py |
| mcp-server/csv-merge.cjs | mcp_server/csv_merge.py |
| mcp-server/dataset.cjs | mcp_server/dataset.py |
| mcp-server/index.cjs | mcp_server/index.py |
| mcp-server/mcp-core.cjs | mcp_server/mcp_core.py |
| mcp-server/queries.cjs | mcp_server/queries.py |
| mcp-server/report.cjs | mcp_server/report.py |
| mcp-server/zip-reader.cjs | mcp_server/zip_reader.py |
| public/index.html | public/index.html (구성/기능을 따라 재구현) |
| config/local-config.example.json | 같은 경로 |
| kilo.json | 같은 경로, MCP 실행만 Python으로 변경 |
| readme.md | README.md |

`mcp-server`는 Python 모듈 import를 위해 `mcp_server`로 바꿨습니다.

## 화면 변경 범위

사이드바·프로젝트/시험 생성·Link-16/MDIL 선택·ZIP 업로드·상태 폴링·활동 피드·결과 타임라인·증거 모달·CSV 다운로드를 유지한 HTML/JS 재구현입니다. 원본 HTML 바이트나 픽셀 단위 동일 복사본은 아닙니다. 프런트엔드를 Python 템플릿으로 바꾸지는 않았습니다.
외부 CDN 폰트 의존성을 제거했으며, 하드코딩된 가짜 분석 결과/가짜 증거는 표시하지 않습니다. 실제 저장된 결과만 표시합니다. 프로젝트/시험명은 브라우저 로컬 저장소로 유지하고 저장된 작업은 서버 목록에서 복원합니다. 같은 프로젝트/시험/프로토콜의 최신 작업을 기본 복원합니다. 과거 작업은 `?job=<작업 ID>`로 열 수 있습니다.

## 데이터 이전

빈 프로젝트로 시작하는 것이 기본입니다. 이전 데이터를 옮길 경우 양쪽 서버와 Kilo/MCP 프로세스를 모두 종료하고 기존 `data` 폴더 전체를 백업한 뒤 복사하세요. 실행 중 SQLite의 `app.db`만 복사하면 WAL에 남은 데이터가 빠질 수 있습니다.
Python은 기존 v2 테이블/컬럼명을 유지하고 v1 messages의 명시적 id 생성 마이그레이션을 제공합니다. 실제 사용자 DB는 제공되지 않아 합성 DB에서만 확인했습니다. 이전 v1 판정 데이터의 의미적 변환은 하지 않습니다.
재시작 당시 비종료 작업은 실패로 표시합니다. UI 새로고침 복원과 서버 재시작 후 작업 재실행은 서로 다릅니다.

## 수정한 원본 문제

- `finalizeAnalysis`/`verifyReport`에 문자열만 넘기던 인증 인자 오류
- `messageLinks` 내부가 아닌 이벤트/Finding 자체에서 메시지 링크를 읽던 오류
- UPSERT UPDATE 시 `lastInsertRowid`를 사용해 다른 행의 링크를 수정할 수 있던 오류 (`RETURNING id` 사용)
- `summarize_dataset(file=...)`에서 파일명을 컬럼명으로 검증하던 오류
- SELECT JSON 경로와 WHERE 업로드 ID의 SQL 바인딩 순서 오류
- 정상 이벤트 필터를 GROUP BY 전에 적용해 혼합 판정을 정상 처리하던 오류
- anomaly/undetermined Finding 겹침으로 커버리지가 중복 집계되던 오류
- 부모 이벤트 순서 의존 및 자기참조/순환 허용 오류
- CSV 내부 개행을 새 데이터 행으로 세던 오류 및 헤더 부분문자열 검사
- 하나의 시각만 있는 정상 데이터셋을 타임라인 개수로 무조건 실패 처리하던 오류
- 에이전트 프롬프트에서 `job.context` 대신 없는 최상위 project/test/protocol 참조
- stderr/stdout 마지막 줄 누락, 모델 오류 이벤트를 CLI 성공 코드만으로 무시하던 문제

추가로 CP949, Date+Time 컬럼, 시간만 있는 순차 로그의 자정 통과, 잘못된 날짜 거부, ZIP 용량/경로 검사, 원자적 CSV 교체를 지원합니다. 자정 처리는 이전 행보다 12시간 이상 뒤로 이동한 경우에만 다음 날로 간주합니다. 날짜가 없는 여러 CSV의 서로 다른 시작 날짜는 추론할 수 없습니다.

## 테스트

```bat
py -3 -m unittest discover -v
py -3 scripts\make_test_zip.py
```

48개 테스트: ZIP→SQLite→이벤트/Finding→확정→CSV→검증, SQL 필터·지표, UPSERT/부모 순환 롤백, 판정 중복, 인증, 개행 포함 CSV, CP949/날짜/자정, CSV 변조 검출, 실제 stdio MCP 프로세스, 실제 HTTP 업로드/조회, 모의 CLI 출력·타임아웃, RAG 요청/응답/인증/환경변수/오류 및 MCP 등록.

**실제 Kilo Windows 실행 파일, 사내 Qwen 모델, 외부 RAG 서버는 이 환경에서 실행하지 않았습니다.** 테스트의 CLI는 모의 프로세스이며 통합 설정 후 실데이터로 확인해야 합니다.

## 산출물 경로

- `data/uploads/<id>/upload.zip`
- `data/app.db`
- `data/results/<id>/final.csv`
- `data/logs/<id>.log`

Python 표준 HTTP 서버 기반 로컬 도구입니다. 대용량 CSV 파싱·분석 상태맵은 메모리를 사용하므로 업로드 상한이 메모리 사용 보장치는 아닙니다.


## 내장 RAG 클라이언트 및 검색 도구 (추가)

추가 파일은 `mcp_server/rag_client.py`, `.env.example`, `tests/test_rag.py`입니다.
제공된 RagClient의 요청 계약과 응답 변환을 반영했습니다. 현재 MCP의 동기 실행 방식에 맞춰 Python 표준 `urllib`로 동기 호출하며, `httpx`/`python-dotenv`/`mcps` 패키지는 필요하지 않습니다.

```bat
copy .env.example .env
```

프로젝트 루트 `.env`에서 다음 값을 실제 환경으로 수정하세요.

```dotenv
RAG_SERVER_URL=http://실제-사내-RAG-서버:포트
RAG_SEARCH_PATH=/실제-검색-경로
RAG_HEALTH_PATH=/실제-health-경로
RAG_TIMEOUT_SEC=30
RAG_VERIFY_SSL=true
RAG_API_TOKEN=
RAG_AUTH_HEADER=Authorization
RAG_AUTH_SCHEME=Bearer
RAG_EXTRA_HEADER_NAME=
RAG_EXTRA_HEADER_VALUE=
RAG_DATASET_IDS=268158e49fba11f19801ef240dbe1ea1
```

`RAG_SERVER_URL`에 기존 주소의 base 경로가 있으면 유지하고 search/health 경로를 뒤에 이어 붙입니다. 예시 localhost:9000은 기본값이며 사내 서버 주소를 뜻하지 않습니다. OS 환경변수가 `.env`보다 우선합니다. 간단한 KEY=value, export, 따옴표 및 주석을 지원하지만 `${VAR}` 보간은 하지 않습니다. 변경 후 Python 서버와 기존 Kilo/MCP 작업을 종료하고 재시작하세요.

데이터셋 ID는 사용자 제공 값을 기본값으로 사용했습니다. 어떤 문서가 들어 있는지는 조회로 확인해야 하며 Link-16/MDIL 모두 포함한다고 가정하지 않습니다. 여러 ID는 쉼표 구분 또는 JSON 문자열 배열로 입력하세요.

같은 `log-analyzer` MCP 서버가 기존 9개 + 다음 2개, 총 11개 도구를 제공합니다. 토글 OFF에서는 같은 검색 도구가 지정 TXT에서 조회합니다.

| 도구 | 입력 | 동작 |
|---|---|---|
| `rag_connection_check` | `{}` | ON: RAG health 경로 GET / OFF: 지정 TXT 읽기 확인 |
| `search_rag` | `query`, 선택 `message_id`, `dfi`, `dui`, `rule_type`, `top_k` | ON: 사내 RAG POST / OFF: 지정 TXT 키워드 검색 |

`search_rag` 호출 예시:

```json
{
  "query": "J3.2 항공기 항적의 TRACK NUMBER REFERENCE와 TRACK QUALITY 의미 및 송신 조건",
  "message_id": "J3.2I",
  "top_k": 5
}
```

실제 서버에 보내는 본문은 제공된 계약처럼 아래 두 필드만 사용합니다.

```json
{
  "dataset_ids": ["268158e49fba11f19801ef240dbe1ea1"],
  "question": "질문 본문\nmessage_id: J3.2I"
}
```

`message_id/dfi/dui/rule_type`은 질문에 포함하며 강제 서버 필터가 아닙니다. `top_k`는 API에 확인되지 않은 파라미터를 추가하지 않고 서버가 반환한 결과 중 MCP에 전달할 최대 개수(1~20)로 적용합니다. `retrieved_count`와 `truncated`로 반환 상한 적용 여부를 알립니다. 본문은 임의로 잘라내지 않습니다.

응답은 `chunks/results/documents/items`, 중첩 `data`를 지원하고 `content_with_weight`, `docnm_kwd`, `position_int` 등 원본 필드를 변환·보존합니다. API `code`는 숫자 `0`과 문자열 `"0"`을 모두 성공으로 처리합니다. 오류와 비정상 응답은 MCP `isError=true`로 전달합니다. 0건 검색은 오류가 아닌 빈 결과입니다.

에이전트 프롬프트를 다음 흐름으로 변경했습니다. 호출 순서 전체를 자동 실행하는 엔진은 아니며 에이전트가 도구를 선택합니다.

```text
prepare_dataset → summarize_dataset
→ rag_connection_check → search_rag (필요한 규격마다 반복)
→ query_messages / calculate_metrics / 추가 search_rag
→ save_analysis 반복 → finalize_analysis → build_report → verify_report
```

이번 버전에는 파일 선택만 해도 처리 중으로 표시되던 `busy()` 버그 수정도 포함했습니다. 현재 버전은 CSV 빈/중복 헤더를 구분 가능한 이름으로 정규화해 값을 보존합니다. 작업 취소 UI는 추가하지 않았습니다.


## search_rag 이름 및 반복 조회 흐름

검색 도구 이름을 `search_mdil`에서 `search_rag`로 변경했습니다. 구 이름의 별도 alias는 등록하지 않으며 총 도구 수는 11개입니다. 기존 Kilo 작업은 구 도구 목록을 가질 수 있으므로 종료하고 새 작업으로 시작하세요. API 주소·질문 본문·데이터셋 설정 계약은 동일합니다.

에이전트 지침은 다음 흐름을 따릅니다.

```text
준비 → 로그 관찰
→ 라벨링: 모르는 정의/절차를 search_rag로 확인하고 실제 로그와 대조
→ 이벤트 유효성 검토: 필요한 근거를 추가 검색하고 전후 로그/지표와 대조
→ save_analysis로 후보 저장·갱신 반복
→ 확정 → 보고 → 구조 검증
```

RAG 검색을 처음 한 번으로 제한하지 않으며, 라벨링/유효성 검토 중 새 불확실성이 생길 때마다 호출하도록 했습니다. 같은 근거는 재사용합니다. 로그 자체의 값은 query_messages/calculate_metrics로 확인합니다.
이벤트 유효성 검토는 에이전트가 수행하는 의미적 검토입니다. 별도 validate_event 도구를 추가하거나 의미적 정답을 코드로 강제한 변경은 아닙니다. verify_report는 계속 구조적 정합성만 검사합니다. 순서와 검색 시점은 에이전트 지침이며 검색 충실성/판정 정확성을 보장하는 상태 머신은 아닙니다.


## 토글 버전 업데이트 시

기존 서버/Kilo/MCP를 종료한 뒤 새 소스를 적용하세요. `config/local-config.json`, `.env`, `kilo.json`의 사내 설정과 `data`는 보존하세요. 새 코드에 개인 설정/실제 규격 TXT/기존 DB는 포함하지 않았습니다.

로컬 파일 `knowledge/reference.txt`를 준비한 뒤 토글 OFF로 새 분석을 시작하면 됩니다. RAG ON은 기존 `.env`를 그대로 사용합니다. 연결/검색 도구 이름은 호환성을 위해 `rag_connection_check`/`search_rag`를 유지하며, 실제 사용 소스는 반환값 `knowledge_source`로 구분합니다.

HTTP 업로드 쿼리의 선택값은 `knowledgeSource=rag` 또는 `knowledgeSource=local_text`입니다. 누락 시 rag를 사용합니다. OFF 파일 오류/잘못된 소스 값은 작업을 생성하거나 Kilo를 시작하기 전에 400으로 반환합니다.

추가 검증: OFF 분기에서 RagClient를 생성하지 않는지, ON 분기에서 TXT를 읽지 않는지, 실제 stdio MCP 프로세스의 OFF 검색, Kilo 환경 전달, HTTP OFF 선택의 DB 보존 및 파일 누락 처리. 사내 RAG·Windows Kilo 실제 연결은 별도 확인이 필요합니다.


## CSV 병합 차단 검사 수정

원본 JS에 없던 빈/중복 헤더 거부 조건을 제거했습니다. 데이터 값의 빈 칸은 계속 허용합니다. 빈 헤더는 Unnamed_열번호, 중복 헤더는 충돌 없는 __2/__3 접미사로 구분하고 원래 열 위치의 값을 각각 저장합니다. 실제로 존재하는 컬럼명과 생성한 이름도 충돌하지 않게 처리합니다. 헤더보다 많은 셀은 ExtraColumn_열번호로 보존하고 짧은 행은 빈 값으로 채웁니다. 헤더 이름 변환 내역은 prepare_dataset 경고와 작업 상세 datasetWarnings에 반환합니다. 원본 CSV 파일은 수정하지 않습니다.

UTF-16 BOM과 Excel sep= 구분자 선언도 지원합니다. 손상된 ZIP/깨진 인용부호 등 파싱 불가능한 데이터는 계속 오류이며 무시해 성공 처리하지 않습니다. 준비 단계가 실패하면 부분 DB 데이터를 지우고 작업을 failed로 바꿔 파일명·실패 원인을 표시합니다. 합성 J13.5C1/J3.2I의 순서·값 보존·CSV 결과 검증을 추가했습니다. 실제 사용자 ZIP은 제공되지 않아 해당 파일의 실패 원인은 확인하지 못했습니다.
